import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/dashboard/presentation/pages/dashboard_page.dart';
import '../../features/trips/presentation/pages/trips_list_page.dart';
import '../../features/trips/presentation/pages/trip_details_page.dart';
import '../../features/navigation/presentation/pages/navigation_page.dart';
import '../../features/vehicle/presentation/pages/vehicle_inspection_page.dart';
import '../../features/earnings/presentation/pages/earnings_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';

class AppRouter {
  final AuthBloc authBloc;
  late final GoRouter router;

  AppRouter(this.authBloc) {
    router = GoRouter(
      initialLocation: '/login',
      redirect: (context, state) {
        final isAuthenticated = authBloc.state is AuthAuthenticated;
        final isLoggingIn = state.matchedLocation == '/login';

        if (!isAuthenticated && !isLoggingIn) {
          return '/login';
        }

        if (isAuthenticated && isLoggingIn) {
          return '/dashboard';
        }

        return null;
      },
      routes: [
        GoRoute(
          path: '/login',
          builder: (context, state) => const LoginPage(),
        ),
        GoRoute(
          path: '/dashboard',
          builder: (context, state) => const DashboardPage(),
        ),
        GoRoute(
          path: '/trips',
          builder: (context, state) => const TripsListPage(),
        ),
        GoRoute(
          path: '/trip-details/:id',
          builder: (context, state) {
            final id = state.pathParameters['id']!;
            return TripDetailsPage(tripId: id);
          },
        ),
        GoRoute(
          path: '/navigation/:id',
          builder: (context, state) {
            final id = state.pathParameters['id']!;
            return NavigationPage(tripId: id);
          },
        ),
        GoRoute(
          path: '/vehicle-inspection',
          builder: (context, state) => const VehicleInspectionPage(),
        ),
        GoRoute(
          path: '/earnings',
          builder: (context, state) => const EarningsPage(),
        ),
        GoRoute(
          path: '/profile',
          builder: (context, state) => const ProfilePage(),
        ),
      ],
    );
  }

  void dispose() {
    // Clean up if needed
  }
}
