class ApiEndpoints {
  static const String baseUrl = 'https://api.transit-platform.com';
  
  // Auth
  static const String login = '/api/auth/login';
  static const String logout = '/api/auth/logout';
  static const String refreshToken = '/api/auth/refresh';
  
  // Driver
  static String driver(String id) => '/api/drivers/$id';
  static String driverEarnings(String id) => '/api/drivers/$id/earnings';
  
  // Trips
  static const String trips = '/api/trips';
  static String tripDetails(String id) => '/api/trips/$id';
  static String acceptTrip(String id) => '/api/trips/$id/accept';
  static String startTrip(String id) => '/api/trips/$id/start';
  static String completeTrip(String id) => '/api/trips/$id/complete';
  
  // Vehicle
  static String vehicleInspection(String vehicleId) => '/api/vehicles/$vehicleId/inspection';
}
