import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get_it/get_it.dart';

import '../network/api_client.dart';
import '../../features/auth/data/repositories/auth_repository.dart';
import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/trips/data/repositories/trip_repository.dart';
import '../../features/trips/presentation/bloc/trip_bloc.dart';

final getIt = GetIt.instance;

Future<void> setupDependencies() async {
  // External
  getIt.registerLazySingleton(() => const FlutterSecureStorage());

  // Core
  getIt.registerLazySingleton(() => ApiClient(getIt()));

  // Repositories
  getIt.registerLazySingleton(() => AuthRepository(getIt(), getIt()));
  getIt.registerLazySingleton(() => TripRepository(getIt()));

  // BLoCs
  getIt.registerFactory(() => AuthBloc(getIt()));
  getIt.registerFactory(() => TripBloc(getIt()));
}
