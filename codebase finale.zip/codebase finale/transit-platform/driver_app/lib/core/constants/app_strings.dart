class AppStrings {
  // App
  static const String appName = 'TRANS-IT Driver';
  static const String currency = 'TZS';
  
  // Auth
  static const String login = 'Login';
  static const String phoneOrEmail = 'Phone or Email';
  static const String password = 'Password';
  static const String rememberMe = 'Remember Me';
  static const String forgotPassword = 'Forgot Password?';
  static const String loginButton = 'Login';
  
  // Dashboard
  static const String welcome = 'Welcome';
  static const String todaysEarnings = 'Today\'s Earnings';
  static const String completedTrips = 'Completed Trips';
  static const String activeTrip = 'Active Trip';
  static const String noActiveTrip = 'No active trips';
  static const String startShift = 'Start Shift';
  
  // Trips
  static const String trips = 'Trips';
  static const String upcoming = 'Upcoming';
  static const String inProgress = 'In Progress';
  static const String completed = 'Completed';
  static const String tripDetails = 'Trip Details';
  static const String acceptTrip = 'Accept Trip';
  static const String startTrip = 'Start Trip';
  static const String completeTrip = 'Complete Trip';
  static const String viewRoute = 'View Route';
  
  // Navigation
  static const String navigate = 'Navigate';
  static const String directions = 'Directions';
  static const String distance = 'Distance';
  static const String duration = 'Duration';
  static const String arrive = 'Arrive';
  
  // Vehicle
  static const String vehicleInspection = 'Vehicle Inspection';
  static const String inspectionRequired = 'Daily inspection required';
  static const String submitInspection = 'Submit Inspection';
  
  // Earnings
  static const String earnings = 'Earnings';
  static const String totalEarnings = 'Total Earnings';
  static const String thisWeek = 'This Week';
  static const String thisMonth = 'This Month';
  static const String paymentHistory = 'Payment History';
  
  // Profile
  static const String profile = 'Profile';
  static const String personalInfo = 'Personal Information';
  static const String vehicleInfo = 'Vehicle Information';
  static const String documents = 'Documents';
  static const String settings = 'Settings';
  static const String logout = 'Logout';
  
  // Common
  static const String cancel = 'Cancel';
  static const String confirm = 'Confirm';
  static const String save = 'Save';
  static const String loading = 'Loading...';
  static const String error = 'Error';
  static const String retry = 'Retry';
  static const String noData = 'No data available';
}
