// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trip_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Trip _$TripFromJson(Map<String, dynamic> json) => Trip(
      id: json['id'] as String,
      pickupLocation:
          Location.fromJson(json['pickup_location'] as Map<String, dynamic>),
      deliveryLocation:
          Location.fromJson(json['delivery_location'] as Map<String, dynamic>),
      pickupTime: DateTime.parse(json['pickup_time'] as String),
      estimatedDeliveryTime:
          DateTime.parse(json['estimated_delivery_time'] as String),
      status: json['status'] as String,
      distance: (json['distance'] as num).toDouble(),
      fare: (json['fare'] as num).toDouble(),
      cargoDetails:
          CargoDetails.fromJson(json['cargo_details'] as Map<String, dynamic>),
      customerName: json['customer_name'] as String,
      customerPhone: json['customer_phone'] as String,
    );

Map<String, dynamic> _$TripToJson(Trip instance) => <String, dynamic>{
      'id': instance.id,
      'pickup_location': instance.pickupLocation,
      'delivery_location': instance.deliveryLocation,
      'pickup_time': instance.pickupTime.toIso8601String(),
      'estimated_delivery_time': instance.estimatedDeliveryTime.toIso8601String(),
      'status': instance.status,
      'distance': instance.distance,
      'fare': instance.fare,
      'cargo_details': instance.cargoDetails,
      'customer_name': instance.customerName,
      'customer_phone': instance.customerPhone,
    };

Location _$LocationFromJson(Map<String, dynamic> json) => Location(
      address: json['address'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
    );

Map<String, dynamic> _$LocationToJson(Location instance) => <String, dynamic>{
      'address': instance.address,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
    };

CargoDetails _$CargoDetailsFromJson(Map<String, dynamic> json) => CargoDetails(
      type: json['type'] as String,
      weight: (json['weight'] as num).toDouble(),
      description: json['description'] as String,
      specialInstructions: json['special_instructions'] as String?,
    );

Map<String, dynamic> _$CargoDetailsToJson(CargoDetails instance) =>
    <String, dynamic>{
      'type': instance.type,
      'weight': instance.weight,
      'description': instance.description,
      'special_instructions': instance.specialInstructions,
    };
