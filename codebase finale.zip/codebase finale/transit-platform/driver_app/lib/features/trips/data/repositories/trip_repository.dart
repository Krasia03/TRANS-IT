import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../models/trip_model.dart';

class TripRepository {
  final ApiClient _apiClient;

  TripRepository(this._apiClient);

  Future<List<Trip>> getTrips(String driverId, {String? status}) async {
    try {
      final queryParams = {
        'driver_id': driverId,
        if (status != null) 'status': status,
      };

      final response = await _apiClient.get(
        ApiEndpoints.trips,
        queryParameters: queryParams,
      );

      final List<dynamic> data = response.data['trips'];
      return data.map((json) => Trip.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to fetch trips: ${e.toString()}');
    }
  }

  Future<Trip> getTripDetails(String tripId) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.tripDetails(tripId));
      return Trip.fromJson(response.data);
    } catch (e) {
      throw Exception('Failed to fetch trip details: ${e.toString()}');
    }
  }

  Future<void> acceptTrip(String tripId) async {
    try {
      await _apiClient.post(ApiEndpoints.acceptTrip(tripId));
    } catch (e) {
      throw Exception('Failed to accept trip: ${e.toString()}');
    }
  }

  Future<void> startTrip(String tripId) async {
    try {
      await _apiClient.post(ApiEndpoints.startTrip(tripId));
    } catch (e) {
      throw Exception('Failed to start trip: ${e.toString()}');
    }
  }

  Future<void> completeTrip(String tripId) async {
    try {
      await _apiClient.post(ApiEndpoints.completeTrip(tripId));
    } catch (e) {
      throw Exception('Failed to complete trip: ${e.toString()}');
    }
  }
}
