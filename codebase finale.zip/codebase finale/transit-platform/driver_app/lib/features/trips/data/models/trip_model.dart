import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'trip_model.g.dart';

@JsonSerializable()
class Trip extends Equatable {
  final String id;
  
  @JsonKey(name: 'pickup_location')
  final Location pickupLocation;
  
  @JsonKey(name: 'delivery_location')
  final Location deliveryLocation;
  
  @JsonKey(name: 'pickup_time')
  final DateTime pickupTime;
  
  @JsonKey(name: 'estimated_delivery_time')
  final DateTime estimatedDeliveryTime;
  
  final String status;
  final double distance;
  final double fare;
  
  @JsonKey(name: 'cargo_details')
  final CargoDetails cargoDetails;
  
  @JsonKey(name: 'customer_name')
  final String customerName;
  
  @JsonKey(name: 'customer_phone')
  final String customerPhone;

  const Trip({
    required this.id,
    required this.pickupLocation,
    required this.deliveryLocation,
    required this.pickupTime,
    required this.estimatedDeliveryTime,
    required this.status,
    required this.distance,
    required this.fare,
    required this.cargoDetails,
    required this.customerName,
    required this.customerPhone,
  });

  factory Trip.fromJson(Map<String, dynamic> json) => _$TripFromJson(json);

  Map<String, dynamic> toJson() => _$TripToJson(this);

  @override
  List<Object?> get props => [
        id,
        pickupLocation,
        deliveryLocation,
        pickupTime,
        estimatedDeliveryTime,
        status,
        distance,
        fare,
        cargoDetails,
        customerName,
        customerPhone,
      ];
}

@JsonSerializable()
class Location extends Equatable {
  final String address;
  final double latitude;
  final double longitude;

  const Location({
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  factory Location.fromJson(Map<String, dynamic> json) =>
      _$LocationFromJson(json);

  Map<String, dynamic> toJson() => _$LocationToJson(this);

  @override
  List<Object?> get props => [address, latitude, longitude];
}

@JsonSerializable()
class CargoDetails extends Equatable {
  final String type;
  final double weight;
  final String description;
  
  @JsonKey(name: 'special_instructions')
  final String? specialInstructions;

  const CargoDetails({
    required this.type,
    required this.weight,
    required this.description,
    this.specialInstructions,
  });

  factory CargoDetails.fromJson(Map<String, dynamic> json) =>
      _$CargoDetailsFromJson(json);

  Map<String, dynamic> toJson() => _$CargoDetailsToJson(this);

  @override
  List<Object?> get props => [type, weight, description, specialInstructions];
}
