import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../../../shared/widgets/error_widget.dart' as custom;
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../bloc/trip_bloc.dart';
import '../widgets/trip_card.dart';

class TripsListPage extends StatefulWidget {
  const TripsListPage({super.key});

  @override
  State<TripsListPage> createState() => _TripsListPageState();
}

class _TripsListPageState extends State<TripsListPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadTrips();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _loadTrips() {
    final authState = context.read<AuthBloc>().state;
    if (authState is AuthAuthenticated) {
      context.read<TripBloc>().add(
            TripsFetchRequested(driverId: authState.driver.id),
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.trips),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: AppStrings.upcoming),
            Tab(text: AppStrings.inProgress),
            Tab(text: AppStrings.completed),
          ],
        ),
      ),
      body: BlocBuilder<TripBloc, TripState>(
        builder: (context, state) {
          if (state is TripLoading) {
            return const LoadingIndicator();
          }

          if (state is TripError) {
            return custom.ErrorWidget(
              message: state.message,
              onRetry: _loadTrips,
            );
          }

          if (state is TripsLoaded) {
            return TabBarView(
              controller: _tabController,
              children: [
                _buildTripsList(
                  state.trips.where((t) => t.status == 'pending').toList(),
                ),
                _buildTripsList(
                  state.trips.where((t) => t.status == 'in_progress').toList(),
                ),
                _buildTripsList(
                  state.trips.where((t) => t.status == 'completed').toList(),
                ),
              ],
            );
          }

          return const Center(child: Text(AppStrings.noData));
        },
      ),
    );
  }

  Widget _buildTripsList(List trips) {
    if (trips.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox_outlined,
              size: 64,
              color: AppColors.textTertiary,
            ),
            const SizedBox(height: 16),
            Text(
              'No trips found',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppColors.textSecondary,
                  ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async => _loadTrips(),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: trips.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          return TripCard(trip: trips[index]);
        },
      ),
    );
  }
}
