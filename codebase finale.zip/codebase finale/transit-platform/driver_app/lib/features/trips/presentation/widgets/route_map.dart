import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../../core/constants/app_colors.dart';
import '../../data/models/trip_model.dart';

class RouteMap extends StatefulWidget {
  final Location pickupLocation;
  final Location deliveryLocation;

  const RouteMap({
    super.key,
    required this.pickupLocation,
    required this.deliveryLocation,
  });

  @override
  State<RouteMap> createState() => _RouteMapState();
}

class _RouteMapState extends State<RouteMap> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};

  @override
  void initState() {
    super.initState();
    _setupMarkers();
  }

  void _setupMarkers() {
    _markers = {
      Marker(
        markerId: const MarkerId('pickup'),
        position: LatLng(
          widget.pickupLocation.latitude,
          widget.pickupLocation.longitude,
        ),
        infoWindow: InfoWindow(
          title: 'Pickup',
          snippet: widget.pickupLocation.address,
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
      ),
      Marker(
        markerId: const MarkerId('delivery'),
        position: LatLng(
          widget.deliveryLocation.latitude,
          widget.deliveryLocation.longitude,
        ),
        infoWindow: InfoWindow(
          title: 'Delivery',
          snippet: widget.deliveryLocation.address,
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      ),
    };

    // Create a simple polyline between pickup and delivery
    _polylines = {
      Polyline(
        polylineId: const PolylineId('route'),
        points: [
          LatLng(
            widget.pickupLocation.latitude,
            widget.pickupLocation.longitude,
          ),
          LatLng(
            widget.deliveryLocation.latitude,
            widget.deliveryLocation.longitude,
          ),
        ],
        color: AppColors.primary,
        width: 4,
      ),
    };
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    _fitBounds();
  }

  void _fitBounds() {
    if (_mapController == null) return;

    final bounds = LatLngBounds(
      southwest: LatLng(
        widget.pickupLocation.latitude < widget.deliveryLocation.latitude
            ? widget.pickupLocation.latitude
            : widget.deliveryLocation.latitude,
        widget.pickupLocation.longitude < widget.deliveryLocation.longitude
            ? widget.pickupLocation.longitude
            : widget.deliveryLocation.longitude,
      ),
      northeast: LatLng(
        widget.pickupLocation.latitude > widget.deliveryLocation.latitude
            ? widget.pickupLocation.latitude
            : widget.deliveryLocation.latitude,
        widget.pickupLocation.longitude > widget.deliveryLocation.longitude
            ? widget.pickupLocation.longitude
            : widget.deliveryLocation.longitude,
      ),
    );

    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 50),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GoogleMap(
      onMapCreated: _onMapCreated,
      initialCameraPosition: CameraPosition(
        target: LatLng(
          widget.pickupLocation.latitude,
          widget.pickupLocation.longitude,
        ),
        zoom: 12,
      ),
      markers: _markers,
      polylines: _polylines,
      myLocationEnabled: true,
      myLocationButtonEnabled: true,
      zoomControlsEnabled: false,
      mapToolbarEnabled: false,
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
