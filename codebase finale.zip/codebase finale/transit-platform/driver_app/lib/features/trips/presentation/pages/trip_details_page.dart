import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../shared/widgets/custom_button.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../bloc/trip_bloc.dart';
import '../widgets/route_map.dart';
import '../../data/models/trip_model.dart';

class TripDetailsPage extends StatelessWidget {
  final String tripId;

  const TripDetailsPage({super.key, required this.tripId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.tripDetails),
        actions: [
          IconButton(
            icon: const Icon(Icons.phone),
            onPressed: () {
              // TODO: Call customer
            },
          ),
        ],
      ),
      body: BlocBuilder<TripBloc, TripState>(
        builder: (context, state) {
          if (state is TripLoading) {
            return const LoadingIndicator();
          }

          if (state is TripDetailsLoaded) {
            return _buildTripDetails(context, state.trip);
          }

          return const Center(child: Text('Trip not found'));
        },
      ),
    );
  }

  Widget _buildTripDetails(BuildContext context, Trip trip) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Map
          SizedBox(
            height: 250,
            child: RouteMap(
              pickupLocation: trip.pickupLocation,
              deliveryLocation: trip.deliveryLocation,
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Status and Fare
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildStatusChip(context, trip.status),
                    Text(
                      CurrencyFormatter.format(trip.fare),
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            color: AppColors.success,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Locations
                Text(
                  'Route Details',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 16),
                _buildLocationCard(
                  context,
                  Icons.radio_button_checked,
                  'Pickup Location',
                  trip.pickupLocation.address,
                  DateFormatter.formatDateTime(trip.pickupTime),
                  AppColors.primary,
                ),
                const SizedBox(height: 12),
                _buildLocationCard(
                  context,
                  Icons.location_on,
                  'Delivery Location',
                  trip.deliveryLocation.address,
                  DateFormatter.formatDateTime(trip.estimatedDeliveryTime),
                  AppColors.error,
                ),
                const SizedBox(height: 24),

                // Cargo Details
                Text(
                  'Cargo Information',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildInfoRow('Type', trip.cargoDetails.type),
                        const Divider(),
                        _buildInfoRow(
                          'Weight',
                          '${trip.cargoDetails.weight} kg',
                        ),
                        const Divider(),
                        _buildInfoRow(
                          'Description',
                          trip.cargoDetails.description,
                        ),
                        if (trip.cargoDetails.specialInstructions != null) ...[
                          const Divider(),
                          _buildInfoRow(
                            'Special Instructions',
                            trip.cargoDetails.specialInstructions!,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Customer Details
                Text(
                  'Customer Information',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildInfoRow('Name', trip.customerName),
                        const Divider(),
                        _buildInfoRow('Phone', trip.customerPhone),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Action Buttons
                _buildActionButtons(context, trip),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(BuildContext context, String status) {
    Color color;
    String label;

    switch (status) {
      case 'pending':
        color = AppColors.tripPending;
        label = 'Pending';
        break;
      case 'in_progress':
        color = AppColors.tripInProgress;
        label = 'In Progress';
        break;
      case 'completed':
        color = AppColors.tripCompleted;
        label = 'Completed';
        break;
      default:
        color = AppColors.textSecondary;
        label = status;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
      ),
    );
  }

  Widget _buildLocationCard(
    BuildContext context,
    IconData icon,
    String label,
    String address,
    String time,
    Color color,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textTertiary,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    address,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    time,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, Trip trip) {
    if (trip.status == 'pending') {
      return CustomButton(
        text: AppStrings.acceptTrip,
        onPressed: () {
          context.read<TripBloc>().add(TripAcceptRequested(trip.id));
        },
      );
    }

    if (trip.status == 'in_progress') {
      return Column(
        children: [
          CustomButton(
            text: 'Navigate',
            onPressed: () {
              context.push('/navigation/${trip.id}');
            },
            icon: Icons.navigation,
          ),
          const SizedBox(height: 12),
          CustomButton(
            text: AppStrings.completeTrip,
            onPressed: () {
              _showCompleteDialog(context, trip);
            },
          ),
        ],
      );
    }

    return const SizedBox.shrink();
  }

  void _showCompleteDialog(BuildContext context, Trip trip) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Complete Trip'),
        content: const Text('Are you sure you want to mark this trip as completed?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              context.read<TripBloc>().add(TripCompleteRequested(trip.id));
            },
            child: const Text(AppStrings.confirm),
          ),
        ],
      ),
    );
  }
}
