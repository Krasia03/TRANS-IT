import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../data/models/trip_model.dart';
import '../../data/repositories/trip_repository.dart';

// Events
abstract class TripEvent extends Equatable {
  const TripEvent();

  @override
  List<Object?> get props => [];
}

class TripsFetchRequested extends TripEvent {
  final String driverId;
  final String? status;

  const TripsFetchRequested({
    required this.driverId,
    this.status,
  });

  @override
  List<Object?> get props => [driverId, status];
}

class TripDetailsFetchRequested extends TripEvent {
  final String tripId;

  const TripDetailsFetchRequested(this.tripId);

  @override
  List<Object?> get props => [tripId];
}

class TripAcceptRequested extends TripEvent {
  final String tripId;

  const TripAcceptRequested(this.tripId);

  @override
  List<Object?> get props => [tripId];
}

class TripStartRequested extends TripEvent {
  final String tripId;

  const TripStartRequested(this.tripId);

  @override
  List<Object?> get props => [tripId];
}

class TripCompleteRequested extends TripEvent {
  final String tripId;

  const TripCompleteRequested(this.tripId);

  @override
  List<Object?> get props => [tripId];
}

// States
abstract class TripState extends Equatable {
  const TripState();

  @override
  List<Object?> get props => [];
}

class TripInitial extends TripState {}

class TripLoading extends TripState {}

class TripsLoaded extends TripState {
  final List<Trip> trips;

  const TripsLoaded(this.trips);

  @override
  List<Object?> get props => [trips];
}

class TripDetailsLoaded extends TripState {
  final Trip trip;

  const TripDetailsLoaded(this.trip);

  @override
  List<Object?> get props => [trip];
}

class TripActionSuccess extends TripState {
  final String message;

  const TripActionSuccess(this.message);

  @override
  List<Object?> get props => [message];
}

class TripError extends TripState {
  final String message;

  const TripError(this.message);

  @override
  List<Object?> get props => [message];
}

// BLoC
class TripBloc extends Bloc<TripEvent, TripState> {
  final TripRepository _tripRepository;

  TripBloc(this._tripRepository) : super(TripInitial()) {
    on<TripsFetchRequested>(_onTripsFetchRequested);
    on<TripDetailsFetchRequested>(_onTripDetailsFetchRequested);
    on<TripAcceptRequested>(_onTripAcceptRequested);
    on<TripStartRequested>(_onTripStartRequested);
    on<TripCompleteRequested>(_onTripCompleteRequested);
  }

  Future<void> _onTripsFetchRequested(
    TripsFetchRequested event,
    Emitter<TripState> emit,
  ) async {
    emit(TripLoading());
    try {
      final trips = await _tripRepository.getTrips(
        event.driverId,
        status: event.status,
      );
      emit(TripsLoaded(trips));
    } catch (e) {
      emit(TripError(e.toString()));
    }
  }

  Future<void> _onTripDetailsFetchRequested(
    TripDetailsFetchRequested event,
    Emitter<TripState> emit,
  ) async {
    emit(TripLoading());
    try {
      final trip = await _tripRepository.getTripDetails(event.tripId);
      emit(TripDetailsLoaded(trip));
    } catch (e) {
      emit(TripError(e.toString()));
    }
  }

  Future<void> _onTripAcceptRequested(
    TripAcceptRequested event,
    Emitter<TripState> emit,
  ) async {
    emit(TripLoading());
    try {
      await _tripRepository.acceptTrip(event.tripId);
      emit(const TripActionSuccess('Trip accepted successfully'));
    } catch (e) {
      emit(TripError(e.toString()));
    }
  }

  Future<void> _onTripStartRequested(
    TripStartRequested event,
    Emitter<TripState> emit,
  ) async {
    emit(TripLoading());
    try {
      await _tripRepository.startTrip(event.tripId);
      emit(const TripActionSuccess('Trip started successfully'));
    } catch (e) {
      emit(TripError(e.toString()));
    }
  }

  Future<void> _onTripCompleteRequested(
    TripCompleteRequested event,
    Emitter<TripState> emit,
  ) async {
    emit(TripLoading());
    try {
      await _tripRepository.completeTrip(event.tripId);
      emit(const TripActionSuccess('Trip completed successfully'));
    } catch (e) {
      emit(TripError(e.toString()));
    }
  }
}
