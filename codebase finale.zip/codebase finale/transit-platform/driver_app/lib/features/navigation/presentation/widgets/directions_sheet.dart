import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';

class DirectionsSheet extends StatelessWidget {
  const DirectionsSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.15,
      minChildSize: 0.15,
      maxChildSize: 0.6,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 10,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              // Handle
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.textTertiary,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Header
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Turn-by-turn directions',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    Icon(Icons.expand_less, color: AppColors.textSecondary),
                  ],
                ),
              ),

              Divider(color: AppColors.divider),

              // Directions List
              Expanded(
                child: ListView(
                  controller: scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _buildDirectionStep(
                      context,
                      Icons.turn_right,
                      'Turn right',
                      'Morogoro Road',
                      '500 m',
                      true,
                    ),
                    _buildDirectionStep(
                      context,
                      Icons.straight,
                      'Continue straight',
                      'Morogoro Road',
                      '2.3 km',
                      false,
                    ),
                    _buildDirectionStep(
                      context,
                      Icons.turn_left,
                      'Turn left',
                      'Nyerere Road',
                      '1.5 km',
                      false,
                    ),
                    _buildDirectionStep(
                      context,
                      Icons.turn_slight_right,
                      'Slight right',
                      'Ali Hassan Mwinyi Road',
                      '3.2 km',
                      false,
                    ),
                    _buildDirectionStep(
                      context,
                      Icons.location_on,
                      'Arrive at destination',
                      'Tegeta Beach',
                      '5.0 km',
                      false,
                      isLast: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDirectionStep(
    BuildContext context,
    IconData icon,
    String instruction,
    String street,
    String distance,
    bool isActive, {
    bool isLast = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: isLast
              ? BorderSide.none
              : BorderSide(color: AppColors.divider),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isActive
                  ? AppColors.primary.withOpacity(0.1)
                  : AppColors.background,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: isActive ? AppColors.primary : AppColors.textSecondary,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  instruction,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                      ),
                ),
                const SizedBox(height: 2),
                Text(
                  street,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
              ],
            ),
          ),
          Text(
            distance,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: isActive ? AppColors.primary : AppColors.textSecondary,
                ),
          ),
        ],
      ),
    );
  }
}
