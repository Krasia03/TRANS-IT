import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'login_model.g.dart';

@JsonSerializable()
class LoginRequest {
  final String username;
  final String password;

  const LoginRequest({
    required this.username,
    required this.password,
  });

  factory LoginRequest.fromJson(Map<String, dynamic> json) =>
      _$LoginRequestFromJson(json);

  Map<String, dynamic> toJson() => _$LoginRequestToJson(this);
}

@JsonSerializable()
class LoginResponse extends Equatable {
  @JsonKey(name: 'access_token')
  final String accessToken;
  
  @JsonKey(name: 'refresh_token')
  final String refreshToken;
  
  final Driver driver;

  const LoginResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.driver,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) =>
      _$LoginResponseFromJson(json);

  Map<String, dynamic> toJson() => _$LoginResponseToJson(this);

  @override
  List<Object?> get props => [accessToken, refreshToken, driver];
}

@JsonSerializable()
class Driver extends Equatable {
  final String id;
  final String name;
  final String email;
  final String phone;
  
  @JsonKey(name: 'profile_photo')
  final String? profilePhoto;
  
  final double rating;
  
  @JsonKey(name: 'total_trips')
  final int totalTrips;
  
  @JsonKey(name: 'vehicle_id')
  final String? vehicleId;

  const Driver({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.profilePhoto,
    required this.rating,
    required this.totalTrips,
    this.vehicleId,
  });

  factory Driver.fromJson(Map<String, dynamic> json) =>
      _$DriverFromJson(json);

  Map<String, dynamic> toJson() => _$DriverToJson(this);

  @override
  List<Object?> get props => [
        id,
        name,
        email,
        phone,
        profilePhoto,
        rating,
        totalTrips,
        vehicleId,
      ];
}
