import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../models/login_model.dart';

class AuthRepository {
  final ApiClient _apiClient;
  final FlutterSecureStorage _secureStorage;

  AuthRepository(this._apiClient, this._secureStorage);

  Future<LoginResponse> login(String username, String password) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.login,
        data: LoginRequest(username: username, password: password).toJson(),
      );

      final loginResponse = LoginResponse.fromJson(response.data);

      // Store tokens
      await _secureStorage.write(
        key: 'access_token',
        value: loginResponse.accessToken,
      );
      await _secureStorage.write(
        key: 'refresh_token',
        value: loginResponse.refreshToken,
      );
      await _secureStorage.write(
        key: 'driver_id',
        value: loginResponse.driver.id,
      );

      return loginResponse;
    } catch (e) {
      throw Exception('Login failed: ${e.toString()}');
    }
  }

  Future<void> logout() async {
    try {
      await _apiClient.post(ApiEndpoints.logout);
    } catch (e) {
      // Continue with local logout even if API call fails
    } finally {
      await _secureStorage.deleteAll();
    }
  }

  Future<bool> isLoggedIn() async {
    final token = await _secureStorage.read(key: 'access_token');
    return token != null;
  }

  Future<String?> getDriverId() async {
    return await _secureStorage.read(key: 'driver_id');
  }
}
