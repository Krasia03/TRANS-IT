import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';

class InspectionChecklist extends StatefulWidget {
  const InspectionChecklist({super.key});

  @override
  State<InspectionChecklist> createState() => _InspectionChecklistState();
}

class _InspectionChecklistState extends State<InspectionChecklist> {
  final Map<String, bool> _checklistItems = {
    'Tires and tire pressure': false,
    'Brakes functionality': false,
    'Engine oil level': false,
    'Coolant level': false,
    'Lights (headlights, taillights, indicators)': false,
    'Windshield and wipers': false,
    'Side mirrors': false,
    'Seat belts': false,
    'Horn': false,
    'Fire extinguisher': false,
    'First aid kit': false,
    'Warning triangle': false,
    'Vehicle registration and insurance': false,
    'Cargo area cleanliness': false,
  };

  @override
  Widget build(BuildContext context) {
    final completedCount = _checklistItems.values.where((v) => v).length;
    final totalCount = _checklistItems.length;
    final progress = completedCount / totalCount;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Progress
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Inspection Progress',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            Text(
              '$completedCount / $totalCount',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                  ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 8,
            backgroundColor: AppColors.border,
            valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
          ),
        ),
        const SizedBox(height: 24),

        // Checklist Items
        Text(
          'Inspection Items',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              children: _checklistItems.entries.map((entry) {
                return _buildChecklistItem(
                  entry.key,
                  entry.value,
                  (value) {
                    setState(() {
                      _checklistItems[entry.key] = value;
                    });
                  },
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildChecklistItem(
    String title,
    bool isChecked,
    ValueChanged<bool> onChanged,
  ) {
    return CheckboxListTile(
      title: Text(
        title,
        style: TextStyle(
          decoration: isChecked ? TextDecoration.lineThrough : null,
          color: isChecked ? AppColors.textSecondary : AppColors.textPrimary,
        ),
      ),
      value: isChecked,
      onChanged: (value) => onChanged(value ?? false),
      activeColor: AppColors.success,
      controlAffinity: ListTileControlAffinity.leading,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}
