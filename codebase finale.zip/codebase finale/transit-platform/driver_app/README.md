# TRANS-IT Driver App

A Flutter mobile application for drivers in the TRANS-IT fleet/logistics management platform.

## Features

- **Authentication**: Secure login with phone/email and password
- **Dashboard**: Overview of earnings, completed trips, and active trips
- **Trip Management**: View upcoming, in-progress, and completed trips
- **Real-time Navigation**: Turn-by-turn navigation with Google Maps
- **Vehicle Inspection**: Daily vehicle inspection checklist
- **Earnings Tracking**: View earnings with weekly/monthly charts
- **Profile Management**: View and manage driver profile

## Design System

- **Primary Color**: Royal Blue (#2563EB)
- **Accent Color**: Golden Yellow (#F5C842)
- **Currency**: TZS (Tanzanian Shilling)

## Tech Stack

- **Framework**: Flutter 3.0+
- **State Management**: BLoC (flutter_bloc)
- **Navigation**: GoRouter
- **HTTP Client**: Dio
- **Local Storage**: Hive + Flutter Secure Storage
- **Maps**: Google Maps Flutter
- **Location**: Geolocator
- **Dependency Injection**: GetIt

## Project Structure

```
lib/
├── core/                    # Core utilities and configuration
│   ├── constants/          # App colors, strings
│   ├── theme/              # App theme
│   ├── utils/              # Formatters, helpers
│   ├── network/            # API client, endpoints
│   └── di/                 # Dependency injection
├── features/               # Feature modules
│   ├── auth/              # Authentication
│   ├── dashboard/         # Dashboard
│   ├── trips/             # Trip management
│   ├── navigation/        # Real-time navigation
│   ├── vehicle/           # Vehicle inspection
│   ├── earnings/          # Earnings tracking
│   └── profile/           # Profile management
└── shared/                # Shared widgets and utilities
    ├── widgets/           # Reusable widgets
    └── routes/            # App routing
```

## Getting Started

### Prerequisites

- Flutter SDK 3.0 or higher
- Dart SDK 3.0 or higher
- Android Studio / VS Code
- Google Maps API Key

### Installation

1. Clone the repository
```bash
cd transit-platform/driver_app
```

2. Install dependencies
```bash
flutter pub get
```

3. Generate code
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

4. Configure Google Maps API Key

**Android** (`android/app/src/main/AndroidManifest.xml`):
```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_API_KEY_HERE"/>
```

**iOS** (`ios/Runner/AppDelegate.swift`):
```swift
GMSServices.provideAPIKey("YOUR_API_KEY_HERE")
```

5. Run the app
```bash
flutter run
```

## API Configuration

Update the base URL in `lib/core/network/api_endpoints.dart`:

```dart
static const String baseUrl = 'YOUR_API_BASE_URL';
```

## Build

### Android APK
```bash
flutter build apk --release
```

### iOS IPA
```bash
flutter build ios --release
```

## Code Generation

When you modify model files with JSON serialization:

```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

## Testing

```bash
flutter test
```

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests and linting
4. Submit a pull request

## License

Copyright © 2024 TRANS-IT Platform. All rights reserved.
