-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Utility Functions
-- =====================================================

-- Generate tracking number for cargo
CREATE OR REPLACE FUNCTION generate_tracking_number()
RETURNS VARCHAR AS $$
DECLARE
    v_prefix VARCHAR := 'TRT';
    v_timestamp VARCHAR := to_char(NOW(), 'YYMMDD');
    v_random VARCHAR := upper(substr(md5(random()::text, 1, 6));
BEGIN
    RETURN v_prefix || '-' || v_timestamp || '-' || v_random;
END;
$$ LANGUAGE plpgsql;

-- Generate invoice number
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS VARCHAR AS $$
DECLARE
    v_year VARCHAR := to_char(NOW(), 'YYYY');
    v_seq INTEGER;
BEGIN
    SELECT COALESCE(MAX(CAST(SUBSTRING(invoice_number FROM 10) AS INTEGER)), 0) + 1
    INTO v_seq
    FROM invoices
    WHERE invoice_number LIKE 'INV-' || v_year || '-%';
    RETURN 'INV-' || v_year || '-' || LPAD(v_seq::TEXT, 5, '0');
END;
$$ LANGUAGE plpgsql;

-- Calculate estimated delivery price based on distance and zones
CREATE OR REPLACE FUNCTION calculate_delivery_price(
    p_origin_h3 VARCHAR,
    p_destination_h3 VARCHAR,
    p_weight DECIMAL,
    p_category cargo_category
)
RETURNS DECIMAL AS $$
DECLARE
    v_base_price DECIMAL := 50000;
    v_price_per_km DECIMAL := 150;
    v_distance_km DECIMAL;
    v_category_multiplier DECIMAL := 1.0;
    v_total DECIMAL;
BEGIN
    SELECT INTO v_distance_km AVG(
        ST_Distance(
            ST_SetSRID(ST_MakePoint(origin_longitude, origin_latitude), 4326)::GEOGRAPHY,
            ST_SetSRID(ST_MakePoint(dest_longitude, dest_latitude), 4326)::GEOGRAPHY
        ) / 1000
    )
    FROM routes WHERE origin_h3 = p_origin_h3 AND destination_h3 = p_destination_h3;

    IF v_distance_km IS NULL THEN
        v_distance_km := 500;
    END IF;

    CASE p_category
        WHEN 'fragile' THEN v_category_multiplier := 1.5;
        WHEN 'perishable' THEN v_category_multiplier := 2.0;
        WHEN 'hazardous' THEN v_category_multiplier := 2.5;
        WHEN 'oversized' THEN v_category_multiplier := 2.0;
        ELSE v_category_multiplier := 1.0;
    END CASE;

    v_total := (v_base_price + (v_distance_km * v_price_per_km)) * v_category_multiplier;
    v_total := ROUND(v_total, -2);

    RETURN v_total;
END;
$$ LANGUAGE plpgsql;

-- Calculate driver payroll for period
CREATE OR REPLACE FUNCTION calculate_driver_payroll(
    p_driver_id UUID,
    p_period_start DATE,
    p_period_end DATE
)
RETURNS TABLE (
    base_salary DECIMAL,
    trip_bonus DECIMAL,
    total_trips INTEGER,
    total_distance DECIMAL,
    net_pay DECIMAL
) AS $$
DECLARE
    v_base_salary DECIMAL := 1500000;
    v_trip_count INTEGER;
    v_total_distance DECIMAL;
    v_bonus DECIMAL;
BEGIN
    SELECT COUNT(*), COALESCE(SUM(distance_km), 0)
    INTO v_trip_count, v_total_distance
    FROM dispatch_orders
    WHERE driver_id = p_driver_id
    AND status = 'completed'
    AND completed_at BETWEEN p_period_start AND p_period_end;

    v_bonus := v_trip_count * 15000;

    IF v_total_distance > 2000 THEN
        v_bonus := v_bonus + (v_total_distance - 2000) * 100;
    END IF;

    RETURN QUERY SELECT
        v_base_salary,
        v_bonus,
        v_trip_count,
        v_total_distance,
        v_base_salary + v_bonus - (v_base_salary * 0.1);
END;
$$ LANGUAGE plpgsql;

-- Update escrow balance
CREATE OR REPLACE FUNCTION update_escrow_balance(
    p_escrow_id UUID,
    p_amount DECIMAL,
    p_operation VARCHAR
)
RETURNS VOID AS $$
BEGIN
    IF p_operation = 'hold' THEN
        UPDATE escrow_accounts
        SET balance = balance - p_amount,
            held_amount = held_amount + p_amount,
            updated_at = NOW()
        WHERE id = p_escrow_id;
    ELSIF p_operation = 'release' THEN
        UPDATE escrow_accounts
        SET held_amount = held_amount - p_amount,
            updated_at = NOW()
        WHERE id = p_escrow_id;
    ELSIF p_operation = 'refund' THEN
        UPDATE escrow_accounts
        SET balance = balance + p_amount,
            held_amount = held_amount - p_amount,
            updated_at = NOW()
        WHERE id = p_escrow_id;
    ELSIF p_operation = 'deposit' THEN
        UPDATE escrow_accounts
        SET balance = balance + p_amount,
            updated_at = NOW()
        WHERE id = p_escrow_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Check vehicle availability
CREATE OR REPLACE FUNCTION check_vehicle_availability(p_vehicle_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_status vehicle_status;
BEGIN
    SELECT status INTO v_status FROM vehicles WHERE id = p_vehicle_id;
    RETURN v_status = 'available';
END;
$$ LANGUAGE plpgsql;

-- Update vehicle status based on active dispatch
CREATE OR REPLACE FUNCTION update_vehicle_status(p_driver_id UUID)
RETURNS VOID AS $$
DECLARE
    v_active_dispatch INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_active_dispatch
    FROM dispatch_orders
    WHERE driver_id = p_driver_id
    AND status = 'in_progress';

    IF v_active_dispatch > 0 THEN
        UPDATE vehicles SET status = 'in_use'
        WHERE id = (SELECT vehicle_id FROM vehicle_assignments WHERE driver_id = p_driver_id AND status = 'active');
    ELSE
        UPDATE vehicles SET status = 'available'
        WHERE id = (SELECT vehicle_id FROM vehicle_assignments WHERE driver_id = p_driver_id AND status = 'active');
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Get route with H3 zone info
CREATE OR REPLACE FUNCTION get_route_details(p_route_id UUID)
RETURNS TABLE (
    route_name VARCHAR,
    origin_name VARCHAR,
    destination_name VARCHAR,
    distance_km DECIMAL,
    origin_h3 VARCHAR,
    destination_h3 VARCHAR,
    estimated_duration INTEGER
) AS $$
BEGIN
    RETURN QUERY SELECT
        r.name,
        r.origin_address,
        r.destination_address,
        r.distance_km,
        r.origin_h3,
        r.destination_h3,
        r.estimated_duration_minutes
    FROM routes r WHERE r.id = p_route_id;
END;
$$ LANGUAGE plpgsql;
