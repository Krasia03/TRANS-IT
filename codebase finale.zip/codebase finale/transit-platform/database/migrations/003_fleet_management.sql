-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 003: Fleet Management (6 modules)
-- =====================================================

-- Vehicles table
CREATE TABLE vehicles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vin VARCHAR(17) UNIQUE,
    registration_number VARCHAR(50) NOT NULL UNIQUE,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INTEGER NOT NULL,
    capacity_kg NUMERIC(10, 2) NOT NULL,
    fuel_type fuel_type NOT NULL,
    status vehicle_status NOT NULL DEFAULT 'active',
    mileage INTEGER NOT NULL DEFAULT 0,
    insurance_expiry DATE NOT NULL,
    registration_expiry DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT chk_year CHECK (year >= 1900 AND year <= EXTRACT(YEAR FROM CURRENT_DATE) + 1),
    CONSTRAINT chk_capacity CHECK (capacity_kg > 0),
    CONSTRAINT chk_mileage CHECK (mileage >= 0)
);

-- Vehicle maintenance records
CREATE TABLE vehicle_maintenance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    maintenance_type maintenance_type NOT NULL,
    description TEXT NOT NULL,
    cost_tzs NUMERIC(12, 2) NOT NULL DEFAULT 0,
    service_date DATE NOT NULL,
    next_service_date DATE,
    mechanic_id UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_cost CHECK (cost_tzs >= 0),
    CONSTRAINT chk_service_dates CHECK (next_service_date IS NULL OR next_service_date > service_date)
);

-- Fuel transactions
CREATE TABLE fuel_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    driver_id UUID REFERENCES users(id) ON DELETE SET NULL,
    liters NUMERIC(8, 2) NOT NULL,
    cost_tzs NUMERIC(12, 2) NOT NULL,
    station VARCHAR(255) NOT NULL,
    odometer_reading INTEGER NOT NULL,
    transaction_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_liters CHECK (liters > 0),
    CONSTRAINT chk_fuel_cost CHECK (cost_tzs > 0),
    CONSTRAINT chk_odometer CHECK (odometer_reading >= 0)
);

-- Vehicle inspections
CREATE TABLE vehicle_inspections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    inspector_id UUID REFERENCES users(id) ON DELETE SET NULL,
    inspection_type inspection_type NOT NULL,
    passed BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    inspection_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Vehicle locations (real-time GPS tracking with H3 indexing)
CREATE TABLE vehicle_locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    location_h3 VARCHAR(15) NOT NULL,
    lat NUMERIC(10, 8) NOT NULL,
    lng NUMERIC(11, 8) NOT NULL,
    speed NUMERIC(5, 2) DEFAULT 0,
    heading INTEGER DEFAULT 0,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_lat CHECK (lat >= -90 AND lat <= 90),
    CONSTRAINT chk_lng CHECK (lng >= -180 AND lng <= 180),
    CONSTRAINT chk_speed CHECK (speed >= 0),
    CONSTRAINT chk_heading CHECK (heading >= 0 AND heading < 360)
);

-- Vehicle assignments (linking vehicles to drivers)
CREATE TABLE vehicle_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    unassigned_at TIMESTAMP WITH TIME ZONE,
    status vehicle_status NOT NULL DEFAULT 'active',
    
    CONSTRAINT chk_assignment_dates CHECK (unassigned_at IS NULL OR unassigned_at > assigned_at)
);

-- =====================================================
-- INDEXES
-- =====================================================

CREATE INDEX idx_vehicles_registration ON vehicles(registration_number);
CREATE INDEX idx_vehicles_status ON vehicles(status);
CREATE INDEX idx_vehicles_insurance_expiry ON vehicles(insurance_expiry);
CREATE INDEX idx_vehicles_deleted_at ON vehicles(deleted_at);

CREATE INDEX idx_vehicle_maintenance_vehicle_id ON vehicle_maintenance(vehicle_id);
CREATE INDEX idx_vehicle_maintenance_service_date ON vehicle_maintenance(service_date);
CREATE INDEX idx_vehicle_maintenance_next_service ON vehicle_maintenance(next_service_date);

CREATE INDEX idx_fuel_transactions_vehicle_id ON fuel_transactions(vehicle_id);
CREATE INDEX idx_fuel_transactions_driver_id ON fuel_transactions(driver_id);
CREATE INDEX idx_fuel_transactions_date ON fuel_transactions(transaction_date);

CREATE INDEX idx_vehicle_inspections_vehicle_id ON vehicle_inspections(vehicle_id);
CREATE INDEX idx_vehicle_inspections_date ON vehicle_inspections(inspection_date);
CREATE INDEX idx_vehicle_inspections_passed ON vehicle_inspections(passed);

CREATE INDEX idx_vehicle_locations_vehicle_id ON vehicle_locations(vehicle_id);
CREATE INDEX idx_vehicle_locations_h3 ON vehicle_locations(location_h3);
CREATE INDEX idx_vehicle_locations_timestamp ON vehicle_locations(timestamp DESC);
CREATE INDEX idx_vehicle_locations_vehicle_time ON vehicle_locations(vehicle_id, timestamp DESC);

CREATE INDEX idx_vehicle_assignments_vehicle_id ON vehicle_assignments(vehicle_id);
CREATE INDEX idx_vehicle_assignments_driver_id ON vehicle_assignments(driver_id);
CREATE INDEX idx_vehicle_assignments_status ON vehicle_assignments(status);

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON TABLE vehicles IS 'Core fleet vehicle registry';
COMMENT ON TABLE vehicle_maintenance IS 'Maintenance history and scheduling';
COMMENT ON TABLE fuel_transactions IS 'Fuel consumption tracking (costs in TZS)';
COMMENT ON TABLE vehicle_locations IS 'Real-time GPS tracking with H3 geospatial indexing';
COMMENT ON COLUMN vehicle_locations.location_h3 IS 'H3 hexagonal index for efficient geospatial queries';
