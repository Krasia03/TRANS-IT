-- ============================================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 002: ENUM Types
-- ============================================================================

-- User roles
CREATE TYPE user_role AS ENUM (
    'super_admin',
    'admin',
    'fleet_manager',
    'dispatcher',
    'driver',
    'warehouse_manager',
    'warehouse_staff',
    'accountant',
    'customer_support',
    'corporate_client',
    'individual_client'
);

-- Generic status types
CREATE TYPE generic_status AS ENUM (
    'active',
    'inactive',
    'suspended',
    'deleted'
);

-- Vehicle status
CREATE TYPE vehicle_status AS ENUM (
    'available',
    'in_use',
    'maintenance',
    'out_of_service',
    'retired'
);

-- Vehicle fuel types
CREATE TYPE fuel_type AS ENUM (
    'petrol',
    'diesel',
    'electric',
    'hybrid',
    'cng',
    'lpg'
);

-- Maintenance types
CREATE TYPE maintenance_type AS ENUM (
    'routine',
    'repair',
    'emergency',
    'inspection',
    'upgrade'
);

-- Driver status
CREATE TYPE driver_status AS ENUM (
    'available',
    'on_trip',
    'off_duty',
    'on_leave',
    'suspended'
);

-- Cargo request types
CREATE TYPE request_type AS ENUM (
    'corporate',
    'individual'
);

-- Cargo request status
CREATE TYPE cargo_status AS ENUM (
    'pending',
    'quote_sent',
    'accepted',
    'assigned',
    'picked_up',
    'in_transit',
    'delivered',
    'cancelled',
    'failed'
);

-- Route status
CREATE TYPE route_status AS ENUM (
    'planned',
    'active',
    'completed',
    'cancelled'
);

-- Dispatch order status
CREATE TYPE dispatch_status AS ENUM (
    'pending',
    'assigned',
    'in_progress',
    'completed',
    'cancelled'
);

-- Escrow status
CREATE TYPE escrow_status AS ENUM (
    'held',
    'released',
    'refunded',
    'expired'
);

-- Invoice status
CREATE TYPE invoice_status AS ENUM (
    'draft',
    'sent',
    'paid',
    'overdue',
    'cancelled',
    'refunded'
);

-- Payment methods
CREATE TYPE payment_method AS ENUM (
    'mpesa',
    'tigo_pesa',
    'airtel_money',
    'bank_transfer',
    'card',
    'cash',
    'wallet'
);

-- Payment status
CREATE TYPE payment_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'refunded'
);

-- Support ticket priority
CREATE TYPE ticket_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);

-- Support ticket status
CREATE TYPE ticket_status AS ENUM (
    'open',
    'assigned',
    'in_progress',
    'resolved',
    'closed',
    'reopened'
);

-- Client types
CREATE TYPE client_type AS ENUM (
    'corporate',
    'individual'
);

-- Zone types for H3 grid
CREATE TYPE zone_type AS ENUM (
    'urban',
    'suburban',
    'rural',
    'industrial',
    'commercial',
    'residential'
);

-- Notification types
CREATE TYPE notification_type AS ENUM (
    'system',
    'cargo_update',
    'payment',
    'maintenance',
    'alert',
    'promotion'
);

-- Document types
CREATE TYPE document_type AS ENUM (
    'invoice',
    'receipt',
    'manifest',
    'insurance',
    'contract',
    'permit',
    'other'
);

-- Training types
CREATE TYPE training_type AS ENUM (
    'safety',
    'defensive_driving',
    'hazmat',
    'customer_service',
    'first_aid',
    'other'
);

-- Inspection types
CREATE TYPE inspection_type AS ENUM (
    'routine',
    'pre_trip',
    'post_trip',
    'safety',
    'compliance',
    'damage'
);

-- Incident types
CREATE TYPE incident_type AS ENUM (
    'damage',
    'theft',
    'loss',
    'delay',
    'accident',
    'other'
);

-- Resolution status
CREATE TYPE resolution_status AS ENUM (
    'open',
    'investigating',
    'resolved',
    'closed'
);

-- Revenue types
CREATE TYPE revenue_type AS ENUM (
    'cargo_delivery',
    'fuel_surcharge',
    'insurance_fee',
    'storage_fee',
    'late_fee',
    'other'
);

-- Expense types
CREATE TYPE expense_type AS ENUM (
    'fuel',
    'maintenance',
    'salary',
    'insurance',
    'rent',
    'utilities',
    'supplies',
    'other'
);

-- Shift types
CREATE TYPE shift_type AS ENUM (
    'morning',
    'afternoon',
    'night',
    'full_day'
);

-- Assignment status
CREATE TYPE assignment_status AS ENUM (
    'active',
    'completed',
    'cancelled'
);

COMMENT ON TYPE user_role IS 'Available user roles in the system';
COMMENT ON TYPE cargo_status IS 'Status progression for cargo requests';
COMMENT ON TYPE payment_method IS 'Supported payment methods in Tanzania';
