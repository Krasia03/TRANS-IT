-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 006: Route & Dispatch (4 modules)
-- =====================================================

-- Routes table
CREATE TABLE routes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
    driver_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    start_location TEXT NOT NULL,
    end_location TEXT NOT NULL,
    waypoints_json JSONB DEFAULT '[]',
    total_distance_km NUMERIC(10, 2) NOT NULL,
    estimated_duration_min INTEGER NOT NULL,
    status route_status NOT NULL DEFAULT 'planned',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_distance CHECK (total_distance_km >= 0),
    CONSTRAINT chk_duration CHECK (estimated_duration_min > 0)
);

-- Dispatch orders (linking cargo to routes)
CREATE TABLE dispatch_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    route_id UUID NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    cargo_request_id UUID NOT NULL REFERENCES cargo_requests(id) ON DELETE RESTRICT,
    priority priority_level NOT NULL DEFAULT 'normal',
    sequence_order INTEGER NOT NULL,
    status dispatch_status NOT NULL DEFAULT 'pending',
    assigned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT chk_sequence CHECK (sequence_order > 0),
    CONSTRAINT chk_completion CHECK (completed_at IS NULL OR completed_at > assigned_at)
);

-- Route history (actual performance tracking)
CREATE TABLE route_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    route_id UUID NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    actual_start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    actual_end_time TIMESTAMP WITH TIME ZONE,
    actual_distance_km NUMERIC(10, 2),
    fuel_consumed_liters NUMERIC(8, 2),
    efficiency_rating NUMERIC(5, 2),
    
    CONSTRAINT chk_actual_times CHECK (actual_end_time IS NULL OR actual_end_time > actual_start_time),
    CONSTRAINT chk_actual_distance CHECK (actual_distance_km IS NULL OR actual_distance_km >= 0),
    CONSTRAINT chk_fuel_consumed CHECK (fuel_consumed_liters IS NULL OR fuel_consumed_liters >= 0),
    CONSTRAINT chk_efficiency CHECK (efficiency_rating IS NULL OR (efficiency_rating >= 0 AND efficiency_rating <= 100))
);

-- Route optimizations (tracking optimization improvements)
CREATE TABLE route_optimizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    original_route_id UUID NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    optimized_route_id UUID REFERENCES routes(id) ON DELETE SET NULL,
    distance_saved_km NUMERIC(10, 2) NOT NULL DEFAULT 0,
    time_saved_min INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_distance_saved CHECK (distance_saved_km >= 0),
    CONSTRAINT chk_time_saved CHECK (time_saved_min >= 0)
);

-- =====================================================
-- INDEXES
-- =====================================================

CREATE INDEX idx_routes_vehicle_id ON routes(vehicle_id);
CREATE INDEX idx_routes_driver_id ON routes(driver_id);
CREATE INDEX idx_routes_status ON routes(status);
CREATE INDEX idx_routes_created_at ON routes(created_at DESC);

CREATE INDEX idx_dispatch_orders_route_id ON dispatch_orders(route_id);
CREATE INDEX idx_dispatch_orders_cargo_id ON dispatch_orders(cargo_request_id);
CREATE INDEX idx_dispatch_orders_priority ON dispatch_orders(priority);
CREATE INDEX idx_dispatch_orders_status ON dispatch_orders(status);
CREATE INDEX idx_dispatch_orders_sequence ON dispatch_orders(route_id, sequence_order);

CREATE INDEX idx_route_history_route_id ON route_history(route_id);
CREATE INDEX idx_route_history_start_time ON route_history(actual_start_time);

CREATE INDEX idx_route_optimizations_original_id ON route_optimizations(original_route_id);
CREATE INDEX idx_route_optimizations_optimized_id ON route_optimizations(optimized_route_id);
CREATE INDEX idx_route_optimizations_created_at ON route_optimizations(created_at);

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON TABLE routes IS 'Planned and active delivery routes';
COMMENT ON TABLE dispatch_orders IS 'Links cargo requests to routes with sequencing';
COMMENT ON TABLE route_history IS 'Actual route performance vs. planned metrics';
COMMENT ON TABLE route_optimizations IS 'Optimization improvements tracking';
COMMENT ON COLUMN routes.waypoints_json IS 'Array of intermediate stops in GeoJSON format';
COMMENT ON COLUMN dispatch_orders.sequence_order IS 'Delivery order in the route (1-based)';
