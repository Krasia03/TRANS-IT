-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 007: Payments & Billing
-- =====================================================

-- Escrow accounts
CREATE TABLE escrow_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL,
    client_type client_type NOT NULL,
    balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    held_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    status escrow_status NOT NULL DEFAULT 'held',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Invoices
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    client_id UUID NOT NULL,
    client_type client_type NOT NULL,
    cargo_request_id UUID,
    subtotal DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    tax_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    total DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(3) NOT NULL DEFAULT 'TZS',
    status invoice_status NOT NULL DEFAULT 'draft',
    due_date DATE NOT NULL,
    paid_at TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Invoice line items
CREATE TABLE invoice_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    unit_price DECIMAL(15,2) NOT NULL,
    total DECIMAL(15,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Payments
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID REFERENCES invoices(id),
    escrow_account_id UUID REFERENCES escrow_accounts(id),
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'TZS',
    method payment_method NOT NULL,
    reference VARCHAR(100) NOT NULL UNIQUE,
    status payment_status NOT NULL DEFAULT 'pending',
    provider_response_json JSONB,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Payment reconciliation
CREATE TABLE payment_reconciliation (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    payment_id UUID NOT NULL REFERENCES payments(id),
    invoice_id UUID NOT NULL REFERENCES invoices(id),
    amount DECIMAL(15,2) NOT NULL,
    reconciled_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Revenue records
CREATE TABLE revenue_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cargo_request_id UUID,
    route_id UUID,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'TZS',
    type revenue_type NOT NULL DEFAULT 'cargo_delivery',
    description TEXT,
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Expenses
CREATE TABLE expenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category expense_type NOT NULL,
    vehicle_id UUID REFERENCES vehicles(id),
    driver_id UUID REFERENCES drivers(id),
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'TZS',
    description TEXT,
    receipt_url TEXT,
    expense_date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================
-- INDEXES
-- =====================================================
CREATE INDEX idx_escrow_accounts_client ON escrow_accounts(client_id, client_type);
CREATE INDEX idx_escrow_accounts_status ON escrow_accounts(status);

CREATE INDEX idx_invoices_client ON invoices(client_id, client_type);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_due_date ON invoices(due_date);
CREATE INDEX idx_invoices_invoice_number ON invoices(invoice_number);

CREATE INDEX idx_invoice_items_invoice ON invoice_items(invoice_id);

CREATE INDEX idx_payments_invoice ON payments(invoice_id);
CREATE INDEX idx_payments_escrow ON payments(escrow_account_id);
CREATE INDEX idx_payments_reference ON payments(reference);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_created_at ON payments(created_at);

CREATE INDEX idx_payment_reconciliation_payment ON payment_reconciliation(payment_id);
CREATE INDEX idx_payment_reconciliation_invoice ON payment_reconciliation(invoice_id);

CREATE INDEX idx_revenue_records_cargo ON revenue_records(cargo_request_id);
CREATE INDEX idx_revenue_records_route ON revenue_records(route_id);
CREATE INDEX idx_revenue_records_recorded_at ON revenue_records(recorded_at);

CREATE INDEX idx_expenses_category ON expenses(category);
CREATE INDEX idx_expenses_vehicle ON expenses(vehicle_id);
CREATE INDEX idx_expenses_driver ON expenses(driver_id);
CREATE INDEX idx_expenses_date ON expenses(expense_date);

-- =====================================================
-- CONSTRAINTS
-- =====================================================
ALTER TABLE invoices ADD CONSTRAINT chk_invoice_total CHECK (total >= 0);
ALTER TABLE invoice_items ADD CONSTRAINT chk_invoice_item_total CHECK (total >= 0);
ALTER TABLE payments ADD CONSTRAINT chk_payment_amount CHECK (amount > 0);
ALTER TABLE expenses ADD CONSTRAINT chk_expense_amount CHECK (amount > 0);

COMMENT ON TABLE escrow_accounts IS 'Customer escrow accounts for secure payment holding';
COMMENT ON TABLE invoices IS 'Client invoices for cargo shipments';
COMMENT ON TABLE payments IS 'Payment transactions with multiple payment methods';
