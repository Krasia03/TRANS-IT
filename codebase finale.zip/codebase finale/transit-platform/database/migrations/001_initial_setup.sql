-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 001: Initial Setup - Extensions & ENUMs
-- =====================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- =====================================================
-- ENUM TYPES
-- =====================================================

-- Vehicle related enums
CREATE TYPE vehicle_status AS ENUM ('active', 'maintenance', 'inactive', 'retired');
CREATE TYPE fuel_type AS ENUM ('petrol', 'diesel', 'electric', 'hybrid', 'cng');
CREATE TYPE maintenance_type AS ENUM ('routine', 'repair', 'inspection', 'emergency');
CREATE TYPE inspection_type AS ENUM ('daily', 'weekly', 'monthly', 'annual', 'pre_trip');

-- Driver related enums
CREATE TYPE driver_status AS ENUM ('active', 'on_leave', 'suspended', 'terminated', 'training');
CREATE TYPE training_type AS ENUM ('safety', 'defensive_driving', 'cargo_handling', 'first_aid', 'compliance');
CREATE TYPE shift_status AS ENUM ('scheduled', 'in_progress', 'completed', 'cancelled');

-- Cargo related enums
CREATE TYPE request_type AS ENUM ('pickup', 'delivery', 'round_trip', 'scheduled');
CREATE TYPE cargo_status AS ENUM ('pending', 'assigned', 'in_transit', 'delivered', 'cancelled', 'failed');
CREATE TYPE cargo_type AS ENUM ('general', 'fragile', 'perishable', 'hazardous', 'valuable', 'livestock');
CREATE TYPE document_type AS ENUM ('invoice', 'waybill', 'manifest', 'insurance', 'permit', 'customs');
CREATE TYPE incident_type AS ENUM ('damage', 'delay', 'theft', 'loss', 'accident', 'other');
CREATE TYPE resolution_status AS ENUM ('open', 'investigating', 'resolved', 'closed');

-- Route & Dispatch enums
CREATE TYPE route_status AS ENUM ('planned', 'active', 'completed', 'cancelled');
CREATE TYPE dispatch_status AS ENUM ('pending', 'assigned', 'in_progress', 'completed', 'cancelled');
CREATE TYPE priority_level AS ENUM ('low', 'normal', 'high', 'urgent');

-- Payment related enums
CREATE TYPE escrow_status AS ENUM ('pending', 'held', 'released', 'refunded', 'disputed');
CREATE TYPE invoice_status AS ENUM ('draft', 'sent', 'paid', 'overdue', 'cancelled', 'refunded');
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');
CREATE TYPE payment_method AS ENUM ('cash', 'mobile_money', 'bank_transfer', 'card', 'escrow');
CREATE TYPE revenue_type AS ENUM ('cargo_fee', 'fuel_surcharge', 'insurance', 'storage', 'express_delivery', 'other');
CREATE TYPE expense_type AS ENUM ('fuel', 'maintenance', 'tolls', 'parking', 'meals', 'accommodation', 'other');

-- Client related enums
CREATE TYPE client_status AS ENUM ('active', 'inactive', 'suspended', 'blacklisted');
CREATE TYPE client_type AS ENUM ('corporate', 'individual');
CREATE TYPE ticket_priority AS ENUM ('low', 'normal', 'high', 'critical');
CREATE TYPE ticket_status AS ENUM ('open', 'assigned', 'in_progress', 'waiting_response', 'resolved', 'closed');

-- User & System enums
CREATE TYPE user_role AS ENUM ('super_admin', 'admin', 'dispatcher', 'driver', 'warehouse_manager', 'warehouse_staff', 'accountant', 'support_agent', 'client');
CREATE TYPE user_status AS ENUM ('active', 'inactive', 'suspended', 'pending_verification');
CREATE TYPE notification_type AS ENUM ('info', 'warning', 'error', 'success', 'alert');
CREATE TYPE zone_type AS ENUM ('high_demand', 'medium_demand', 'low_demand', 'restricted', 'parking');

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON TYPE vehicle_status IS 'Status of vehicles in the fleet';
COMMENT ON TYPE cargo_status IS 'Lifecycle status of cargo requests';
COMMENT ON TYPE payment_method IS 'Available payment methods (all transactions in TZS)';
COMMENT ON TYPE zone_type IS 'H3 grid zone classifications for demand-based routing';
