-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 008: Customer Management
-- =====================================================

-- Corporate clients
CREATE TABLE corporate_clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    company_name VARCHAR(255) NOT NULL,
    registration_number VARCHAR(100) UNIQUE,
    tax_id VARCHAR(100),
    contact_person VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    address_line TEXT,
    city VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20),
    country VARCHAR(100) NOT NULL DEFAULT 'Tanzania',
    credit_limit DECIMAL(15,2) DEFAULT 0.00,
    payment_terms INTEGER DEFAULT 30,
    status client_type NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Individual clients
CREATE TABLE individual_clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    national_id VARCHAR(50) UNIQUE,
    address_line TEXT,
    city VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20),
    country VARCHAR(100) NOT NULL DEFAULT 'Tanzania',
    status client_type NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Support tickets
CREATE TABLE support_tickets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_number VARCHAR(50) NOT NULL UNIQUE,
    client_id UUID NOT NULL,
    client_type client_type NOT NULL,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    priority ticket_priority NOT NULL DEFAULT 'medium',
    status ticket_status NOT NULL DEFAULT 'open',
    assigned_to UUID REFERENCES users(id),
    resolved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Support ticket responses
CREATE TABLE ticket_responses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_id UUID NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    message TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Client documents
CREATE TABLE client_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL,
    client_type client_type NOT NULL,
    type document_type NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_size INTEGER,
    mime_type VARCHAR(100),
    uploaded_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================
-- INDEXES
-- =====================================================
CREATE INDEX idx_corporate_clients_user ON corporate_clients(user_id);
CREATE INDEX idx_corporate_clients_company ON corporate_clients(company_name);
CREATE INDEX idx_corporate_clients_status ON corporate_clients(status);

CREATE INDEX idx_individual_clients_user ON individual_clients(user_id);
CREATE INDEX idx_individual_clients_email ON individual_clients(email);
CREATE INDEX idx_individual_clients_phone ON individual_clients(phone);
CREATE INDEX idx_individual_clients_status ON individual_clients(status);

CREATE INDEX idx_support_tickets_client ON support_tickets(client_id, client_type);
CREATE INDEX idx_support_tickets_status ON support_tickets(status);
CREATE INDEX idx_support_tickets_priority ON support_tickets(priority);
CREATE INDEX idx_support_tickets_ticket_number ON support_tickets(ticket_number);

CREATE INDEX idx_ticket_responses_ticket ON ticket_responses(ticket_id);
CREATE INDEX idx_ticket_responses_user ON ticket_responses(user_id);

CREATE INDEX idx_client_documents_client ON client_documents(client_id, client_type);
CREATE INDEX idx_client_documents_type ON client_documents(type);

-- =====================================================
-- CONSTRAINTS
-- =====================================================
ALTER TABLE corporate_clients ADD CONSTRAINT chk_credit_limit CHECK (credit_limit >= 0);
ALTER TABLE support_tickets ADD CONSTRAINT chk_ticket_priority CHECK (priority IN ('low', 'medium', 'high', 'urgent'));

COMMENT ON TABLE corporate_clients IS 'Corporate/business customer accounts';
COMMENT ON TABLE individual_clients IS 'Individual customer accounts';
COMMENT ON TABLE support_tickets IS 'Customer support tickets';
