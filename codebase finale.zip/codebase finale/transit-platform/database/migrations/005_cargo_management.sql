-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 005: Cargo Management (8 modules)
-- =====================================================

-- Cargo categories (pricing reference)
CREATE TABLE cargo_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    rate_per_kg_tzs NUMERIC(10, 2) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    CONSTRAINT chk_rate_per_kg CHECK (rate_per_kg_tzs >= 0)
);

-- Cargo pricing matrix
CREATE TABLE cargo_pricing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id UUID NOT NULL REFERENCES cargo_categories(id) ON DELETE CASCADE,
    vehicle_type VARCHAR(50) NOT NULL,
    base_rate_tzs NUMERIC(12, 2) NOT NULL,
    per_km_rate_tzs NUMERIC(10, 2) NOT NULL,
    min_weight_kg NUMERIC(10, 2) NOT NULL DEFAULT 0,
    max_weight_kg NUMERIC(10, 2),
    
    CONSTRAINT chk_base_rate CHECK (base_rate_tzs >= 0),
    CONSTRAINT chk_per_km_rate CHECK (per_km_rate_tzs >= 0),
    CONSTRAINT chk_weight_range CHECK (max_weight_kg IS NULL OR max_weight_kg > min_weight_kg)
);

-- Cargo requests (main cargo table)
CREATE TABLE cargo_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_type request_type NOT NULL,
    client_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    pickup_location_h3 VARCHAR(15) NOT NULL,
    delivery_location_h3 VARCHAR(15) NOT NULL,
    pickup_address TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    cargo_type cargo_type NOT NULL,
    weight_kg NUMERIC(10, 2) NOT NULL,
    volume_m3 NUMERIC(10, 2),
    special_requirements TEXT,
    status cargo_status NOT NULL DEFAULT 'pending',
    estimated_cost_tzs NUMERIC(12, 2),
    pickup_date TIMESTAMP WITH TIME ZONE NOT NULL,
    delivery_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT chk_weight CHECK (weight_kg > 0),
    CONSTRAINT chk_volume CHECK (volume_m3 IS NULL OR volume_m3 > 0),
    CONSTRAINT chk_estimated_cost CHECK (estimated_cost_tzs IS NULL OR estimated_cost_tzs >= 0),
    CONSTRAINT chk_delivery_after_pickup CHECK (delivery_date IS NULL OR delivery_date > pickup_date)
);

-- Cargo tracking (real-time status updates)
CREATE TABLE cargo_tracking (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cargo_request_id UUID NOT NULL REFERENCES cargo_requests(id) ON DELETE CASCADE,
    vehicle_id UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    driver_id UUID REFERENCES users(id) ON DELETE SET NULL,
    current_location_h3 VARCHAR(15),
    current_address TEXT,
    status cargo_status NOT NULL,
    eta TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Cargo documents
CREATE TABLE cargo_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cargo_request_id UUID NOT NULL REFERENCES cargo_requests(id) ON DELETE CASCADE,
    document_type document_type NOT NULL,
    file_path TEXT NOT NULL,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
    uploaded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Cargo insurance
CREATE TABLE cargo_insurance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cargo_request_id UUID NOT NULL REFERENCES cargo_requests(id) ON DELETE CASCADE,
    policy_number VARCHAR(100) NOT NULL UNIQUE,
    provider VARCHAR(255) NOT NULL,
    coverage_amount_tzs NUMERIC(12, 2) NOT NULL,
    premium_tzs NUMERIC(12, 2) NOT NULL,
    expiry_date DATE NOT NULL,
    
    CONSTRAINT chk_coverage_amount CHECK (coverage_amount_tzs > 0),
    CONSTRAINT chk_premium CHECK (premium_tzs > 0)
);

-- Cargo incidents
CREATE TABLE cargo_incidents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cargo_request_id UUID NOT NULL REFERENCES cargo_requests(id) ON DELETE CASCADE,
    incident_type incident_type NOT NULL,
    description TEXT NOT NULL,
    reported_by UUID REFERENCES users(id) ON DELETE SET NULL,
    reported_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    resolution_status resolution_status NOT NULL DEFAULT 'open'
);

-- Delivery proofs
CREATE TABLE delivery_proofs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cargo_request_id UUID NOT NULL UNIQUE REFERENCES cargo_requests(id) ON DELETE CASCADE,
    photo_path TEXT,
    signature_path TEXT,
    recipient_name VARCHAR(255) NOT NULL,
    delivered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_proof_required CHECK (photo_path IS NOT NULL OR signature_path IS NOT NULL)
);

-- =====================================================
-- INDEXES
-- =====================================================

CREATE INDEX idx_cargo_categories_name ON cargo_categories(name);
CREATE INDEX idx_cargo_categories_is_active ON cargo_categories(is_active);

CREATE INDEX idx_cargo_pricing_category_id ON cargo_pricing(category_id);
CREATE INDEX idx_cargo_pricing_vehicle_type ON cargo_pricing(vehicle_type);

CREATE INDEX idx_cargo_requests_client_id ON cargo_requests(client_id);
CREATE INDEX idx_cargo_requests_status ON cargo_requests(status);
CREATE INDEX idx_cargo_requests_pickup_h3 ON cargo_requests(pickup_location_h3);
CREATE INDEX idx_cargo_requests_delivery_h3 ON cargo_requests(delivery_location_h3);
CREATE INDEX idx_cargo_requests_pickup_date ON cargo_requests(pickup_date);
CREATE INDEX idx_cargo_requests_created_at ON cargo_requests(created_at DESC);
CREATE INDEX idx_cargo_requests_deleted_at ON cargo_requests(deleted_at);

CREATE INDEX idx_cargo_tracking_cargo_id ON cargo_tracking(cargo_request_id);
CREATE INDEX idx_cargo_tracking_vehicle_id ON cargo_tracking(vehicle_id);
CREATE INDEX idx_cargo_tracking_driver_id ON cargo_tracking(driver_id);
CREATE INDEX idx_cargo_tracking_current_h3 ON cargo_tracking(current_location_h3);
CREATE INDEX idx_cargo_tracking_status ON cargo_tracking(status);
CREATE INDEX idx_cargo_tracking_updated_at ON cargo_tracking(updated_at DESC);

CREATE INDEX idx_cargo_documents_cargo_id ON cargo_documents(cargo_request_id);
CREATE INDEX idx_cargo_documents_type ON cargo_documents(document_type);

CREATE INDEX idx_cargo_insurance_cargo_id ON cargo_insurance(cargo_request_id);
CREATE INDEX idx_cargo_insurance_policy_number ON cargo_insurance(policy_number);
CREATE INDEX idx_cargo_insurance_expiry ON cargo_insurance(expiry_date);

CREATE INDEX idx_cargo_incidents_cargo_id ON cargo_incidents(cargo_request_id);
CREATE INDEX idx_cargo_incidents_status ON cargo_incidents(resolution_status);
CREATE INDEX idx_cargo_incidents_reported_at ON cargo_incidents(reported_at);

CREATE INDEX idx_delivery_proofs_cargo_id ON delivery_proofs(cargo_request_id);
CREATE INDEX idx_delivery_proofs_delivered_at ON delivery_proofs(delivered_at);

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON TABLE cargo_requests IS 'Main cargo booking and management table';
COMMENT ON TABLE cargo_tracking IS 'Real-time cargo location and status tracking';
COMMENT ON TABLE cargo_insurance IS 'Insurance policies for cargo shipments (all amounts in TZS)';
COMMENT ON TABLE delivery_proofs IS 'Proof of delivery with photo/signature verification';
COMMENT ON COLUMN cargo_requests.pickup_location_h3 IS 'H3 index for pickup location';
COMMENT ON COLUMN cargo_requests.delivery_location_h3 IS 'H3 index for delivery location';
