-- ============================================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 001: Database Extensions
-- ============================================================================

-- PostGIS extension for geospatial operations
CREATE EXTENSION IF NOT EXISTS postgis;

-- UUID extension for generating unique identifiers
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- pgcrypto for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- H3 PostgreSQL extension for Uber's H3 geospatial indexing
-- Note: Requires h3-pg extension to be installed
-- Install: https://github.com/zachasme/h3-pg
CREATE EXTENSION IF NOT EXISTS h3;

-- Additional useful extensions
CREATE EXTENSION IF NOT EXISTS btree_gist; -- For range indexing
CREATE EXTENSION IF NOT EXISTS pg_trgm;    -- For fuzzy text search

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';
COMMENT ON EXTENSION h3 IS 'H3 hierarchical hexagonal geospatial indexing system';
