-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 010: Geospatial & H3 Integration
-- =====================================================

-- H3 grid zones for spatial indexing
CREATE TABLE h3_grid_zones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    h3_index VARCHAR(20) NOT NULL UNIQUE,
    resolution INTEGER NOT NULL CHECK (resolution >= 0 AND resolution <= 15),
    zone_type zone_type NOT NULL,
    name VARCHAR(100),
    boundary_json JSONB,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Geofences
CREATE TABLE geofences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    fence_type VARCHAR(50) NOT NULL DEFAULT 'polygon',
    center_latitude DECIMAL(10,8),
    center_longitude DECIMAL(11,8),
    radius_meters DECIMAL(10,2),
    boundary_points JSONB,
    h3_indexes TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Geofence alerts
CREATE TABLE geofence_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    geofence_id UUID NOT NULL REFERENCES geofences(id) ON DELETE CASCADE,
    vehicle_id UUID REFERENCES vehicles(id),
    driver_id UUID REFERENCES drivers(id),
    alert_type VARCHAR(50) NOT NULL,
    h3_index VARCHAR(20),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    message TEXT,
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Zone pricing (different prices for different zones)
CREATE TABLE zone_pricing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    h3_index VARCHAR(20) NOT NULL,
    origin_h3_index VARCHAR(20) NOT NULL,
    price_per_km DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    base_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(3) NOT NULL DEFAULT 'TZS',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    UNIQUE(h3_index, origin_h3_index)
);

-- =====================================================
-- INDEXES
-- =====================================================
CREATE INDEX idx_h3_grid_zones_h3 ON h3_grid_zones(h3_index);
CREATE INDEX idx_h3_grid_zones_resolution ON h3_grid_zones(resolution);
CREATE INDEX idx_h3_grid_zones_type ON h3_grid_zones(zone_type);

CREATE INDEX idx_geofences_active ON geofences(is_active);
CREATE INDEX idx_geofences_type ON geofences(fence_type);

CREATE INDEX idx_geofence_alerts_vehicle ON geofence_alerts(vehicle_id);
CREATE INDEX idx_geofence_alerts_driver ON geofence_alerts(driver_id);
CREATE INDEX idx_geofence_alerts_created ON geofence_alerts(created_at);
CREATE INDEX idx_geofence_alerts_acknowledged ON geofence_alerts(acknowledged_at) WHERE acknowledged_at IS NULL;

CREATE INDEX idx_zone_pricing_origin ON zone_pricing(origin_h3_index);
CREATE INDEX idx_zone_pricing_destination ON zone_pricing(h3_index);

-- =====================================================
-- FUNCTIONS
-- =====================================================

-- Function to generate H3 index from lat/lng
CREATE OR REPLACE FUNCTION generate_h3_index(
    p_latitude DECIMAL,
    p_longitude DECIMAL,
    p_resolution INTEGER DEFAULT 10
)
RETURNS VARCHAR AS $$
DECLARE
    v_h3_index VARCHAR;
BEGIN
    v_h3_index := h3_geo_to_h3(p_latitude, p_longitude, p_resolution);
    RETURN v_h3_index;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function to get neighboring H3 cells
CREATE OR REPLACE FUNCTION get_h3_neighbors(p_h3_index VARCHAR)
RETURNS TEXT[] AS $$
BEGIN
    RETURN h3_grid_disk(p_h3_index, 1);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function to check if point is inside geofence
CREATE OR REPLACE FUNCTION is_point_in_geofence(
    p_geofence_id UUID,
    p_latitude DECIMAL,
    p_longitude DECIMAL
)
RETURNS BOOLEAN AS $$
DECLARE
    v_geofence RECORD;
    v_point GEOGRAPHY;
    v_boundary GEOGRAPHY;
BEGIN
    SELECT * INTO v_geofence FROM geofences WHERE id = p_geofence_id AND is_active = TRUE;
    
    IF NOT FOUND THEN
        RETURN FALSE;
    END IF;
    
    v_point := ST_SetSRID(ST_MakePoint(p_longitude, p_latitude), 4326)::GEOGRAPHY;
    
    IF v_geofence.fence_type = 'circle' THEN
        RETURN ST_DWithin(
            v_point,
            ST_SetSRID(ST_MakePoint(v_geofence.center_longitude, v_geofence.center_latitude), 4326)::GEOGRAPHY,
            v_geofence.radius_meters
        );
    ELSE
        IF v_geofence.boundary_points IS NOT NULL THEN
            v_boundary := ST_SetSRID(ST_GeomFromGeoJSON(v_geofence.boundary_points), 4326)::GEOGRAPHY;
            RETURN ST_Within(v_point, v_boundary);
        END IF;
    END IF;
    
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update vehicle location H3 index
CREATE OR REPLACE FUNCTION update_vehicle_h3_index()
RETURNS TRIGGER AS $$
BEGIN
    NEW.h3_index := generate_h3_index(NEW.latitude, NEW.longitude, 10);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- CONSTRAINTS
-- =====================================================
ALTER TABLE geofences ADD CONSTRAINT chk_radius CHECK (radius_meters IS NULL OR radius_meters > 0);
ALTER TABLE zone_pricing ADD CONSTRAINT chk_price_per_km CHECK (price_per_km >= 0);
ALTER TABLE zone_pricing ADD CONSTRAINT chk_base_price CHECK (base_price >= 0);

COMMENT ON TABLE h3_grid_zones IS 'H3 hexagonal grid zones for spatial indexing and pricing';
COMMENT ON TABLE geofences IS 'Virtual boundaries for vehicle monitoring';
COMMENT ON TABLE geofence_alerts IS 'Alerts when vehicles enter/exit geofences';
COMMENT ON TABLE zone_pricing IS 'Dynamic pricing based on H3 zones';
