-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 004: Driver Management (5 modules)
-- =====================================================

-- Drivers table
CREATE TABLE drivers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    license_number VARCHAR(50) NOT NULL UNIQUE,
    license_expiry DATE NOT NULL,
    experience_years INTEGER NOT NULL DEFAULT 0,
    status driver_status NOT NULL DEFAULT 'active',
    rating NUMERIC(3, 2) DEFAULT 5.00,
    joined_date DATE NOT NULL DEFAULT CURRENT_DATE,
    
    CONSTRAINT chk_experience CHECK (experience_years >= 0),
    CONSTRAINT chk_rating CHECK (rating >= 0 AND rating <= 5),
    CONSTRAINT chk_license_expiry CHECK (license_expiry > CURRENT_DATE)
);

-- Driver performance metrics
CREATE TABLE driver_performance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    safety_score NUMERIC(5, 2) NOT NULL DEFAULT 100,
    delivery_rating NUMERIC(3, 2) NOT NULL DEFAULT 5.00,
    efficiency_score NUMERIC(5, 2) NOT NULL DEFAULT 100,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    
    CONSTRAINT chk_safety_score CHECK (safety_score >= 0 AND safety_score <= 100),
    CONSTRAINT chk_delivery_rating CHECK (delivery_rating >= 0 AND delivery_rating <= 5),
    CONSTRAINT chk_efficiency_score CHECK (efficiency_score >= 0 AND efficiency_score <= 100),
    CONSTRAINT chk_performance_period CHECK (period_end > period_start)
);

-- Driver payroll
CREATE TABLE driver_payroll (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    base_salary_tzs NUMERIC(12, 2) NOT NULL,
    bonuses_tzs NUMERIC(12, 2) NOT NULL DEFAULT 0,
    deductions_tzs NUMERIC(12, 2) NOT NULL DEFAULT 0,
    net_pay_tzs NUMERIC(12, 2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method payment_method NOT NULL,
    
    CONSTRAINT chk_base_salary CHECK (base_salary_tzs > 0),
    CONSTRAINT chk_bonuses CHECK (bonuses_tzs >= 0),
    CONSTRAINT chk_deductions CHECK (deductions_tzs >= 0),
    CONSTRAINT chk_net_pay CHECK (net_pay_tzs = base_salary_tzs + bonuses_tzs - deductions_tzs)
);

-- Driver training records
CREATE TABLE driver_training (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    training_type training_type NOT NULL,
    completed_at DATE NOT NULL,
    certificate_number VARCHAR(100),
    expiry_date DATE,
    
    CONSTRAINT chk_training_dates CHECK (expiry_date IS NULL OR expiry_date > completed_at)
);

-- Driver schedules
CREATE TABLE driver_schedules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    shift_start TIMESTAMP WITH TIME ZONE NOT NULL,
    shift_end TIMESTAMP WITH TIME ZONE NOT NULL,
    day_off BOOLEAN NOT NULL DEFAULT FALSE,
    status shift_status NOT NULL DEFAULT 'scheduled',
    
    CONSTRAINT chk_shift_times CHECK (shift_end > shift_start)
);

-- =====================================================
-- INDEXES
-- =====================================================

CREATE INDEX idx_drivers_user_id ON drivers(user_id);
CREATE INDEX idx_drivers_license_number ON drivers(license_number);
CREATE INDEX idx_drivers_status ON drivers(status);
CREATE INDEX idx_drivers_rating ON drivers(rating DESC);

CREATE INDEX idx_driver_performance_driver_id ON driver_performance(driver_id);
CREATE INDEX idx_driver_performance_period ON driver_performance(period_start, period_end);

CREATE INDEX idx_driver_payroll_driver_id ON driver_payroll(driver_id);
CREATE INDEX idx_driver_payroll_payment_date ON driver_payroll(payment_date);

CREATE INDEX idx_driver_training_driver_id ON driver_training(driver_id);
CREATE INDEX idx_driver_training_expiry ON driver_training(expiry_date);

CREATE INDEX idx_driver_schedules_driver_id ON driver_schedules(driver_id);
CREATE INDEX idx_driver_schedules_shift_start ON driver_schedules(shift_start);
CREATE INDEX idx_driver_schedules_status ON driver_schedules(status);

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON TABLE drivers IS 'Driver profiles linked to user accounts';
COMMENT ON TABLE driver_performance IS 'Performance metrics calculated per period';
COMMENT ON TABLE driver_payroll IS 'Payroll records (all amounts in TZS)';
COMMENT ON TABLE driver_training IS 'Training certifications and compliance';
COMMENT ON TABLE driver_schedules IS 'Shift scheduling and availability';
COMMENT ON COLUMN drivers.rating IS 'Average customer rating (0-5 scale)';
