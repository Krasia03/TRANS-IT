-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Migration 009: Warehouse Management
-- =====================================================

-- Warehouses
CREATE TABLE warehouses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) NOT NULL UNIQUE,
    address_line TEXT,
    city VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20),
    country VARCHAR(100) NOT NULL DEFAULT 'Tanzania',
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    h3_index VARCHAR(20),
    capacity_sqm DECIMAL(10,2),
    current_utilization DECIMAL(5,2) DEFAULT 0.00,
    manager_id UUID REFERENCES users(id),
    status generic_status NOT NULL DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Warehouse sections/zones
CREATE TABLE warehouse_zones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    zone_type VARCHAR(50) NOT NULL,
    capacity_sqm DECIMAL(10,2),
    current_utilization DECIMAL(5,2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Inventory
CREATE TABLE inventory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id),
    warehouse_zone_id UUID REFERENCES warehouse_zones(id),
    cargo_request_id UUID REFERENCES cargo_requests(id),
    description TEXT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    weight DECIMAL(10,2),
    volume DECIMAL(10,4),
    unit_value DECIMAL(15,2),
    status VARCHAR(50) NOT NULL DEFAULT 'stored',
    stored_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    released_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Warehouse staff assignments
CREATE TABLE warehouse_staff (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id),
    role VARCHAR(50) NOT NULL DEFAULT 'staff',
    shift_type shift_type DEFAULT 'morning',
    is_active BOOLEAN DEFAULT TRUE,
    assigned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Inventory transactions
CREATE TABLE inventory_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    inventory_id UUID NOT NULL REFERENCES inventory(id),
    transaction_type VARCHAR(50) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    reference VARCHAR(100),
    notes TEXT,
    performed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================
-- INDEXES
-- =====================================================
CREATE INDEX idx_warehouses_code ON warehouses(code);
CREATE INDEX idx_warehouses_location ON warehouses(city, region);
CREATE INDEX idx_warehouses_h3 ON warehouses(h3_index);

CREATE INDEX idx_warehouse_zones_warehouse ON warehouse_zones(warehouse_id);

CREATE INDEX idx_inventory_warehouse ON inventory(warehouse_id);
CREATE INDEX idx_inventory_zone ON inventory(warehouse_zone_id);
CREATE INDEX idx_inventory_cargo ON inventory(cargo_request_id);
CREATE INDEX idx_inventory_status ON inventory(status);

CREATE INDEX idx_warehouse_staff_user ON warehouse_staff(user_id);
CREATE INDEX idx_warehouse_staff_warehouse ON warehouse_staff(warehouse_id);

CREATE INDEX idx_inventory_transactions_inventory ON inventory_transactions(inventory_id);
CREATE INDEX idx_inventory_transactions_type ON inventory_transactions(transaction_type);

-- =====================================================
-- CONSTRAINTS
-- =====================================================
ALTER TABLE inventory ADD CONSTRAINT chk_inventory_quantity CHECK (quantity > 0);
ALTER TABLE inventory ADD CONSTRAINT chk_inventory_weight CHECK (weight IS NULL OR weight > 0);
ALTER TABLE warehouses ADD CONSTRAINT chk_utilization CHECK (current_utilization >= 0 AND current_utilization <= 100);

COMMENT ON TABLE warehouses IS 'Physical warehouse facilities for cargo storage';
COMMENT ON TABLE inventory IS 'Inventory items stored in warehouses';
COMMENT ON TABLE warehouse_staff IS 'Staff assignments to warehouses';
