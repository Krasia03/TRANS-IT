-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Seeds: Core Users and Drivers
-- =====================================================

-- Insert admin user (password: admin123)
INSERT INTO users (id, name, email, password_hash, phone, role, status) VALUES
('a0eebc99-9c0b-4ef8-b0d6-1f4a8c6b7d2e', 'Admin User', 'admin@transit.co.tz', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+255 800 123 456', 'admin', 'active'),
('b1ffcd88-8d1a-5dg9-c1e7-2g5b9d7c8e3f', 'John Mwakasege', 'john.mwakasege@transit.co.tz', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+255 712 345 678', 'driver', 'active'),
('c2ggbd77-9e2b-6eh0-d2f8-3h6c0e8d9f4g', 'Samira Komba', 'samira.komba@transit.co.tz', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+255 765 432 109', 'driver', 'active'),
('d3hhce66-0f3c-7fi1-e3g9-4i7d1f9e0g5h', 'Emmanuel Msafiri', 'emmanuel.msafiri@transit.co.tz', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+255 678 901 234', 'driver', 'active'),
('e4iidf55-1g4d-8gj2-f4h0-5j8e2g0f1h6i', 'Grace Lola', 'grace.lola@transit.co.tz', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+255 654 321 098', 'driver', 'active');

-- Insert drivers
INSERT INTO drivers (id, user_id, license_number, license_expiry, phone, emergency_contact, status, hire_date, rating) VALUES
('f5jjeg44-2h5e-9hk3-g5i1-6k9f3h1g2i7j', 'b1ffcd88-8d1a-5dg9-c1e7-2g5b9d7c8e3f', 'DL-2020-1234', '2027-08-15', '+255 712 345 678', '+255 712 345 679', 'available', '2020-03-15', 4.8),
('g6kkfh33-3i6f-0il4-h6j2-7l0g4i2h3j8k', 'c2ggbd77-9e2b-6eh0-d2f8-3h6c0e8d9f4g', 'DL-2019-5678', '2026-03-20', '+255 765 432 109', '+255 765 432 110', 'available', '2019-06-01', 4.6),
('h7llgi22-4j7g-1jm5-i7k3-8m1h5j3i4k9l', 'd3hhce66-0f3c-7fi1-e3g9-4i7d1f9e0g5h', 'DL-2021-9012', '2028-01-10', '+255 678 901 234', '+255 678 901 235', 'available', '2021-09-01', 4.9),
('i8mmhj11-5k8h-2kn6-j8l4-9n2i6k4j5l0m', 'e4iidf55-1g4d-8gj2-f4h0-5j8e2g0f1h6i', 'DL-2018-3456', '2025-11-30', '+255 654 321 098', '+255 654 321 099', 'off_duty', '2018-01-15', 4.5);
