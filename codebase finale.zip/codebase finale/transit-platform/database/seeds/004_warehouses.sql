-- =====================================================
-- TRANS-IT Seeds: Warehouses
-- =====================================================
INSERT INTO warehouses (id, name, code, city, region, capacity_sqm, current_utilization, status) VALUES
('w1a2b3c4-5d6e-7f8a-9b0c-1d2e3f4a5b6c', 'Dar es Salaam Hub', 'DAR-01', 'Dar es Salaam', 'Dar es Salaam', 10000, 78, 'active'),
('w2b3c4d5-6e7f-8a9b-0c1d-2e3f4a5b6c7d', 'Arusha Depot', 'ARU-01', 'Arusha', 'Arusha', 5000, 45, 'active'),
('w3c4d5e6-7f8a-9b0c-1d2e-3f4a5b6c7d8e', 'Mwanza Terminal', 'MWZ-01', 'Mwanza', 'Mwanza', 3500, 62, 'active');
