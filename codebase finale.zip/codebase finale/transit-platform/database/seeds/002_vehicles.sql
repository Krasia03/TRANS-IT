-- =====================================================
-- TRANS-IT Fleet/Logistics Management Platform
-- Seeds: Vehicles and Fleet
-- =====================================================

-- Insert vehicles
INSERT INTO vehicles (id, plate_number, make, model, year, type, capacity_kg, fuel_type, status, last_service_date, next_service_date) VALUES
('a1b2c3d4-5e6f-7g8h-9i0j-1k2l3m4n5o6p', 'TZ-1234', 'Isuzu', 'NMR 250', 2022, 'truck', 5000, 'diesel', 'in_use', '2026-03-01', '2026-06-01'),
('b2c3d4e5-6f7g-8h9i-0j1k-2l3m4n5o6p7q', 'TZ-2345', 'Hino', 'FG 175', 2021, 'flatbed', 8000, 'diesel', 'available', '2026-02-15', '2026-05-15'),
('c3d4e5f6-7g8h-9i0j-1k2l-3m4n5o6p7q8r', 'TZ-3456', 'Mercedes', 'Actros 2528', 2023, 'trailer', 25000, 'diesel', 'maintenance', '2026-01-20', '2026-04-20'),
('d4e5f6g7-8h9i-0j1k-2l3m-4n5o6p7q8r9s', 'TZ-4567', 'Foton', 'Aumark BJ1086', 2020, 'van', 2000, 'diesel', 'in_use', '2026-03-10', '2026-06-10'),
('e5f6g7h8-9i0j-1k2l-3m4n-5o6p7q8r9s0t', 'TZ-5678', 'Toyota', 'Dyna 150', 2019, 'refrigerated', 3500, 'diesel', 'available', '2026-02-28', '2026-05-28'),
('f6g7h8i9-0j1k-2l3m-4n5o-6p7q8r9s0t1u', 'TZ-6789', 'Isuzu', 'D-Max', 2021, 'truck', 4500, 'diesel', 'available', '2026-03-05', '2026-06-05'),
('g7h8i9j0-1k2l-3m4n-5o6p-7q8r9s0t1u2v', 'TZ-7890', 'Hino', '300', 2022, 'van', 3000, 'diesel', 'in_use', '2026-02-20', '2026-05-20');

-- Insert vehicle locations (latest positions)
INSERT INTO vehicle_locations (vehicle_id, latitude, longitude, h3_index, speed, heading, recorded_at) VALUES
('a1b2c3d4-5e6f-7g8h-9i0j-1k2l3m4n5o6p', -6.7929, 39.2083, '86283082fffffff', 45, 90, NOW()),
('d4e5f6g7-8h9i-0j1k-2l3m-4n5o6p7q8r9s', -3.6674, 39.2610, '86283083fffffff', 60, 270, NOW()),
('g7h8i9j0-1k2l-3m4n-5o6p-7q8r9s0t1u2v', -6.3690, 34.5846, '86283080fffffff', 0, 0, NOW());
