'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Plus, UserCog, Shield, Search } from 'lucide-react'

const users = [
  { id: '1', name: 'Admin User', email: 'admin@transit.co.tz', role: 'admin', status: 'active', lastLogin: '2026-04-15' },
  { id: '2', name: 'John Mwakasege', email: 'john.mwakasege@transit.co.tz', role: 'driver', status: 'active', lastLogin: '2026-04-14' },
]

const columns: TableColumn<typeof users[0]>[] = [
  { key: 'name', header: 'User', render: (item) => <div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-royal text-xs font-medium text-white">{item.name.split(' ').map(n => n[0]).join('')}</div><span className="font-medium">{item.name}</span></div> },
  { key: 'email', header: 'Email' },
  { key: 'role', header: 'Role', render: (item) => <span className="capitalize">{item.role}</span> },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
  { key: 'lastLogin', header: 'Last Login' },
]

export default function UsersPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">User Management</h1><p className="text-neutral-500">Manage system users and permissions.</p></div><Button><Plus className="h-4 w-4" />Add User</Button></div>
        <Card padding="none"><Table columns={columns} data={users} keyExtractor={(item) => item.id} /></Card>
      </div>
    </AdminLayout>
  )
}
