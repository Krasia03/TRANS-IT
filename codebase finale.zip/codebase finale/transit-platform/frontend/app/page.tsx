'use client';

import { useEffect, useState } from 'react';
import { commandCenterAPI } from '@/lib/api';
import { CommandCenterDashboard } from '@/types';
import { Card } from '@/components/ui/Card';
import { RevenueChart } from '@/components/charts/RevenueChart';
import { 
  Truck, Users, Package, AlertTriangle, TrendingUp, Clock,
  Fuel, MapPin, Activity
} from 'lucide-react';

export default function DashboardPage() {
  const [dashboard, setDashboard] = useState<CommandCenterDashboard | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const response = await commandCenterAPI.getDashboard();
        setDashboard(response.data.data);
      } catch (error) {
        console.error('Failed to fetch dashboard:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-royalBlue"></div>
      </div>
    );
  }

  const stats = [
    { label: 'Active Vehicles', value: dashboard?.active_vehicles ?? 0, icon: Truck, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Active Drivers', value: dashboard?.active_drivers ?? 0, icon: Users, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Pending Cargo', value: dashboard?.pending_cargo ?? 0, icon: Package, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'In Transit', value: dashboard?.in_transit_cargo ?? 0, icon: MapPin, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'Critical Alerts', value: dashboard?.critical_alerts ?? 0, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-100' },
    { label: 'Pending Alerts', value: dashboard?.pending_alerts ?? 0, icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-100' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Dashboard</h1>
          <p className="text-neutral-500 mt-1">Welcome to TRANS-IT Command Center</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-neutral-500">
          <Activity className="w-4 h-4" />
          <span>Last updated: {new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">{stat.label}</p>
                <p className="text-2xl font-bold text-neutral-900 mt-1">{stat.value}</p>
              </div>
              <div className={`p-3 rounded-full ${stat.bg}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-neutral-900">Revenue Overview</h2>
            <TrendingUp className="w-5 h-5 text-neutral-400" />
          </div>
          <RevenueChart />
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-neutral-900">Fleet Status</h2>
            <Truck className="w-5 h-5 text-neutral-400" />
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="text-sm text-neutral-600">Active</span>
              </div>
              <span className="text-sm font-medium">{dashboard?.active_vehicles ?? 0} vehicles</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <span className="text-sm text-neutral-600">Idle</span>
              </div>
              <span className="text-sm font-medium">12 vehicles</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span className="text-sm text-neutral-600">Maintenance</span>
              </div>
              <span className="text-sm font-medium">5 vehicles</span>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Recent Alerts</h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-neutral-900">Speed Violation</p>
                <p className="text-xs text-neutral-500">Vehicle T 123 ABC - 85 km/h in 60 zone</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
              <Fuel className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-neutral-900">Low Fuel Alert</p>
                <p className="text-xs text-neutral-500">Vehicle T 456 DEF - 15% fuel level</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
              <Clock className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-neutral-900">Maintenance Due</p>
                <p className="text-xs text-neutral-500">Vehicle T 789 GHI - Service in 500 km</p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Today's Activity</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2 border-b border-neutral-100">
              <span className="text-sm text-neutral-600">Deliveries Completed</span>
              <span className="text-lg font-semibold text-green-600">24</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-neutral-100">
              <span className="text-sm text-neutral-600">Pickups Scheduled</span>
              <span className="text-lg font-semibold text-blue-600">18</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-neutral-100">
              <span className="text-sm text-neutral-600">Avg Delivery Time</span>
              <span className="text-lg font-semibold text-neutral-900">2.4h</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-neutral-600">Customer Satisfaction</span>
              <span className="text-lg font-semibold text-accent-goldenYellow">4.8/5</span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Quick Actions</h2>
          <div className="space-y-2">
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Create New Dispatch
            </button>
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Add New Vehicle
            </button>
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Register Driver
            </button>
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Create Cargo Request
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
