'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Plus, Download, Search, FileText, DollarSign } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const invoices = [
  {
    id: '1',
    invoiceNumber: 'INV-2026-001',
    customerName: 'Acme Corporation',
    customerType: 'corporate',
    items: 3,
    subtotal: 750000,
    tax: 112500,
    total: 862500,
    status: 'sent',
    dueDate: '2026-04-30',
  },
  {
    id: '2',
    invoiceNumber: 'INV-2026-002',
    customerName: 'John Doe',
    customerType: 'individual',
    items: 1,
    subtotal: 125000,
    tax: 18750,
    total: 143750,
    status: 'paid',
    dueDate: '2026-04-20',
  },
  {
    id: '3',
    invoiceNumber: 'INV-2026-003',
    customerName: 'TanzFood Ltd',
    customerType: 'corporate',
    items: 5,
    subtotal: 1100000,
    tax: 165000,
    total: 1265000,
    status: 'overdue',
    dueDate: '2026-04-10',
  },
]

const columns: TableColumn<typeof invoices[0]>[] = [
  {
    key: 'invoiceNumber',
    header: 'Invoice',
    render: (item) => (
      <div className="flex items-center gap-2">
        <FileText className="h-5 w-5 text-neutral-400" />
        <span className="font-medium text-neutral-900">{item.invoiceNumber}</span>
      </div>
    ),
  },
  {
    key: 'customer',
    header: 'Customer',
    render: (item) => (
      <div>
        <p className="font-medium text-neutral-900">{item.customerName}</p>
        <p className="text-xs text-neutral-500 capitalize">{item.customerType}</p>
      </div>
    ),
  },
  { key: 'items', header: 'Items' },
  {
    key: 'total',
    header: 'Amount',
    render: (item) => (
      <span className="font-semibold">{formatCurrency(item.total)}</span>
    ),
  },
  {
    key: 'status',
    header: 'Status',
    render: (item) => <StatusBadge status={item.status} />,
  },
  { key: 'dueDate', header: 'Due Date' },
]

export default function InvoicesPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Invoice Management</h1>
            <p className="text-neutral-500">Create and manage client invoices.</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4" />
              Create Invoice
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-royal/10 p-2">
                <FileText className="h-5 w-5 text-primary-royal" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Total Invoiced</p>
                <p className="text-xl font-bold text-neutral-900">45.2M TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-success/10 p-2">
                <DollarSign className="h-5 w-5 text-semantic-success" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Collected</p>
                <p className="text-xl font-bold text-semantic-success">32.8M TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-warning/10 p-2">
                <FileText className="h-5 w-5 text-semantic-warning" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Pending</p>
                <p className="text-xl font-bold text-semantic-warning">8.5M TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-error/10 p-2">
                <FileText className="h-5 w-5 text-semantic-error" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Overdue</p>
                <p className="text-xl font-bold text-semantic-error">3.9M TZS</p>
              </div>
            </div>
          </Card>
        </div>

        <Card padding="none">
          <Table columns={columns} data={invoices} keyExtractor={(item) => item.id} />
        </Card>
      </div>
    </AdminLayout>
  )
}
