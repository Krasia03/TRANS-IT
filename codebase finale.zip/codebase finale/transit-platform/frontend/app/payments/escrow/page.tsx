'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { DollarSign, Shield, Lock } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const escrowAccounts = [
  { id: '1', customerId: 'CUST-001', customerName: 'Acme Corporation', balance: 2500000, heldAmount: 500000, status: 'active' },
  { id: '2', customerId: 'CUST-002', customerName: 'TanzFood Ltd', balance: 1800000, heldAmount: 750000, status: 'active' },
  { id: '3', customerId: 'CUST-003', customerName: 'John Doe', balance: 450000, heldAmount: 0, status: 'active' },
]

const columns: TableColumn<typeof escrowAccounts[0]>[] = [
  { key: 'customerName', header: 'Customer' },
  { key: 'customerId', header: 'Customer ID' },
  { key: 'balance', header: 'Balance', render: (item) => <span className="font-medium">{formatCurrency(item.balance)}</span> },
  { key: 'heldAmount', header: 'Held Amount', render: (item) => <span className="text-primary-golden">{formatCurrency(item.heldAmount)}</span> },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
]

export default function EscrowPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Escrow Accounts</h1>
          <p className="text-neutral-500">Manage customer escrow accounts for secure payments.</p>
        </div>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-royal/10 p-2"><DollarSign className="h-5 w-5 text-primary-royal" /></div>
              <div><p className="text-sm text-neutral-500">Total Escrow</p><p className="text-xl font-bold text-neutral-900">12.5M TZS</p></div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-golden/10 p-2"><Lock className="h-5 w-5 text-primary-golden" /></div>
              <div><p className="text-sm text-neutral-500">Held in Escrow</p><p className="text-xl font-bold text-primary-golden">2.8M TZS</p></div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-success/10 p-2"><Shield className="h-5 w-5 text-semantic-success" /></div>
              <div><p className="text-sm text-neutral-500">Available</p><p className="text-xl font-bold text-semantic-success">9.7M TZS</p></div>
            </div>
          </Card>
        </div>
        <Card padding="none"><Table columns={columns} data={escrowAccounts} keyExtractor={(item) => item.id} /></Card>
      </div>
    </AdminLayout>
  )
}
