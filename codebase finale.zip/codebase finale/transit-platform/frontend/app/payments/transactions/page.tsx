'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Table, type TableColumn, Badge } from '@/components/ui'
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const transactions = [
  { id: '1', type: 'credit', amount: 850000, method: 'mobile_money', reference: 'TRX-123456', description: 'Payment from Acme Corp', date: '2026-04-15' },
  { id: '2', type: 'debit', amount: 120000, method: 'bank_transfer', reference: 'TRX-123457', description: 'Fuel expense - TZ-1234', date: '2026-04-14' },
  { id: '3', type: 'credit', amount: 125000, method: 'mobile_money', reference: 'TRX-123458', description: 'Payment from John Doe', date: '2026-04-14' },
]

const columns: TableColumn<typeof transactions[0]>[] = [
  { key: 'date', header: 'Date' },
  { key: 'type', header: 'Type', render: (item) => <div className={`flex items-center gap-2 ${item.type === 'credit' ? 'text-semantic-success' : 'text-semantic-error'}`}>{item.type === 'credit' ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}<span className="capitalize">{item.type}</span></div> },
  { key: 'amount', header: 'Amount', render: (item) => <span className={`font-medium ${item.type === 'credit' ? 'text-semantic-success' : 'text-semantic-error'}`}>{item.type === 'credit' ? '+' : '-'}{formatCurrency(item.amount)}</span> },
  { key: 'method', header: 'Method' },
  { key: 'reference', header: 'Reference' },
  { key: 'description', header: 'Description' },
]

export default function TransactionsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div><h1 className="text-2xl font-bold text-neutral-900">Payment Transactions</h1><p className="text-neutral-500">View all payment history.</p></div>
        <Card padding="none"><Table columns={columns} data={transactions} keyExtractor={(item) => item.id} /></Card>
      </div>
    </AdminLayout>
  )
}
