'use client'

import { Card, Button, Checkbox } from '@/components/ui'
import { ClipboardCheck } from 'lucide-react'

const checklist = ['Tires', 'Brakes', 'Lights', 'Fluids', 'Engine', 'Body']

export default function VehiclePage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Vehicle Inspection</h1><p className="text-neutral-500">Pre-trip vehicle checklist.</p></div>
      <Card padding="lg">
        <div className="mb-6"><h3 className="font-semibold text-neutral-900">Assigned Vehicle: TZ-1234</h3><p className="text-sm text-neutral-500">Isuzu NMR 250</p></div>
        <div className="space-y-4">
          {checklist.map((item) => (<div key={item} className="flex items-center justify-between rounded-lg border border-neutral-200 p-4"><span className="font-medium">{item}</span><Checkbox /></div>))}
        </div>
        <div className="mt-6"><Button><ClipboardCheck className="h-4 w-4" />Submit Inspection</Button></div>
      </Card>
    </div>
  )
}
