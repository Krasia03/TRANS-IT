'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { 
  User, Truck, MapPin, Clock, Star, Fuel, Phone,
  Navigation, CheckCircle, AlertCircle
} from 'lucide-react';

export default function DriverPortal() {
  const [activeDelivery] = useState({
    id: 'CRG-123',
    pickup: 'Dar es Salaam Warehouse',
    delivery: 'Arusha Distribution Center',
    distance: '45 km',
    eta: '2h 30m',
    status: 'in_transit',
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center">
            <User className="w-6 h-6 text-primary-royalBlue" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-neutral-900">Welcome, John Kamau</h1>
            <p className="text-sm text-neutral-500">Driver ID: DRV-001234</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-green-100 text-green-800">Online</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4 text-center">
          <Star className="w-6 h-6 text-accent-goldenYellow mx-auto" />
          <p className="text-2xl font-bold text-neutral-900 mt-2">4.8</p>
          <p className="text-sm text-neutral-500">Rating</p>
        </Card>
        <Card className="p-4 text-center">
          <Truck className="w-6 h-6 text-blue-600 mx-auto" />
          <p className="text-2xl font-bold text-neutral-900 mt-2">1,234</p>
          <p className="text-sm text-neutral-500">Total Deliveries</p>
        </Card>
        <Card className="p-4 text-center">
          <CheckCircle className="w-6 h-6 text-green-600 mx-auto" />
          <p className="text-2xl font-bold text-neutral-900 mt-2">98%</p>
          <p className="text-sm text-neutral-500">Success Rate</p>
        </Card>
        <Card className="p-4 text-center">
          <Clock className="w-6 h-6 text-purple-600 mx-auto" />
          <p className="text-2xl font-bold text-neutral-900 mt-2">156h</p>
          <p className="text-sm text-neutral-500">Online This Month</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Current Delivery</h2>
          {activeDelivery && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                    <Navigation className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-neutral-900">{activeDelivery.id}</p>
                    <p className="text-sm text-neutral-500">In Transit</p>
                  </div>
                </div>
                <Button size="sm">Navigate</Button>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 rounded-full bg-white" />
                  </div>
                  <div>
                    <p className="font-medium text-neutral-900">Pickup</p>
                    <p className="text-sm text-neutral-500">{activeDelivery.pickup}</p>
                  </div>
                </div>
                <div className="ml-4 border-l-2 border-dashed border-neutral-300 h-6" />
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 rounded-full bg-white" />
                  </div>
                  <div>
                    <p className="font-medium text-neutral-900">Delivery</p>
                    <p className="text-sm text-neutral-500">{activeDelivery.delivery}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-200">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-neutral-400" />
                  <span className="text-neutral-600">Distance:</span>
                  <span className="font-medium">{activeDelivery.distance}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-neutral-400" />
                  <span className="text-neutral-600">ETA:</span>
                  <span className="font-medium">{activeDelivery.eta}</span>
                </div>
              </div>
            </div>
          )}
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Vehicle Status</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-neutral-600">Vehicle</span>
              <span className="font-medium">T-123 ABC</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-neutral-600">Fuel Level</span>
              <div className="flex items-center gap-2">
                <div className="w-20 h-2 bg-neutral-200 rounded-full overflow-hidden">
                  <div className="w-3/4 h-full bg-green-500" />
                </div>
                <span className="text-sm font-medium">75%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-neutral-600">Odometer</span>
              <span className="font-medium">45,678 km</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-neutral-600">Next Service</span>
              <span className="font-medium text-yellow-600">500 km</span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-neutral-200">
            <h3 className="text-sm font-semibold text-neutral-900 mb-3">Quick Actions</h3>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <CheckCircle className="w-4 h-4 mr-2" />
                Complete Delivery
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <AlertCircle className="w-4 h-4 mr-2" />
                Report Issue
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Fuel className="w-4 h-4 mr-2" />
                Log Fuel
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h2 className="text-lg font-semibold text-neutral-900 mb-4">Upcoming Schedule</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary-100 flex items-center justify-center">
                <Truck className="w-5 h-5 text-primary-royalBlue" />
              </div>
              <div>
                <p className="font-medium text-neutral-900">Morning Route</p>
                <p className="text-sm text-neutral-500">8:00 AM - 12:00 PM</p>
              </div>
            </div>
            <Badge>3 Deliveries</Badge>
          </div>
          <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                <Truck className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-neutral-900">Afternoon Route</p>
                <p className="text-sm text-neutral-500">1:00 PM - 5:00 PM</p>
              </div>
            </div>
            <Badge>2 Deliveries</Badge>
          </div>
        </div>
      </Card>
    </div>
  );
}
