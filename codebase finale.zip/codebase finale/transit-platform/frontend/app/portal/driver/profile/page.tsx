'use client'

import { Card, Button, Input } from '@/components/ui'
import { User, Mail, Phone, MapPin } from 'lucide-react'

export default function ProfilePage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Profile</h1><p className="text-neutral-500">Manage your profile information.</p></div>
      <Card padding="lg">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary-royal text-xl font-bold text-white">JM</div>
          <div><p className="font-semibold text-neutral-900">John Mwakasege</p><p className="text-sm text-neutral-500">Driver</p></div>
        </div>
        <form className="space-y-4">
          <Input label="First Name" defaultValue="John" />
          <Input label="Last Name" defaultValue="Mwakasege" />
          <Input label="Email" type="email" defaultValue="john.mwakasege@transit.co.tz" />
          <Input label="Phone" defaultValue="+255 712 345 678" />
          <div className="flex justify-end"><Button>Save Changes</Button></div>
        </form>
      </Card>
    </div>
  )
}
