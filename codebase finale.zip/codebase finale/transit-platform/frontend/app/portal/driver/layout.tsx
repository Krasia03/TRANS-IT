'use client'

import type { ReactNode } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useAuthStore } from '@/lib/store/auth'
import { LayoutDashboard, Truck, MapPin, DollarSign, User, Bell, LogOut } from 'lucide-react'

export default function DriverLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const { user, logout } = useAuthStore()
  const navItems = [
    { href: '/portal/driver/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/portal/driver/trips', label: 'Trips', icon: Truck },
    { href: '/portal/driver/vehicle', label: 'Vehicle', icon: Truck },
    { href: '/portal/driver/earnings', label: 'Earnings', icon: DollarSign },
    { href: '/portal/driver/profile', label: 'Profile', icon: User },
  ]

  return (
    <div className="min-h-screen bg-neutral-50">
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-neutral-200 bg-white px-4 lg:px-6">
        <Link href="/portal/driver/dashboard" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-royal"><span className="text-lg font-bold text-white">T</span></div>
          <span className="text-lg font-bold text-neutral-900">TRANS-IT</span>
          <span className="hidden text-sm font-medium text-neutral-500 lg:inline">Driver</span>
        </Link>
        <div className="flex items-center gap-2">
          <button className="relative rounded-lg p-2 text-neutral-500 hover:bg-neutral-100"><Bell className="h-5 w-5" /></button>
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-golden text-sm font-medium text-neutral-900">{user?.firstName?.[0]}{user?.lastName?.[0]}</div>
          <button onClick={logout} className="rounded-lg p-2 text-neutral-500 hover:bg-neutral-100"><LogOut className="h-5 w-5" /></button>
        </div>
      </header>
      <div className="flex">
        <aside className="sticky top-16 hidden h-[calc(100vh-4rem)] w-64 flex-col border-r border-neutral-200 bg-white p-4 lg:flex">
          <nav className="space-y-1">{navItems.map((item) => (<Link key={item.href} href={item.href} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors', pathname === item.href ? 'bg-primary-royal/10 text-primary-royal' : 'text-neutral-600 hover:bg-neutral-100')}><item.icon className="h-5 w-5" />{item.label}</Link>))}</nav>
        </aside>
        <main className="flex-1 p-4 lg:p-6">{children}</main>
      </div>
    </div>
  )
}
