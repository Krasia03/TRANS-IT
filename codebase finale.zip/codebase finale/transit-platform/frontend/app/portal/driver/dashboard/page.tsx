'use client'

import { Card, CardContent } from '@/components/ui'
import { Truck, DollarSign, Star, Clock } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const stats = [
  { title: 'Active Trip', value: '1', icon: Truck, color: 'text-semantic-info' },
  { title: 'Today\'s Earnings', value: formatCurrency(185000), icon: DollarSign, color: 'text-semantic-success' },
  { title: 'Rating', value: '4.8', icon: Star, color: 'text-primary-golden' },
  { title: 'Completed Trips', value: '156', icon: Clock, color: 'text-primary-royal' },
]

export default function DriverDashboard() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Welcome back!</h1><p className="text-neutral-500">Your trip overview.</p></div>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((stat) => (<Card key={stat.title} padding="md"><CardContent><div className="flex items-start justify-between"><div><p className="text-sm text-neutral-500">{stat.title}</p><p className="text-xl font-bold text-neutral-900">{stat.value}</p></div><stat.icon className={`h-5 w-5 ${stat.color}`} /></div></CardContent></Card>))}
      </div>
    </div>
  )
}
