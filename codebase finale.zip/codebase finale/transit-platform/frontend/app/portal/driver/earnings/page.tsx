'use client'

import { Card, CardContent } from '@/components/ui'
import { DollarSign, TrendingUp, Calendar } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

export default function EarningsPage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Earnings</h1><p className="text-neutral-500">Your earnings breakdown.</p></div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-semantic-success/10 p-2"><DollarSign className="h-5 w-5 text-semantic-success" /></div><div><p className="text-sm text-neutral-500">This Month</p><p className="text-xl font-bold text-neutral-900">{formatCurrency(4500000)}</p></div></div></Card>
        <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-royal/10 p-2"><TrendingUp className="h-5 w-5 text-primary-royal" /></div><div><p className="text-sm text-neutral-500">Bonus</p><p className="text-xl font-bold text-neutral-900">{formatCurrency(320000)}</p></div></div></Card>
        <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-golden/10 p-2"><Calendar className="h-5 w-5 text-primary-golden" /></div><div><p className="text-sm text-neutral-500">Trips</p><p className="text-xl font-bold text-neutral-900">42</p></div></div></Card>
      </div>
    </div>
  )
}
