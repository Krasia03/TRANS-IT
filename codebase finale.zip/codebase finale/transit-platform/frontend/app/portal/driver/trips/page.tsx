'use client'

import { Card, Button, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Truck, MapPin, Clock, Navigation } from 'lucide-react'

const trips = [
  { id: '1', trackingNumber: 'TRT-ABC123', origin: 'Dar es Salaam', destination: 'Arusha', pickupTime: '08:00 AM', status: 'in_progress' },
  { id: '2', trackingNumber: 'TRT-DEF456', origin: 'Mwanza', destination: 'Dodoma', pickupTime: '10:00 AM', status: 'pending' },
]

const columns: TableColumn<typeof trips[0]>[] = [
  { key: 'trackingNumber', header: 'Shipment', render: (item) => <span className="font-mono font-medium text-primary-royal">{item.trackingNumber}</span> },
  { key: 'origin', header: 'From' },
  { key: 'destination', header: 'To' },
  { key: 'pickupTime', header: 'Pickup Time', render: (item) => <div className="flex items-center gap-1"><Clock className="h-4 w-4 text-neutral-400" />{item.pickupTime}</div> },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
]

export default function TripsPage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">My Trips</h1><p className="text-neutral-500">View and manage your assigned trips.</p></div>
      <Card padding="none"><Table columns={columns} data={trips} keyExtractor={(item) => item.id} /></Card>
    </div>
  )
}
