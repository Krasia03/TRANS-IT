'use client'

import { Card, Button, StatusBadge } from '@/components/ui'
import { MapPin, Truck, Navigation, CheckCircle } from 'lucide-react'

export default function TripDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">TRT-ABC123</h1><p className="text-neutral-500">Trip Details</p></div><StatusBadge status="in_progress" /></div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="lg">
          <h3 className="font-semibold text-neutral-900 mb-4">Route</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3"><div className="rounded-full bg-semantic-success/10 p-2"><Truck className="h-5 w-5 text-semantic-success" /></div><div><p className="font-medium">Dar es Salaam</p><p className="text-sm text-neutral-500">Pickup Point</p></div></div>
            <div className="flex items-start gap-3"><div className="rounded-full bg-primary-royal/10 p-2"><MapPin className="h-5 w-5 text-primary-royal" /></div><div><p className="font-medium">Arusha</p><p className="text-sm text-neutral-500">Delivery Point</p></div></div>
          </div>
        </Card>
        <Card padding="lg">
          <h3 className="font-semibold text-neutral-900 mb-4">Actions</h3>
          <div className="flex flex-col gap-3">
            <Button><Navigation className="h-4 w-4" />Start Navigation</Button>
            <Button variant="success"><CheckCircle className="h-4 w-4" />Mark as Delivered</Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
