'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Table } from '@/components/ui/Table';
import { Plus, Search, Filter, Truck, Eye } from 'lucide-react';

export default function CargoOwnerPortal() {
  const [cargoRequests] = useState([
    { id: 1, tracking: 'TRK123456', pickup: 'Dar es Salaam', delivery: 'Arusha', status: 'in_transit', price: 250000, date: '2024-01-15' },
    { id: 2, tracking: 'TRK123457', pickup: 'Mwanza', delivery: 'Dodoma', status: 'delivered', price: 180000, date: '2024-01-14' },
    { id: 3, tracking: 'TRK123458', pickup: 'Zanzibar', delivery: 'Kigoma', status: 'pending', price: 320000, date: '2024-01-16' },
  ]);

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    in_transit: 'bg-blue-100 text-blue-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">My Cargo</h1>
          <p className="text-neutral-500 mt-1">Track and manage your shipments</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Shipment
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
          <input
            type="text"
            placeholder="Search by tracking number..."
            className="w-full pl-10 pr-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary-royalBlue focus:border-transparent outline-none"
          />
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Filter className="w-4 h-4" />
          Filter
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4 text-center">
          <p className="text-sm text-neutral-500">Total Shipments</p>
          <p className="text-2xl font-bold text-neutral-900 mt-1">156</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-sm text-neutral-500">In Transit</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">12</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-sm text-neutral-500">Delivered</p>
          <p className="text-2xl font-bold text-green-600 mt-1">142</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-sm text-neutral-500">Total Spent</p>
          <p className="text-2xl font-bold text-neutral-900 mt-1">TZS 45.2M</p>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <Table>
          <Table.Header>
            <Table.Row>
              <Table.Head>Tracking</Table.Head>
              <Table.Head>Pickup</Table.Head>
              <Table.Head>Delivery</Table.Head>
              <Table.Head>Status</Table.Head>
              <Table.Head>Price</Table.Head>
              <Table.Head>Date</Table.Head>
              <Table.Head>Actions</Table.Head>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {cargoRequests.map((cargo) => (
              <Table.Row key={cargo.id}>
                <Table.Cell className="font-mono text-sm">{cargo.tracking}</Table.Cell>
                <Table.Cell>{cargo.pickup}</Table.Cell>
                <Table.Cell>{cargo.delivery}</Table.Cell>
                <Table.Cell>
                  <Badge className={statusColors[cargo.status]}>
                    {cargo.status.replace('_', ' ')}
                  </Badge>
                </Table.Cell>
                <Table.Cell>TZS {cargo.price.toLocaleString()}</Table.Cell>
                <Table.Cell>{cargo.date}</Table.Cell>
                <Table.Cell>
                  <Button variant="ghost" size="sm" className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    Track
                  </Button>
                </Table.Cell>
              </Table.Row>
            ))}
          </Table.Body>
        </Table>
      </Card>
    </div>
  );
}
