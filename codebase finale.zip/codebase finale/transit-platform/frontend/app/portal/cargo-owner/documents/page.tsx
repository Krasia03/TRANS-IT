'use client'

import { Card, Button } from '@/components/ui'
import { FileText, Upload, Download } from 'lucide-react'

const documents = [
  { id: '1', name: 'Business Registration', type: 'PDF', uploadedAt: '2026-01-15' },
  { id: '2', name: 'Tax Compliance Certificate', type: 'PDF', uploadedAt: '2026-02-20' },
]

export default function DocumentsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">Documents</h1><p className="text-neutral-500">Manage your business documents.</p></div><Button><Upload className="h-4 w-4" />Upload</Button></div>
      <div className="space-y-3">
        {documents.map((doc) => (
          <Card key={doc.id} padding="md" className="flex items-center justify-between">
            <div className="flex items-center gap-3"><FileText className="h-5 w-5 text-primary-royal" /><div><p className="font-medium">{doc.name}</p><p className="text-sm text-neutral-500">{doc.type} • {doc.uploadedAt}</p></div></div>
            <Button variant="ghost" size="icon"><Download className="h-4 w-4" /></Button>
          </Card>
        ))}
      </div>
    </div>
  )
}
