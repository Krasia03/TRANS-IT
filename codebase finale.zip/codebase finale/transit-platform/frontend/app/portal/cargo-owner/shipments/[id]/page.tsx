'use client'

import { Card, StatusBadge, Button } from '@/components/ui'
import { MapPin, Truck, Clock, Package } from 'lucide-react'

export default function ShipmentDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-neutral-900">TRT-ABC123</h1><p className="text-neutral-500">Shipment Details</p></div>
        <StatusBadge status="in_transit" />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="lg">
          <h3 className="font-semibold text-neutral-900 mb-4">Route Information</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-semantic-success/10 p-2"><Package className="h-5 w-5 text-semantic-success" /></div>
              <div><p className="font-medium">Dar es Salaam</p><p className="text-sm text-neutral-500">Pickup: Apr 16, 2026</p></div>
            </div>
            <div className="ml-4 border-l-2 border-dashed border-neutral-300 h-8" />
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary-royal/10 p-2"><MapPin className="h-5 w-5 text-primary-royal" /></div>
              <div><p className="font-medium">Arusha</p><p className="text-sm text-neutral-500">Delivery: Expected Apr 17, 2026</p></div>
            </div>
          </div>
        </Card>
        <Card padding="lg">
          <h3 className="font-semibold text-neutral-900 mb-4">Vehicle & Driver</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between"><span className="text-neutral-500">Vehicle</span><span className="font-medium">TZ-1234</span></div>
            <div className="flex items-center justify-between"><span className="text-neutral-500">Driver</span><span className="font-medium">John Mwakasege</span></div>
            <div className="flex items-center justify-between"><span className="text-neutral-500">ETA</span><span className="font-medium">2h 30m</span></div>
          </div>
        </Card>
      </div>
      <Card padding="none" className="relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center"><MapPin className="h-16 w-16 text-primary-royal/20" /><p className="mt-4 text-neutral-400">Live Tracking Map</p></div>
        <div className="h-64" />
      </Card>
    </div>
  )
}
