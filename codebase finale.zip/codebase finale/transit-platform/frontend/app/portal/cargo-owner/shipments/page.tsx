'use client'

import { Card, Button, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Plus, Package, Search } from 'lucide-react'

const shipments = [
  { id: '1', trackingNumber: 'TRT-ABC123', origin: 'Dar es Salaam', destination: 'Arusha', pickupDate: '2026-04-16', status: 'in_transit' },
  { id: '2', trackingNumber: 'TRT-DEF456', origin: 'Mwanza', destination: 'Dodoma', pickupDate: '2026-04-17', status: 'pending' },
  { id: '3', trackingNumber: 'TRT-GHI789', origin: 'Arusha', destination: 'Moshi', pickupDate: '2026-04-14', status: 'delivered' },
]

const columns: TableColumn<typeof shipments[0]>[] = [
  { key: 'trackingNumber', header: 'Tracking #', render: (item) => <span className="font-mono font-medium text-primary-royal">{item.trackingNumber}</span> },
  { key: 'origin', header: 'From' },
  { key: 'destination', header: 'To' },
  { key: 'pickupDate', header: 'Pickup Date' },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
]

export default function ShipmentsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">My Shipments</h1><p className="text-neutral-500">Track all your cargo shipments.</p></div><Button><Plus className="h-4 w-4" />New Booking</Button></div>
      <div className="relative max-w-md"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" /><input type="text" placeholder="Search shipments..." className="block w-full rounded-lg border border-neutral-300 bg-white pl-10 pr-4 py-2 text-sm" /></div>
      <Card padding="none"><Table columns={columns} data={shipments} keyExtractor={(item) => item.id} /></Card>
    </div>
  )
}
