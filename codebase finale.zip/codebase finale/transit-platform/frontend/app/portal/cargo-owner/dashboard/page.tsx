'use client'

import { Card, CardContent, Button } from '@/components/ui'
import { Package, MapPin, Clock, CheckCircle, Truck } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const stats = [
  { title: 'Active Shipments', value: '3', icon: Truck, color: 'text-semantic-info', bgColor: 'bg-semantic-info/10' },
  { title: 'Total Shipments', value: '24', icon: Package, color: 'text-primary-royal', bgColor: 'bg-primary-royal/10' },
  { title: 'Awaiting Pickup', value: '2', icon: Clock, color: 'text-semantic-warning', bgColor: 'bg-semantic-warning/10' },
  { title: 'Total Spent', value: formatCurrency(12500000), icon: CheckCircle, color: 'text-semantic-success', bgColor: 'bg-semantic-success/10' },
]

const recentShipments = [
  { id: '1', trackingNumber: 'TRT-ABC123', origin: 'Dar es Salaam', destination: 'Arusha', status: 'in_transit', eta: '2h 30m' },
  { id: '2', trackingNumber: 'TRT-DEF456', origin: 'Mwanza', destination: 'Dodoma', status: 'pending', pickup: 'Apr 17' },
  { id: '3', trackingNumber: 'TRT-GHI789', origin: 'Arusha', destination: 'Moshi', status: 'delivered', delivered: 'Apr 14' },
]

export default function CargoOwnerDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-neutral-900">Welcome back!</h1><p className="text-neutral-500">Track your shipments and manage bookings.</p></div>
        <Link href="/portal/cargo-owner/book"><Button><Package className="h-4 w-4" />New Booking</Button></Link>
      </div>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((stat) => (<Card key={stat.title} padding="md"><CardContent><div className="flex items-start justify-between"><div><p className="text-sm text-neutral-500">{stat.title}</p><p className="text-xl font-bold text-neutral-900">{stat.value}</p></div><div className={`rounded-lg p-2 ${stat.bgColor}`}><stat.icon className={`h-5 w-5 ${stat.color}`} /></div></div></CardContent></Card>))}
      </div>
      <Card padding="none">
        <div className="border-b border-neutral-100 px-6 py-4"><h3 className="font-semibold text-neutral-900">Recent Shipments</h3></div>
        <div className="divide-y divide-neutral-100">
          {recentShipments.map((shipment) => (
            <div key={shipment.id} className="flex items-center justify-between px-6 py-4 hover:bg-neutral-50 cursor-pointer">
              <div><p className="font-mono font-medium text-primary-royal">{shipment.trackingNumber}</p><p className="text-sm text-neutral-500">{shipment.origin} → {shipment.destination}</p></div>
              <div className="text-right"><p className="text-sm font-medium capitalize">{shipment.status.replace('_', ' ')}</p><p className="text-xs text-neutral-500">{shipment.eta || shipment.pickup || shipment.delivered}</p></div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
