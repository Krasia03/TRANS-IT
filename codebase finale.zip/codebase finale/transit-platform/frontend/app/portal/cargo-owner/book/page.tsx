'use client'

import { Card, Button, Input, Select } from '@/components/ui'
import { Package, MapPin, Calendar, ArrowRight } from 'lucide-react'

const categories = [
  { value: 'general', label: 'General Cargo' },
  { value: 'fragile', label: 'Fragile Items' },
  { value: 'perishable', label: 'Perishable Goods' },
  { value: 'hazardous', label: 'Hazardous Materials' },
]

export default function BookPage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">New Booking</h1><p className="text-neutral-500">Create a new cargo shipment booking.</p></div>
      <Card padding="lg">
        <form className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-4">Cargo Details</h3>
            <div className="grid gap-4 lg:grid-cols-2">
              <Select label="Cargo Category" options={categories} placeholder="Select category" />
              <Input label="Weight (kg)" type="number" placeholder="Enter weight" />
              <Input label="Volume (m³)" type="number" placeholder="Enter volume (optional)" />
              <Input label="Description" placeholder="Describe your cargo" />
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-4">Pickup Information</h3>
            <div className="grid gap-4 lg:grid-cols-2">
              <Input label="Pickup Address" placeholder="Enter pickup address" />
              <Input label="City/Region" placeholder="Enter city" />
              <Input label="Pickup Date" type="date" />
              <Input label="Contact Person" placeholder="Contact name" />
              <Input label="Contact Phone" placeholder="Phone number" />
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-4">Delivery Information</h3>
            <div className="grid gap-4 lg:grid-cols-2">
              <Input label="Delivery Address" placeholder="Enter delivery address" />
              <Input label="City/Region" placeholder="Enter city" />
              <Input label="Recipient Name" placeholder="Recipient name" />
              <Input label="Recipient Phone" placeholder="Phone number" />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline">Cancel</Button>
            <Button><Package className="h-4 w-4" />Submit Booking</Button>
          </div>
        </form>
      </Card>
    </div>
  )
}
