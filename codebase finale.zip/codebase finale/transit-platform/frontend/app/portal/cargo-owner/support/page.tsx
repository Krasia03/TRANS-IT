'use client'

import { Card, Button, Input } from '@/components/ui'
import { HelpCircle, Send, MessageSquare } from 'lucide-react'

export default function SupportPage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Support</h1><p className="text-neutral-500">Get help with your shipments.</p></div>
      <Card padding="lg">
        <h3 className="font-semibold text-neutral-900 mb-4">Submit a Ticket</h3>
        <form className="space-y-4">
          <Input label="Subject" placeholder="Enter subject" />
          <div className="space-y-1.5"><label className="block text-sm font-medium text-neutral-700">Message</label><textarea className="block w-full rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm" rows={4} placeholder="Describe your issue" /></div>
          <Button><Send className="h-4 w-4" />Submit Ticket</Button>
        </form>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card padding="md"><div className="flex items-center gap-3"><HelpCircle className="h-5 w-5 text-primary-royal" /><div><p className="font-medium">FAQ</p><p className="text-sm text-neutral-500">Find quick answers</p></div></div></Card>
        <Card padding="md"><div className="flex items-center gap-3"><MessageSquare className="h-5 w-5 text-primary-golden" /><div><p className="font-medium">Live Chat</p><p className="text-sm text-neutral-500">Chat with support</p></div></div></Card>
      </div>
    </div>
  )
}
