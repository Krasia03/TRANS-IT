'use client'

import { Card, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { FileText, Download } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const invoices = [{ id: '1', invoiceNumber: 'INV-2026-001', amount: 850000, status: 'paid', date: '2026-04-10', dueDate: '2026-04-25' }]

const columns: TableColumn<typeof invoices[0]>[] = [
  { key: 'invoiceNumber', header: 'Invoice', render: (item) => <div className="flex items-center gap-2"><FileText className="h-4 w-4 text-neutral-400" /><span className="font-medium">{item.invoiceNumber}</span></div> },
  { key: 'amount', header: 'Amount', render: (item) => <span className="font-medium">{formatCurrency(item.amount)}</span> },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
  { key: 'date', header: 'Date' },
  { key: 'dueDate', header: 'Due Date' },
]

export default function InvoicesPage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Invoices</h1><p className="text-neutral-500">View and manage your invoices.</p></div>
      <Card padding="none"><Table columns={columns} data={invoices} keyExtractor={(item) => item.id} /></Card>
    </div>
  )
}
