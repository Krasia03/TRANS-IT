'use client'

import { Card } from '@/components/ui'
import { CreditCard, ArrowDownLeft, ArrowUpRight } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const transactions = [{ id: '1', type: 'credit', amount: 850000, description: 'Shipment TRT-ABC123', date: '2026-04-15' }]

export default function PaymentsPage() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-neutral-900">Payments</h1><p className="text-neutral-500">Payment history and wallet.</p></div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-royal/10 p-2"><CreditCard className="h-5 w-5 text-primary-royal" /></div><div><p className="text-sm text-neutral-500">Balance</p><p className="text-xl font-bold text-neutral-900">{formatCurrency(2500000)}</p></div></div></Card>
        <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-semantic-success/10 p-2"><ArrowDownLeft className="h-5 w-5 text-semantic-success" /></div><div><p className="text-sm text-neutral-500">Total Spent</p><p className="text-xl font-bold text-semantic-success">{formatCurrency(12500000)}</p></div></div></Card>
        <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-golden/10 p-2"><CreditCard className="h-5 w-5 text-primary-golden" /></div><div><p className="text-sm text-neutral-500">Escrow Held</p><p className="text-xl font-bold text-primary-golden">{formatCurrency(500000)}</p></div></div></Card>
      </div>
    </div>
  )
}
