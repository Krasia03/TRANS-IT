'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge, Badge } from '@/components/ui'
import { Plus, Download, DollarSign, Calendar, TrendingUp } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

const payrollRecords = [
  {
    id: '1',
    driverId: 'DRV-001',
    driverName: 'John Mwakasege',
    periodStart: '2026-04-01',
    periodEnd: '2026-04-15',
    baseSalary: 1500000,
    bonuses: 250000,
    deductions: 150000,
    totalEarnings: 1600000,
    status: 'pending',
    trips: 12,
  },
  {
    id: '2',
    driverId: 'DRV-002',
    driverName: 'Samira Komba',
    periodStart: '2026-04-01',
    periodEnd: '2026-04-15',
    baseSalary: 1500000,
    bonuses: 180000,
    deductions: 120000,
    totalEarnings: 1560000,
    status: 'approved',
    trips: 10,
  },
  {
    id: '3',
    driverId: 'DRV-003',
    driverName: 'Emmanuel Msafiri',
    periodStart: '2026-04-01',
    periodEnd: '2026-04-15',
    baseSalary: 1500000,
    bonuses: 320000,
    deductions: 180000,
    totalEarnings: 1640000,
    status: 'paid',
    trips: 15,
  },
]

const columns: TableColumn<typeof payrollRecords[0]>[] = [
  {
    key: 'driver',
    header: 'Driver',
    render: (item) => (
      <div>
        <p className="font-medium text-neutral-900">{item.driverName}</p>
        <p className="text-sm text-neutral-500">{item.driverId}</p>
      </div>
    ),
  },
  {
    key: 'period',
    header: 'Period',
    render: (item) => (
      <div className="flex items-center gap-1.5 text-sm text-neutral-600">
        <Calendar className="h-4 w-4 text-neutral-400" />
        {item.periodStart} - {item.periodEnd}
      </div>
    ),
  },
  { key: 'trips', header: 'Trips' },
  {
    key: 'baseSalary',
    header: 'Base Salary',
    render: (item) => <span>{formatCurrency(item.baseSalary)}</span>,
  },
  {
    key: 'bonuses',
    header: 'Bonuses',
    render: (item) => <span className="text-semantic-success">+{formatCurrency(item.bonuses)}</span>,
  },
  {
    key: 'deductions',
    header: 'Deductions',
    render: (item) => <span className="text-semantic-error">-{formatCurrency(item.deductions)}</span>,
  },
  {
    key: 'totalEarnings',
    header: 'Net Pay',
    render: (item) => (
      <span className="font-semibold text-neutral-900">{formatCurrency(item.totalEarnings)}</span>
    ),
  },
  {
    key: 'status',
    header: 'Status',
    render: (item) => <StatusBadge status={item.status} />,
  },
]

export default function PayrollPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Driver Payroll</h1>
            <p className="text-neutral-500">Manage driver salaries, bonuses, and payments.</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4" />
              Process Payroll
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-royal/10 p-2">
                <DollarSign className="h-5 w-5 text-primary-royal" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Total Payroll</p>
                <p className="text-xl font-bold text-neutral-900">28.5M TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-warning/10 p-2">
                <Calendar className="h-5 w-5 text-semantic-warning" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Pending</p>
                <p className="text-xl font-bold text-semantic-warning">4.2M TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-success/10 p-2">
                <TrendingUp className="h-5 w-5 text-semantic-success" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Avg Bonus</p>
                <p className="text-xl font-bold text-semantic-success">185K TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div>
              <p className="text-sm text-neutral-500">Active Drivers</p>
              <p className="text-xl font-bold text-neutral-900">20</p>
            </div>
          </Card>
        </div>

        {/* Payroll Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={payrollRecords}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked payroll:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
