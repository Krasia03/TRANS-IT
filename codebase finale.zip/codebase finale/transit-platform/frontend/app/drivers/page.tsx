'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Input, Select, Table, type TableColumn, StatusBadge, Badge } from '@/components/ui'
import { Plus, Search, Filter, Phone, Mail, Star, Truck } from 'lucide-react'

const drivers = [
  {
    id: '1',
    name: 'John Mwakasege',
    email: 'john.mwakasege@transit.co.tz',
    phone: '+255 712 345 678',
    licenseNumber: 'DL-2020-1234',
    licenseExpiry: '2027-08-15',
    status: 'active',
    rating: 4.8,
    totalTrips: 156,
    assignedVehicle: 'TZ-1234',
  },
  {
    id: '2',
    name: 'Samira Komba',
    email: 'samira.komba@transit.co.tz',
    phone: '+255 765 432 109',
    licenseNumber: 'DL-2019-5678',
    licenseExpiry: '2026-03-20',
    status: 'active',
    rating: 4.6,
    totalTrips: 89,
    assignedVehicle: 'TZ-3456',
  },
  {
    id: '3',
    name: 'Emmanuel Msafiri',
    email: 'emmanuel.msafiri@transit.co.tz',
    phone: '+255 678 901 234',
    licenseNumber: 'DL-2021-9012',
    licenseExpiry: '2028-01-10',
    status: 'active',
    rating: 4.9,
    totalTrips: 203,
    assignedVehicle: 'TZ-4567',
  },
  {
    id: '4',
    name: 'Grace楼',
    email: 'grace.lola@transit.co.tz',
    phone: '+255 654 321 098',
    licenseNumber: 'DL-2018-3456',
    licenseExpiry: '2025-11-30',
    status: 'on_leave',
    rating: 4.5,
    totalTrips: 312,
    assignedVehicle: null,
  },
  {
    id: '5',
    name: 'Michael Rashidi',
    email: 'michael.rashidi@transit.co.tz',
    phone: '+255 623 456 789',
    licenseNumber: 'DL-2022-7890',
    licenseExpiry: '2029-06-25',
    status: 'active',
    rating: 4.7,
    totalTrips: 67,
    assignedVehicle: null,
  },
]

const columns: TableColumn<typeof drivers[0]>[] = [
  {
    key: 'name',
    header: 'Driver',
    render: (item) => (
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-royal text-sm font-medium text-white">
          {item.name.split(' ').map(n => n[0]).join('')}
        </div>
        <div>
          <p className="font-medium text-neutral-900">{item.name}</p>
          <p className="text-sm text-neutral-500">{item.email}</p>
        </div>
      </div>
    ),
  },
  {
    key: 'contact',
    header: 'Contact',
    render: (item) => (
      <div className="space-y-1">
        <div className="flex items-center gap-1.5 text-sm text-neutral-600">
          <Phone className="h-3.5 w-3.5 text-neutral-400" />
          {item.phone}
        </div>
      </div>
    ),
  },
  { key: 'licenseNumber', header: 'License' },
  {
    key: 'licenseExpiry',
    header: 'License Expiry',
    render: (item) => {
      const expiryDate = new Date(item.licenseExpiry)
      const isExpiringSoon = expiryDate.getTime() - Date.now() < 90 * 24 * 60 * 60 * 1000
      return (
        <div className="flex items-center gap-1.5">
          <span className={isExpiringSoon ? 'text-semantic-warning' : 'text-neutral-700'}>
            {item.licenseExpiry}
          </span>
          {isExpiringSoon && (
            <Badge variant="warning" size="sm">Soon</Badge>
          )}
        </div>
      )
    },
  },
  {
    key: 'status',
    header: 'Status',
    render: (item) => <StatusBadge status={item.status} />,
  },
  {
    key: 'rating',
    header: 'Rating',
    render: (item) => (
      <div className="flex items-center gap-1">
        <Star className="h-4 w-4 text-primary-golden fill-primary-golden" />
        <span className="font-medium">{item.rating}</span>
      </div>
    ),
  },
  {
    key: 'assignedVehicle',
    header: 'Vehicle',
    render: (item) => (
      item.assignedVehicle ? (
        <div className="flex items-center gap-1.5">
          <Truck className="h-4 w-4 text-neutral-400" />
          <span className="font-medium">{item.assignedVehicle}</span>
        </div>
      ) : (
        <span className="text-neutral-400">Unassigned</span>
      )
    ),
  },
  { key: 'totalTrips', header: 'Total Trips' },
]

const statusOptions = [
  { value: 'all', label: 'All Status' },
  { value: 'active', label: 'Active' },
  { value: 'on_leave', label: 'On Leave' },
  { value: 'suspended', label: 'Suspended' },
]

export default function DriversPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Driver Management</h1>
            <p className="text-neutral-500">Manage driver profiles, licenses, and assignments.</p>
          </div>
          <Button>
            <Plus className="h-4 w-4" />
            Add Driver
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <div>
              <p className="text-sm text-neutral-500">Total Drivers</p>
              <p className="text-2xl font-bold text-neutral-900">24</p>
            </div>
          </Card>
          <Card padding="md">
            <div>
              <p className="text-sm text-neutral-500">Active</p>
              <p className="text-2xl font-bold text-semantic-success">20</p>
            </div>
          </Card>
          <Card padding="md">
            <div>
              <p className="text-sm text-neutral-500">On Leave</p>
              <p className="text-2xl font-bold text-semantic-warning">3</p>
            </div>
          </Card>
          <Card padding="md">
            <div>
              <p className="text-sm text-neutral-500">Avg Rating</p>
              <p className="text-2xl font-bold text-primary-golden">4.7</p>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <Card padding="md">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                <Input placeholder="Search drivers..." className="pl-10" />
              </div>
              <Select options={statusOptions} placeholder="Status" className="w-40" />
            </div>
            <Button variant="outline">
              <Filter className="h-4 w-4" />
              More Filters
            </Button>
          </div>
        </Card>

        {/* Drivers Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={drivers}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked driver:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
