'use client'

import Link from 'next/link'
import { Card, CardHeader, CardTitle, CardContent, Button, Input } from '@/components/ui'
import { Truck } from 'lucide-react'

export default function ForgotPasswordPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-neutral-50 px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link href="/" className="mb-8 inline-flex items-center gap-2">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-royal"><Truck className="h-6 w-6 text-white" /></div>
          </Link>
          <h1 className="text-2xl font-bold text-neutral-900">TRANS-IT</h1>
        </div>
        <Card padding="lg">
          <CardHeader><CardTitle>Forgot Password</CardTitle></CardHeader>
          <CardContent>
            <form className="space-y-4">
              <p className="text-sm text-neutral-500">Enter your email address and we'll send you a link to reset your password.</p>
              <Input label="Email" type="email" placeholder="Enter your email" />
              <Button type="submit" className="w-full">Send Reset Link</Button>
            </form>
            <div className="mt-6 text-center text-sm text-neutral-500">
              Remember your password? <Link href="/login" className="text-primary-royal hover:underline">Sign in</Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
