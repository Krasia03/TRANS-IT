'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button } from '@/components/ui'
import { Plus, Warehouse as WarehouseIcon, MapPin } from 'lucide-react'

const warehouses = [
  { id: '1', name: 'Dar es Salaam Hub', code: 'DAR-01', location: 'Kilwa Road, Dar es Salaam', capacity: '10,000 sqm', utilization: 78, status: 'active' },
  { id: '2', name: 'Arusha Depot', code: 'ARU-01', location: 'Nelson Mandela Road, Arusha', capacity: '5,000 sqm', utilization: 45, status: 'active' },
]

export default function WarehousesPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">Warehouses</h1><p className="text-neutral-500">Manage storage facilities.</p></div><Button><Plus className="h-4 w-4" />Add Warehouse</Button></div>
        <div className="grid gap-4 lg:grid-cols-2">
          {warehouses.map((warehouse) => (
            <Card key={warehouse.id} padding="lg">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-primary-royal/10 p-3"><WarehouseIcon className="h-6 w-6 text-primary-royal" /></div>
                  <div><p className="text-lg font-semibold text-neutral-900">{warehouse.name}</p><p className="text-sm text-neutral-500">{warehouse.code}</p></div>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-sm text-neutral-600"><MapPin className="h-4 w-4 text-neutral-400" />{warehouse.location}</div>
                <div className="flex items-center justify-between text-sm"><span className="text-neutral-500">Capacity</span><span className="font-medium">{warehouse.capacity}</span></div>
                <div className="flex items-center justify-between text-sm"><span className="text-neutral-500">Utilization</span><span className="font-medium">{warehouse.utilization}%</span></div>
                <div className="h-2 w-full rounded-full bg-neutral-200"><div className="h-2 rounded-full bg-primary-royal" style={{ width: `${warehouse.utilization}%` }} /></div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </AdminLayout>
  )
}
