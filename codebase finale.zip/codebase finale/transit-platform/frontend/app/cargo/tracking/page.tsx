'use client'

import { AdminLayout } from '@/components/layout'
import { Card, CardHeader, CardTitle, CardContent, Button, Input } from '@/components/ui'
import { Search, MapPin, Package, Truck, CheckCircle, Clock } from 'lucide-react'

const activeShipments = [
  {
    id: '1',
    trackingNumber: 'TRT-GHI789',
    customer: 'TanzFood Ltd',
    vehicle: 'TZ-1234',
    driver: 'John Mwakasege',
    origin: 'Arusha',
    destination: 'Dar es Salaam',
    progress: 65,
    eta: '2h 30m',
    lastUpdate: 'Just passed Morogoro',
    status: 'in_transit',
  },
  {
    id: '2',
    trackingNumber: 'TRT-MNO345',
    customer: 'BuildTech Inc',
    vehicle: 'TZ-4567',
    driver: 'Emmanuel Msafiri',
    origin: 'Dar es Salaam',
    destination: 'Mwanza',
    progress: 30,
    eta: '8h 45m',
    lastUpdate: 'Departed Dodoma',
    status: 'in_transit',
  },
]

export default function CargoTrackingPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Live Cargo Tracking</h1>
            <p className="text-neutral-500">Track shipments in real-time with H3 hexagonal grid zones.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
              <Input placeholder="Search tracking number..." className="pl-10 w-64" />
            </div>
          </div>
        </div>

        {/* Map Placeholder */}
        <Card padding="none" className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary-royal/5 to-primary-golden/5 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="h-16 w-16 text-primary-royal/30 mx-auto" />
              <p className="mt-4 text-lg font-medium text-neutral-400">H3 Map Integration Ready</p>
              <p className="text-sm text-neutral-400">Map visualization component placeholder</p>
            </div>
          </div>
          <div className="h-96" />
        </Card>

        {/* Active Shipments */}
        <div className="grid gap-4 lg:grid-cols-2">
          {activeShipments.map((shipment) => (
            <Card key={shipment.id} padding="lg">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-mono text-lg font-bold text-primary-royal">{shipment.trackingNumber}</p>
                  <p className="text-sm text-neutral-500">{shipment.customer}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-neutral-900">{shipment.eta}</p>
                  <p className="text-sm text-neutral-500">ETA</p>
                </div>
              </div>

              <div className="mt-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600">{shipment.origin}</span>
                  <span className="text-neutral-400">→</span>
                  <span className="text-neutral-600">{shipment.destination}</span>
                </div>
                <div className="mt-2 h-2 w-full rounded-full bg-neutral-200">
                  <div
                    className="h-2 rounded-full bg-primary-royal transition-all"
                    style={{ width: `${shipment.progress}%` }}
                  />
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Truck className="h-4 w-4 text-neutral-400" />
                    <span className="text-sm font-medium">{shipment.vehicle}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-neutral-600">{shipment.driver}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-sm text-neutral-500">
                  <Clock className="h-4 w-4" />
                  {shipment.lastUpdate}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </AdminLayout>
  )
}
