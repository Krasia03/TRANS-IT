'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge, Badge } from '@/components/ui'
import { Plus, Search, MapPin, Calendar, Package } from 'lucide-react'

const cargoRequests = [
  {
    id: '1',
    trackingNumber: 'TRT-ABC123',
    customerName: 'Acme Corporation',
    customerType: 'corporate',
    category: 'general',
    weight: '2,500 kg',
    pickupLocation: 'Dar es Salaam',
    deliveryLocation: 'Arusha',
    pickupDate: '2026-04-16',
    estimatedPrice: 850000,
    status: 'pending',
  },
  {
    id: '2',
    trackingNumber: 'TRT-DEF456',
    customerName: 'John Doe',
    customerType: 'individual',
    category: 'fragile',
    weight: '150 kg',
    pickupLocation: 'Mwanza',
    deliveryLocation: 'Dodoma',
    pickupDate: '2026-04-17',
    estimatedPrice: 125000,
    status: 'confirmed',
  },
  {
    id: '3',
    trackingNumber: 'TRT-GHI789',
    customerName: 'TanzFood Ltd',
    customerType: 'corporate',
    category: 'perishable',
    weight: '5,000 kg',
    pickupLocation: 'Arusha',
    deliveryLocation: 'Dar es Salaam',
    pickupDate: '2026-04-15',
    estimatedPrice: 1200000,
    status: 'in_transit',
  },
  {
    id: '4',
    trackingNumber: 'TRT-JKL012',
    customerName: 'Tech Solutions',
    customerType: 'corporate',
    category: 'general',
    weight: '800 kg',
    pickupLocation: 'Dar es Salaam',
    deliveryLocation: 'Mwanza',
    pickupDate: '2026-04-14',
    estimatedPrice: 680000,
    status: 'delivered',
  },
]

const columns: TableColumn<typeof cargoRequests[0]>[] = [
  {
    key: 'trackingNumber',
    header: 'Tracking #',
    render: (item) => (
      <div className="flex items-center gap-2">
        <Package className="h-5 w-5 text-primary-royal" />
        <span className="font-mono font-medium text-primary-royal">{item.trackingNumber}</span>
      </div>
    ),
  },
  {
    key: 'customer',
    header: 'Customer',
    render: (item) => (
      <div>
        <p className="font-medium text-neutral-900">{item.customerName}</p>
        <Badge variant={item.customerType === 'corporate' ? 'primary' : 'default'} size="sm">
          {item.customerType}
        </Badge>
      </div>
    ),
  },
  {
    key: 'category',
    header: 'Category',
    render: (item) => <Badge size="sm">{item.category}</Badge>,
  },
  { key: 'weight', header: 'Weight' },
  {
    key: 'pickupLocation',
    header: 'Route',
    render: (item) => (
      <div className="flex items-center gap-1 text-sm">
        <span className="text-neutral-600">{item.pickupLocation}</span>
        <span className="text-neutral-400">→</span>
        <span className="text-neutral-600">{item.deliveryLocation}</span>
      </div>
    ),
  },
  { key: 'pickupDate', header: 'Pickup Date' },
  {
    key: 'estimatedPrice',
    header: 'Est. Price',
    render: (item) => (
      <span className="font-medium">{item.estimatedPrice.toLocaleString()} TZS</span>
    ),
  },
  {
    key: 'status',
    header: 'Status',
    render: (item) => <StatusBadge status={item.status} />,
  },
]

export default function CargoRequestsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Cargo Requests</h1>
            <p className="text-neutral-500">Manage incoming cargo bookings and requests.</p>
          </div>
          <Button>
            <Plus className="h-4 w-4" />
            New Booking
          </Button>
        </div>

        {/* Filters */}
        <Card padding="md">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                <input
                  type="text"
                  placeholder="Search by tracking # or customer..."
                  className="block w-full rounded-lg border border-neutral-300 bg-white pl-10 pr-4 py-2 text-sm"
                />
              </div>
              <select className="rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm">
                <option>All Categories</option>
                <option>General</option>
                <option>Fragile</option>
                <option>Perishable</option>
              </select>
              <select className="rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm">
                <option>All Status</option>
                <option>Pending</option>
                <option>Confirmed</option>
                <option>In Transit</option>
                <option>Delivered</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Cargo Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={cargoRequests}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked cargo:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
