'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Plus, Building2, Phone, Mail, MapPin, Search } from 'lucide-react'

const corporateClients = [
  { id: '1', companyName: 'Acme Corporation', registrationNumber: 'REG-001234', contactPerson: 'Robert Kimaro', contactEmail: 'robert@acme.co.tz', contactPhone: '+255 712 123 456', status: 'active' },
  { id: '2', companyName: 'TanzFood Ltd', registrationNumber: 'REG-005678', contactPerson: 'Amina Juma', contactEmail: 'amina@tanzfood.co.tz', contactPhone: '+255 765 987 654', status: 'active' },
]

const columns: TableColumn<typeof corporateClients[0]>[] = [
  { key: 'companyName', header: 'Company', render: (item) => <div className="flex items-center gap-2"><Building2 className="h-5 w-5 text-primary-royal" /><span className="font-medium">{item.companyName}</span></div> },
  { key: 'registrationNumber', header: 'Reg Number' },
  { key: 'contactPerson', header: 'Contact Person' },
  { key: 'contactEmail', header: 'Email', render: (item) => <div className="flex items-center gap-1 text-sm text-neutral-600"><Mail className="h-4 w-4 text-neutral-400" />{item.contactEmail}</div> },
  { key: 'contactPhone', header: 'Phone', render: (item) => <div className="flex items-center gap-1 text-sm text-neutral-600"><Phone className="h-4 w-4 text-neutral-400" />{item.contactPhone}</div> },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
]

export default function CorporateClientsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">Corporate Clients</h1><p className="text-neutral-500">Manage corporate customer accounts.</p></div><Button><Plus className="h-4 w-4" />Add Client</Button></div>
        <Card padding="none"><Table columns={columns} data={corporateClients} keyExtractor={(item) => item.id} /></Card>
      </div>
    </AdminLayout>
  )
}
