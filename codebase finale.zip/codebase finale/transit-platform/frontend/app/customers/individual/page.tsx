'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Plus, User, Phone, Mail, Search } from 'lucide-react'

const individualClients = [
  { id: '1', firstName: 'John', lastName: 'Doe', email: 'john.doe@email.com', phone: '+255 612 345 678', nationalId: 'NID-123456', status: 'active' },
]

const columns: TableColumn<typeof individualClients[0]>[] = [
  { key: 'name', header: 'Name', render: (item) => <div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-royal text-xs font-medium text-white">{item.firstName[0]}{item.lastName[0]}</div><span className="font-medium">{item.firstName} {item.lastName}</span></div> },
  { key: 'email', header: 'Email', render: (item) => <div className="flex items-center gap-1 text-sm text-neutral-600"><Mail className="h-4 w-4 text-neutral-400" />{item.email}</div> },
  { key: 'phone', header: 'Phone', render: (item) => <div className="flex items-center gap-1 text-sm text-neutral-600"><Phone className="h-4 w-4 text-neutral-400" />{item.phone}</div> },
  { key: 'nationalId', header: 'National ID' },
  { key: 'status', header: 'Status', render: (item) => <StatusBadge status={item.status} /> },
]

export default function IndividualClientsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">Individual Clients</h1><p className="text-neutral-500">Manage individual customer accounts.</p></div><Button><Plus className="h-4 w-4" />Add Client</Button></div>
        <Card padding="none"><Table columns={columns} data={individualClients} keyExtractor={(item) => item.id} /></Card>
      </div>
    </AdminLayout>
  )
}
