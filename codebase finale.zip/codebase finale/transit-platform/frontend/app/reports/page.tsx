'use client'

import { AdminLayout } from '@/components/layout'
import { Card, CardHeader, CardTitle } from '@/components/ui'
import { RevenueChart } from '@/components/charts/revenue-chart'
import { PerformanceChart } from '@/components/charts/performance-chart'
import { FileText, Download, TrendingUp, Package, Truck } from 'lucide-react'

const revenueData = [{ date: 'Jan', revenue: 45000000 }, { date: 'Feb', revenue: 52000000 }, { date: 'Mar', revenue: 48000000 }, { date: 'Apr', revenue: 61000000 }]

const topRoutesData = [
  { name: 'DAR-ARS', value: 156, secondaryValue: 145 },
  { name: 'DAR-DOD', value: 134, secondaryValue: 128 },
  { name: 'DAR-MWZ', value: 98, secondaryValue: 92 },
  { name: 'ARS-MSH', value: 67, secondaryValue: 62 },
]

export default function ReportsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold text-neutral-900">Analytics & Reports</h1><p className="text-neutral-500">Business insights and performance metrics.</p></div><button className="flex items-center gap-2 rounded-lg border border-neutral-300 bg-white px-4 py-2 text-sm font-medium"><Download className="h-4 w-4" />Export Report</button></div>
        <div className="grid gap-4 lg:grid-cols-4">
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-royal/10 p-2"><FileText className="h-5 w-5 text-primary-royal" /></div><div><p className="text-sm text-neutral-500">Total Revenue</p><p className="text-xl font-bold text-neutral-900">206M TZS</p></div></div></Card>
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-semantic-success/10 p-2"><TrendingUp className="h-5 w-5 text-semantic-success" /></div><div><p className="text-sm text-neutral-500">Growth</p><p className="text-xl font-bold text-semantic-success">+18.5%</p></div></div></Card>
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-golden/10 p-2"><Package className="h-5 w-5 text-primary-golden" /></div><div><p className="text-sm text-neutral-500">Trips</p><p className="text-xl font-bold text-neutral-900">455</p></div></div></Card>
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-semantic-info/10 p-2"><Truck className="h-5 w-5 text-semantic-info" /></div><div><p className="text-sm text-neutral-500">Avg Distance</p><p className="text-xl font-bold text-neutral-900">380 km</p></div></div></Card>
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <Card padding="lg"><RevenueChart data={revenueData} title="Monthly Revenue" /></Card>
          <Card padding="lg"><PerformanceChart data={topRoutesData} title="Top Routes Performance" primaryLabel="2026" secondaryLabel="2025" /></Card>
        </div>
      </div>
    </AdminLayout>
  )
}
