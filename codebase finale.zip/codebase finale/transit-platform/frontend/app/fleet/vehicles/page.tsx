'use client'

import { AdminLayout } from '@/components/layout'
import { Card, CardHeader, CardTitle, Button, Input, Select, Table, type TableColumn, StatusBadge } from '@/components/ui'
import { Plus, Search, Filter, Truck, MapPin, Fuel } from 'lucide-react'

const vehicles = [
  {
    id: '1',
    plateNumber: 'TZ-1234',
    make: 'Isuzu',
    model: 'NMR 250',
    year: 2022,
    type: 'truck',
    capacity: '5,000 kg',
    status: 'in_transit',
    currentLocation: 'Arusha',
    fuelLevel: 75,
    currentDriver: 'John Mwakasege',
  },
  {
    id: '2',
    plateNumber: 'TZ-2345',
    make: 'Hino',
    model: 'FG 175',
    year: 2021,
    type: 'flatbed',
    capacity: '8,000 kg',
    status: 'available',
    currentLocation: 'Dar es Salaam',
    fuelLevel: 100,
    currentDriver: null,
  },
  {
    id: '3',
    plateNumber: 'TZ-3456',
    make: 'Mercedes',
    model: 'Actros 2528',
    year: 2023,
    type: 'trailer',
    capacity: '25,000 kg',
    status: 'maintenance',
    currentLocation: 'Workshop',
    fuelLevel: 30,
    currentDriver: 'Samira Komba',
  },
  {
    id: '4',
    plateNumber: 'TZ-4567',
    make: 'Foton',
    model: 'Aumark BJ1086',
    year: 2020,
    type: 'van',
    capacity: '2,000 kg',
    status: 'in_transit',
    currentLocation: 'Mwanza',
    fuelLevel: 50,
    currentDriver: 'Emmanuel Msafiri',
  },
  {
    id: '5',
    plateNumber: 'TZ-5678',
    make: 'Toyota',
    model: 'Dyna 150',
    year: 2019,
    type: 'refrigerated',
    capacity: '3,500 kg',
    status: 'available',
    currentLocation: 'Dodoma',
    fuelLevel: 90,
    currentDriver: null,
  },
]

const columns: TableColumn<typeof vehicles[0]>[] = [
  {
    key: 'plateNumber',
    header: 'Plate Number',
    render: (item) => (
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-royal/10">
          <Truck className="h-5 w-5 text-primary-royal" />
        </div>
        <span className="font-medium text-neutral-900">{item.plateNumber}</span>
      </div>
    ),
  },
  { key: 'make', header: 'Make/Model' },
  { key: 'type', header: 'Type' },
  { key: 'capacity', header: 'Capacity' },
  {
    key: 'status',
    header: 'Status',
    render: (item) => <StatusBadge status={item.status} />,
  },
  {
    key: 'location',
    header: 'Location',
    render: (item) => (
      <div className="flex items-center gap-1.5 text-neutral-600">
        <MapPin className="h-4 w-4" />
        {item.currentLocation}
      </div>
    ),
  },
  {
    key: 'fuel',
    header: 'Fuel',
    render: (item) => (
      <div className="flex items-center gap-2">
        <Fuel className="h-4 w-4 text-neutral-400" />
        <div className="w-16 rounded-full bg-neutral-200 h-2">
          <div
            className={`h-2 rounded-full ${
              item.fuelLevel > 50 ? 'bg-semantic-success' :
              item.fuelLevel > 25 ? 'bg-semantic-warning' : 'bg-semantic-error'
            }`}
            style={{ width: `${item.fuelLevel}%` }}
          />
        </div>
        <span className="text-sm text-neutral-600">{item.fuelLevel}%</span>
      </div>
    ),
  },
  { key: 'currentDriver', header: 'Driver' },
]

const vehicleTypes = [
  { value: 'truck', label: 'Truck' },
  { value: 'van', label: 'Van' },
  { value: 'trailer', label: 'Trailer' },
  { value: 'flatbed', label: 'Flatbed' },
  { value: 'refrigerated', label: 'Refrigerated' },
]

const statusOptions = [
  { value: 'all', label: 'All Status' },
  { value: 'available', label: 'Available' },
  { value: 'in_transit', label: 'In Transit' },
  { value: 'maintenance', label: 'Maintenance' },
]

export default function VehiclesPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Fleet Vehicles</h1>
            <p className="text-neutral-500">Manage your vehicle fleet and track their status.</p>
          </div>
          <Button>
            <Plus className="h-4 w-4" />
            Add Vehicle
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <CardContent>
              <p className="text-sm text-neutral-500">Total Vehicles</p>
              <p className="text-2xl font-bold text-neutral-900">20</p>
            </CardContent>
          </Card>
          <Card padding="md">
            <CardContent>
              <p className="text-sm text-neutral-500">Active</p>
              <p className="text-2xl font-bold text-semantic-success">14</p>
            </CardContent>
          </Card>
          <Card padding="md">
            <CardContent>
              <p className="text-sm text-neutral-500">In Transit</p>
              <p className="text-2xl font-bold text-semantic-info">8</p>
            </CardContent>
          </Card>
          <Card padding="md">
            <CardContent>
              <p className="text-sm text-neutral-500">Maintenance</p>
              <p className="text-2xl font-bold text-semantic-warning">2</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card padding="md">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                <Input placeholder="Search vehicles..." className="pl-10" />
              </div>
              <Select options={vehicleTypes} placeholder="Vehicle Type" className="w-40" />
              <Select options={statusOptions} placeholder="Status" className="w-40" />
            </div>
            <Button variant="outline">
              <Filter className="h-4 w-4" />
              More Filters
            </Button>
          </div>
        </Card>

        {/* Vehicle Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={vehicles}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked vehicle:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
