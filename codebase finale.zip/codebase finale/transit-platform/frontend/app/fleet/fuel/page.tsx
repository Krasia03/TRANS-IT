'use client'

import { AdminLayout } from '@/components/layout'
import { Card, CardHeader, CardTitle, Button, Input, Select, Table, type TableColumn } from '@/components/ui'
import { Plus, Search, Filter, Fuel, DollarSign, Truck } from 'lucide-react'

const fuelTransactions = [
  {
    id: '1',
    vehicleId: 'TZ-1234',
    vehicleName: 'Isuzu NMR 250',
    driver: 'John Mwakasege',
    liters: 85,
    pricePerLiter: 2350,
    totalCost: 199750,
    station: 'Total Mbeya Road',
    odometer: 125430,
    date: '2026-04-15',
  },
  {
    id: '2',
    vehicleId: 'TZ-2345',
    vehicleName: 'Hino FG 175',
    driver: null,
    liters: 120,
    pricePerLiter: 2350,
    totalCost: 282000,
    station: 'Shell Sinrivua',
    odometer: 89200,
    date: '2026-04-14',
  },
  {
    id: '3',
    vehicleId: 'TZ-4567',
    vehicleName: 'Foton Aumark BJ1086',
    driver: 'Emmanuel Msafiri',
    liters: 65,
    pricePerLiter: 2350,
    totalCost: 152750,
    station: 'Oryx Morogoro',
    odometer: 67800,
    date: '2026-04-14',
  },
  {
    id: '4',
    vehicleId: 'TZ-5678',
    vehicleName: 'Toyota Dyna 150',
    driver: null,
    liters: 45,
    pricePerLiter: 2350,
    totalCost: 105750,
    station: 'Gapco Dodoma',
    odometer: 145600,
    date: '2026-04-13',
  },
]

const columns: TableColumn<typeof fuelTransactions[0]>[] = [
  {
    key: 'vehicle',
    header: 'Vehicle',
    render: (item) => (
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-royal/10">
          <Truck className="h-5 w-5 text-primary-royal" />
        </div>
        <div>
          <p className="font-medium text-neutral-900">{item.vehicleName}</p>
          <p className="text-sm text-neutral-500">{item.vehicleId}</p>
        </div>
      </div>
    ),
  },
  { key: 'driver', header: 'Driver' },
  {
    key: 'liters',
    header: 'Liters',
    render: (item) => <span className="font-medium">{item.liters} L</span>,
  },
  {
    key: 'pricePerLiter',
    header: 'Price/L',
    render: (item) => <span>{item.pricePerLiter.toLocaleString()} TZS</span>,
  },
  {
    key: 'totalCost',
    header: 'Total Cost',
    render: (item) => (
      <div className="flex items-center gap-1">
        <DollarSign className="h-4 w-4 text-neutral-400" />
        <span className="font-medium">{item.totalCost.toLocaleString()} TZS</span>
      </div>
    ),
  },
  { key: 'station', header: 'Station' },
  {
    key: 'odometer',
    header: 'Odometer',
    render: (item) => <span>{item.odometer.toLocaleString()} km</span>,
  },
  { key: 'date', header: 'Date' },
]

export default function FuelPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Fuel Management</h1>
            <p className="text-neutral-500">Track fuel consumption and expenses across your fleet.</p>
          </div>
          <Button>
            <Plus className="h-4 w-4" />
            Record Fuel Purchase
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-royal/10 p-2">
                <Fuel className="h-5 w-5 text-primary-royal" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">This Month</p>
                <p className="text-xl font-bold text-neutral-900">4,520 L</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-info/10 p-2">
                <DollarSign className="h-5 w-5 text-semantic-info" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Fuel Cost</p>
                <p className="text-xl font-bold text-neutral-900">10.6M TZS</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-success/10 p-2">
                <Truck className="h-5 w-5 text-semantic-success" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Avg Efficiency</p>
                <p className="text-xl font-bold text-neutral-900">8.2 km/L</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-warning/10 p-2">
                <Fuel className="h-5 w-5 text-semantic-warning" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Transactions</p>
                <p className="text-xl font-bold text-neutral-900">156</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <Card padding="md">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                <Input placeholder="Search by vehicle or driver..." className="pl-10" />
              </div>
              <Select
                options={[
                  { value: 'all', label: 'All Stations' },
                  { value: 'total', label: 'Total' },
                  { value: 'shell', label: 'Shell' },
                  { value: 'oryx', label: 'Oryx' },
                ]}
                placeholder="Station"
                className="w-40"
              />
            </div>
            <Button variant="outline">
              <Filter className="h-4 w-4" />
              Export Report
            </Button>
          </div>
        </Card>

        {/* Fuel Transactions Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={fuelTransactions}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked transaction:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
