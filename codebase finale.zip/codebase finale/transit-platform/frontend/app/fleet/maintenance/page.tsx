'use client'

import { AdminLayout } from '@/components/layout'
import { Card, CardHeader, CardTitle, Button, Input, Select, Table, type TableColumn, StatusBadge, Badge } from '@/components/ui'
import { Plus, Search, Filter, Wrench, Calendar, DollarSign } from 'lucide-react'

const maintenanceRecords = [
  {
    id: '1',
    vehicleId: 'TZ-3456',
    vehicleName: 'Mercedes Actros 2528',
    type: 'brake_service',
    description: 'Front brake pad replacement and rotor inspection',
    scheduledDate: '2026-04-18',
    completedDate: null,
    cost: 850000,
    status: 'scheduled',
    workshop: 'Dar Motors Workshop',
  },
  {
    id: '2',
    vehicleId: 'TZ-1234',
    vehicleName: 'Isuzu NMR 250',
    type: 'oil_change',
    description: 'Regular oil change and filter replacement',
    scheduledDate: '2026-04-10',
    completedDate: '2026-04-10',
    cost: 120000,
    status: 'completed',
    workshop: 'Self-Service',
  },
  {
    id: '3',
    vehicleId: 'TZ-4567',
    vehicleName: 'Foton Aumark BJ1086',
    type: 'engine_repair',
    description: 'Engine diagnostic and fuel injector replacement',
    scheduledDate: '2026-04-05',
    completedDate: '2026-04-07',
    cost: 1500000,
    status: 'completed',
    workshop: 'MTL Dar es Salaam',
  },
  {
    id: '4',
    vehicleId: 'TZ-5678',
    vehicleName: 'Toyota Dyna 150',
    type: 'general_service',
    description: '30,000 km general service inspection',
    scheduledDate: '2026-04-25',
    completedDate: null,
    cost: 350000,
    status: 'scheduled',
    workshop: 'Tanga Motors',
  },
]

const columns: TableColumn<typeof maintenanceRecords[0]>[] = [
  {
    key: 'vehicle',
    header: 'Vehicle',
    render: (item) => (
      <div>
        <p className="font-medium text-neutral-900">{item.vehicleName}</p>
        <p className="text-sm text-neutral-500">{item.vehicleId}</p>
      </div>
    ),
  },
  {
    key: 'type',
    header: 'Type',
    render: (item) => (
      <Badge variant="default" size="sm">
        {item.type.replace('_', ' ')}
      </Badge>
    ),
  },
  { key: 'description', header: 'Description' },
  {
    key: 'scheduledDate',
    header: 'Scheduled',
    render: (item) => (
      <div className="flex items-center gap-1.5">
        <Calendar className="h-4 w-4 text-neutral-400" />
        {item.scheduledDate}
      </div>
    ),
  },
  {
    key: 'cost',
    header: 'Cost',
    render: (item) => (
      <div className="flex items-center gap-1.5">
        <DollarSign className="h-4 w-4 text-neutral-400" />
        {item.cost.toLocaleString()} TZS
      </div>
    ),
  },
  {
    key: 'status',
    header: 'Status',
    render: (item) => <StatusBadge status={item.status} />,
  },
]

const maintenanceTypes = [
  { value: 'all', label: 'All Types' },
  { value: 'oil_change', label: 'Oil Change' },
  { value: 'brake_service', label: 'Brake Service' },
  { value: 'engine_repair', label: 'Engine Repair' },
  { value: 'general_service', label: 'General Service' },
]

const statusOptions = [
  { value: 'all', label: 'All Status' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
]

export default function MaintenancePage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Maintenance Tracking</h1>
            <p className="text-neutral-500">Track and manage vehicle maintenance schedules.</p>
          </div>
          <Button>
            <Plus className="h-4 w-4" />
            Schedule Maintenance
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-warning/10 p-2">
                <Wrench className="h-5 w-5 text-semantic-warning" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Scheduled</p>
                <p className="text-xl font-bold text-neutral-900">5</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-info/10 p-2">
                <Calendar className="h-5 w-5 text-semantic-info" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">This Month</p>
                <p className="text-xl font-bold text-neutral-900">12</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-success/10 p-2">
                <Wrench className="h-5 w-5 text-semantic-success" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Completed</p>
                <p className="text-xl font-bold text-neutral-900">8</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-royal/10 p-2">
                <DollarSign className="h-5 w-5 text-primary-royal" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Total Cost</p>
                <p className="text-xl font-bold text-neutral-900">4.2M TZS</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <Card padding="md">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                <Input placeholder="Search maintenance records..." className="pl-10" />
              </div>
              <Select options={maintenanceTypes} placeholder="Type" className="w-40" />
              <Select options={statusOptions} placeholder="Status" className="w-40" />
            </div>
            <Button variant="outline">
              <Filter className="h-4 w-4" />
              More Filters
            </Button>
          </div>
        </Card>

        {/* Maintenance Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={maintenanceRecords}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked maintenance:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
