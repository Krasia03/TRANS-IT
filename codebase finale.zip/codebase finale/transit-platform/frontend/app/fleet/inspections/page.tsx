'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Table, type TableColumn, StatusBadge, Badge } from '@/components/ui'
import { Plus, ClipboardCheck, CheckCircle, XCircle, AlertTriangle, Truck } from 'lucide-react'

const inspections = [
  {
    id: '1',
    vehicleId: 'TZ-1234',
    vehicleName: 'Isuzu NMR 250',
    driver: 'John Mwakasege',
    type: 'pre_trip',
    date: '2026-04-15',
    status: 'passed',
    checklist: { tires: true, brakes: true, lights: true, fluids: true, engine: true, body: true },
  },
  {
    id: '2',
    vehicleId: 'TZ-2345',
    vehicleName: 'Hino FG 175',
    driver: null,
    type: 'periodic',
    date: '2026-04-10',
    status: 'needs_attention',
    checklist: { tires: true, brakes: true, lights: false, fluids: true, engine: true, body: false },
  },
  {
    id: '3',
    vehicleId: 'TZ-4567',
    vehicleName: 'Foton Aumark BJ1086',
    driver: 'Emmanuel Msafiri',
    type: 'post_trip',
    date: '2026-04-14',
    status: 'passed',
    checklist: { tires: true, brakes: true, lights: true, fluids: true, engine: true, body: true },
  },
  {
    id: '4',
    vehicleId: 'TZ-5678',
    vehicleName: 'Toyota Dyna 150',
    driver: null,
    type: 'annual',
    date: '2026-04-01',
    status: 'failed',
    checklist: { tires: false, brakes: true, lights: true, fluids: true, engine: false, body: true },
  },
]

const columns: TableColumn<typeof inspections[0]>[] = [
  {
    key: 'vehicle',
    header: 'Vehicle',
    render: (item) => (
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-royal/10">
          <Truck className="h-5 w-5 text-primary-royal" />
        </div>
        <div>
          <p className="font-medium text-neutral-900">{item.vehicleName}</p>
          <p className="text-sm text-neutral-500">{item.vehicleId}</p>
        </div>
      </div>
    ),
  },
  { key: 'driver', header: 'Driver' },
  {
    key: 'type',
    header: 'Type',
    render: (item) => (
      <Badge variant="default" size="sm">{item.type.replace('_', ' ')}</Badge>
    ),
  },
  { key: 'date', header: 'Date' },
  {
    key: 'status',
    header: 'Status',
    render: (item) => {
      const statusConfig = {
        passed: { icon: CheckCircle, color: 'text-semantic-success', bg: 'bg-semantic-success/10' },
        failed: { icon: XCircle, color: 'text-semantic-error', bg: 'bg-semantic-error/10' },
        needs_attention: { icon: AlertTriangle, color: 'text-semantic-warning', bg: 'bg-semantic-warning/10' },
      }
      const config = statusConfig[item.status]
      return (
        <div className={`flex items-center gap-2 rounded-full px-3 py-1 ${config.bg}`}>
          <config.icon className={`h-4 w-4 ${config.color}`} />
          <span className={`text-sm font-medium ${config.color}`}>{item.status.replace('_', ' ')}</span>
        </div>
      )
    },
  },
]

export default function InspectionsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Vehicle Inspections</h1>
            <p className="text-neutral-500">Manage pre-trip, post-trip, and periodic inspections.</p>
          </div>
          <Button>
            <Plus className="h-4 w-4" />
            New Inspection
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-neutral-100 p-2">
                <ClipboardCheck className="h-5 w-5 text-neutral-500" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Total Inspections</p>
                <p className="text-xl font-bold text-neutral-900">248</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-success/10 p-2">
                <CheckCircle className="h-5 w-5 text-semantic-success" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Passed</p>
                <p className="text-xl font-bold text-semantic-success">218</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-warning/10 p-2">
                <AlertTriangle className="h-5 w-5 text-semantic-warning" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Needs Attention</p>
                <p className="text-xl font-bold text-semantic-warning">22</p>
              </div>
            </div>
          </Card>
          <Card padding="md">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-semantic-error/10 p-2">
                <XCircle className="h-5 w-5 text-semantic-error" />
              </div>
              <div>
                <p className="text-sm text-neutral-500">Failed</p>
                <p className="text-xl font-bold text-semantic-error">8</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Inspections Table */}
        <Card padding="none">
          <Table
            columns={columns}
            data={inspections}
            keyExtractor={(item) => item.id}
            onRowClick={(item) => console.log('Clicked inspection:', item.id)}
          />
        </Card>
      </div>
    </AdminLayout>
  )
}
