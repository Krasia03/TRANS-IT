'use client'

import { AdminLayout } from '@/components/layout'
import { Card } from '@/components/ui'
import { Map, Truck, Package, AlertTriangle } from 'lucide-react'

export default function CommandCenterPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div><h1 className="text-2xl font-bold text-neutral-900">Command Center</h1><p className="text-neutral-500">Real-time fleet monitoring with H3 hexagonal zones.</p></div>
        <div className="grid gap-4 lg:grid-cols-4">
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-semantic-info/10 p-2"><Truck className="h-5 w-5 text-semantic-info" /></div><div><p className="text-sm text-neutral-500">Active Vehicles</p><p className="text-xl font-bold text-neutral-900">14</p></div></div></Card>
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-royal/10 p-2"><Package className="h-5 w-5 text-primary-royal" /></div><div><p className="text-sm text-neutral-500">Active Shipments</p><p className="text-xl font-bold text-neutral-900">8</p></div></div></Card>
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-primary-golden/10 p-2"><Map className="h-5 w-5 text-primary-golden" /></div><div><p className="text-sm text-neutral-500">H3 Zones</p><p className="text-xl font-bold text-neutral-900">24</p></div></div></Card>
          <Card padding="md"><div className="flex items-center gap-3"><div className="rounded-lg bg-semantic-error/10 p-2"><AlertTriangle className="h-5 w-5 text-semantic-error" /></div><div><p className="text-sm text-neutral-500">Alerts</p><p className="text-xl font-bold text-neutral-900">2</p></div></div></Card>
        </div>
        <Card padding="none" className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary-royal/5 to-primary-golden/5 flex items-center justify-center"><div className="text-center"><Map className="h-16 w-16 text-primary-royal/30 mx-auto" /><p className="mt-4 text-lg font-medium text-neutral-400">H3 Hexagon Map Integration</p></div></div>
          <div className="h-96" />
        </Card>
      </div>
    </AdminLayout>
  )
}
