'use client';

import { useEffect, useState } from 'react';
import { commandCenterAPI, analyticsAPI } from '@/lib/api';
import { CommandCenterDashboard, LiveMetrics } from '@/types';
import { Card } from '@/components/ui/Card';
import { RevenueChart } from '@/components/charts/RevenueChart';
import { 
  Truck, Users, Package, AlertTriangle, TrendingUp, Clock,
  Fuel, MapPin, Activity, DollarSign, Target
} from 'lucide-react';

export default function DashboardPage() {
  const [dashboard, setDashboard] = useState<CommandCenterDashboard | null>(null);
  const [metrics, setMetrics] = useState<LiveMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [dashboardRes, metricsRes] = await Promise.all([
          commandCenterAPI.getDashboard(),
          commandCenterAPI.getMetrics(),
        ]);
        setDashboard(dashboardRes.data.data);
        setMetrics(metricsRes.data.data);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-royalBlue"></div>
      </div>
    );
  }

  const stats = [
    { label: 'Active Vehicles', value: dashboard?.active_vehicles ?? 0, icon: Truck, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Active Drivers', value: dashboard?.active_drivers ?? 0, icon: Users, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Pending Cargo', value: dashboard?.pending_cargo ?? 0, icon: Package, color: 'purple', bg: 'bg-purple-100' },
    { label: 'In Transit', value: dashboard?.in_transit_cargo ?? 0, icon: MapPin, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'Critical Alerts', value: dashboard?.critical_alerts ?? 0, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-100' },
    { label: 'Pending Alerts', value: dashboard?.pending_alerts ?? 0, icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-100' },
  ];

  const kpis = [
    { label: "Today's Revenue", value: `TZS ${(metrics?.today_revenue ?? 0).toLocaleString()}`, icon: DollarSign, trend: '+12%' },
    { label: 'Deliveries Today', value: metrics?.today_deliveries ?? 0, icon: Package, trend: '+5%' },
    { label: 'Fleet Utilization', value: `${metrics?.vehicle_utilization.percentage ?? 0}%`, icon: Target, trend: '+3%' },
    { label: 'Avg Delivery Time', value: `${metrics?.avg_delivery_time_minutes ?? 0} min`, icon: Clock, trend: '-8%' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Dashboard</h1>
          <p className="text-neutral-500 mt-1">TRANS-IT Command Center Overview</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-neutral-500">
          <Activity className="w-4 h-4" />
          <span>Last updated: {new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">{kpi.label}</p>
                <p className="text-xl font-bold text-neutral-900 mt-1">{kpi.value}</p>
                <span className={`text-xs font-medium ${kpi.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                  {kpi.trend} from yesterday
                </span>
              </div>
              <div className="p-2 rounded-lg bg-primary-100">
                <kpi.icon className="w-5 h-5 text-primary-royalBlue" />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-500">{stat.label}</p>
                <p className="text-2xl font-bold text-neutral-900 mt-1">{stat.value}</p>
              </div>
              <div className={`p-3 rounded-full ${stat.bg}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-neutral-900">Revenue Overview</h2>
            <TrendingUp className="w-5 h-5 text-neutral-400" />
          </div>
          <RevenueChart />
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-neutral-900">Fleet Status</h2>
            <Truck className="w-5 h-5 text-neutral-400" />
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="text-sm text-neutral-600">Active</span>
              </div>
              <span className="text-sm font-medium">{metrics?.vehicle_utilization.active ?? 0} vehicles</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <span className="text-sm text-neutral-600">Idle</span>
              </div>
              <span className="text-sm font-medium">{Math.max(0, (metrics?.vehicle_utilization.total ?? 0) - (metrics?.vehicle_utilization.active ?? 0))} vehicles</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span className="text-sm text-neutral-600">Maintenance</span>
              </div>
              <span className="text-sm font-medium">3 vehicles</span>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Recent Alerts</h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-neutral-900">Speed Violation</p>
                <p className="text-xs text-neutral-500">Vehicle T 123 ABC - 85 km/h</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
              <Fuel className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-neutral-900">Low Fuel Alert</p>
                <p className="text-xs text-neutral-500">Vehicle T 456 DEF - 15% fuel</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
              <Clock className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-neutral-900">Maintenance Due</p>
                <p className="text-xs text-neutral-500">Vehicle T 789 GHI - Service due</p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Performance</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2 border-b border-neutral-100">
              <span className="text-sm text-neutral-600">On-Time Rate</span>
              <span className="text-lg font-semibold text-green-600">94%</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-neutral-100">
              <span className="text-sm text-neutral-600">Customer Rating</span>
              <span className="text-lg font-semibold text-accent-goldenYellow">4.8/5</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-neutral-100">
              <span className="text-sm text-neutral-600">Fuel Efficiency</span>
              <span className="text-lg font-semibold text-blue-600">8.5 km/L</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-neutral-600">Accident Rate</span>
              <span className="text-lg font-semibold text-red-600">0.02%</span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Quick Actions</h2>
          <div className="space-y-2">
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-primary-royalBlue text-white rounded-lg hover:bg-blue-700 transition-colors">
              + Create New Dispatch
            </button>
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Add New Vehicle
            </button>
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Register Driver
            </button>
            <button className="w-full px-4 py-2 text-left text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
              + Create Cargo Request
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
