'use client'

import { AdminLayout } from '@/components/layout'
import { Card, Button, Input, Select } from '@/components/ui'
import { Settings as SettingsIcon, Bell, Globe, Shield, Key } from 'lucide-react'

export default function SettingsPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div><h1 className="text-2xl font-bold text-neutral-900">System Settings</h1><p className="text-neutral-500">Configure platform settings.</p></div>
        <div className="grid gap-6 lg:grid-cols-2">
          <Card padding="lg">
            <div className="flex items-center gap-3 mb-4"><SettingsIcon className="h-5 w-5 text-primary-royal" /><h3 className="text-lg font-semibold">General Settings</h3></div>
            <div className="space-y-4">
              <Input label="Platform Name" defaultValue="TRANS-IT" />
              <Input label="Support Email" defaultValue="support@transit.co.tz" />
              <Input label="Support Phone" defaultValue="+255 800 123 456" />
              <Select label="Default Currency" options={[{ value: 'tzs', label: 'Tanzanian Shilling (TZS)' }]} placeholder="Select currency" />
            </div>
          </Card>
          <Card padding="lg">
            <div className="flex items-center gap-3 mb-4"><Bell className="h-5 w-5 text-primary-royal" /><h3 className="text-lg font-semibold">Notifications</h3></div>
            <div className="space-y-4">
              <div className="flex items-center justify-between"><span className="text-sm font-medium">Email Notifications</span><input type="checkbox" className="rounded" /></div>
              <div className="flex items-center justify-between"><span className="text-sm font-medium">SMS Notifications</span><input type="checkbox" className="rounded" /></div>
              <div className="flex items-center justify-between"><span className="text-sm font-medium">Push Notifications</span><input type="checkbox" className="rounded" /></div>
            </div>
          </Card>
        </div>
        <div className="flex justify-end"><Button>Save Changes</Button></div>
      </div>
    </AdminLayout>
  )
}
