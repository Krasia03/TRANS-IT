'use client'

import Link from 'next/link'
import { Card, CardHeader, CardTitle, CardContent, Button, Input, Select } from '@/components/ui'
import { Truck } from 'lucide-react'

const roles = [
  { value: 'cargo_owner', label: 'Cargo Owner' },
  { value: 'driver', label: 'Driver' },
]

export default function RegisterPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-neutral-50 px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link href="/" className="mb-8 inline-flex items-center gap-2">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-royal"><Truck className="h-6 w-6 text-white" /></div>
          </Link>
          <h1 className="text-2xl font-bold text-neutral-900">TRANS-IT</h1>
          <p className="text-neutral-500">Create your account</p>
        </div>
        <Card padding="lg">
          <CardHeader><CardTitle>Sign Up</CardTitle></CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div className="grid gap-4 grid-cols-2">
                <Input label="First Name" placeholder="First name" />
                <Input label="Last Name" placeholder="Last name" />
              </div>
              <Input label="Email" type="email" placeholder="Enter your email" />
              <Input label="Phone" type="tel" placeholder="+255 XXX XXX XXX" />
              <Select label="Role" options={roles} placeholder="Select your role" />
              <Input label="Password" type="password" placeholder="Create a password" />
              <Input label="Confirm Password" type="password" placeholder="Confirm your password" />
              <Button type="submit" className="w-full">Create Account</Button>
            </form>
            <div className="mt-6 text-center text-sm text-neutral-500">
              Already have an account? <Link href="/login" className="text-primary-royal hover:underline">Sign in</Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
