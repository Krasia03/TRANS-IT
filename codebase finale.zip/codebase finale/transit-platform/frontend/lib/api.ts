import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
  meta?: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
  };
}

export const authAPI = {
  login: (email: string, password: string) =>
    api.post<ApiResponse<{ user: User; token: string }>>('/auth/login', { email, password }),
  register: (data: { name: string; email: string; password: string; phone?: string }) =>
    api.post<ApiResponse<{ user: User; token: string }>>('/auth/register', data),
  logout: () => api.post('/auth/logout'),
  me: () => api.get<ApiResponse<User>>('/auth/me'),
  refresh: () => api.post<ApiResponse<{ user: User; token: string }>>('/auth/refresh'),
};

export const vehiclesAPI = {
  getAll: (params?: Record<string, any>) => api.get<ApiResponse<Vehicle[]>>('/vehicles', { params }),
  getOne: (id: number) => api.get<ApiResponse<Vehicle>>(`/vehicles/${id}`),
  create: (data: Partial<Vehicle>) => api.post<ApiResponse<Vehicle>>('/vehicles', data),
  update: (id: number, data: Partial<Vehicle>) => api.put<ApiResponse<Vehicle>>(`/vehicles/${id}`, data),
  delete: (id: number) => api.delete(`/vehicles/${id}`),
  updateLocation: (id: number, data: { latitude: number; longitude: number; speed?: number; heading?: number }) =>
    api.post<ApiResponse<any>>(`/vehicles/${id}/location`, data),
};

export const driversAPI = {
  getAll: (params?: Record<string, any>) => api.get<ApiResponse<Driver[]>>('/drivers', { params }),
  getOne: (id: number) => api.get<ApiResponse<Driver>>(`/drivers/${id}`),
  create: (data: Partial<Driver>) => api.post<ApiResponse<Driver>>('/drivers', data),
  update: (id: number, data: Partial<Driver>) => api.put<ApiResponse<Driver>>(`/drivers/${id}`, data),
  delete: (id: number) => api.delete(`/drivers/${id}`),
  getPerformance: (id: number, params?: Record<string, any>) =>
    api.get<ApiResponse<DriverPerformance[]>>(`/drivers/${id}/performance`, { params }),
};

export const cargoAPI = {
  getAll: (params?: Record<string, any>) => api.get<ApiResponse<CargoRequest[]>>('/cargo', { params }),
  getOne: (id: number) => api.get<ApiResponse<CargoRequest>>(`/cargo/${id}`),
  create: (data: Partial<CargoRequest>) => api.post<ApiResponse<CargoRequest>>('/cargo', data),
  update: (id: number, data: Partial<CargoRequest>) => api.put<ApiResponse<CargoRequest>>(`/cargo/${id}`, data),
  assign: (id: number, data: { vehicle_id: number; driver_id: number; route_id?: number }) =>
    api.post<ApiResponse<CargoRequest>>(`/cargo/${id}/assign`, data),
  updateStatus: (id: number, status: string) =>
    api.post<ApiResponse<CargoRequest>>(`/cargo/${id}/status`, { status }),
  track: (id: number) => api.get<ApiResponse<{ cargo: CargoRequest; tracking: CargoTracking[] }>>(`/cargo/${id}/track`),
};

export const clientsAPI = {
  getAll: (params?: Record<string, any>) => api.get<ApiResponse<Client[]>>('/clients', { params }),
  getOne: (id: number) => api.get<ApiResponse<Client>>(`/clients/${id}`),
  create: (data: Partial<Client>) => api.post<ApiResponse<Client>>('/clients', data),
  update: (id: number, data: Partial<Client>) => api.put<ApiResponse<Client>>(`/clients/${id}`, data),
  delete: (id: number) => api.delete(`/clients/${id}`),
};

export const paymentsAPI = {
  getAll: (params?: Record<string, any>) => api.get<ApiResponse<Payment[]>>('/payments', { params }),
  getOne: (id: number) => api.get<ApiResponse<Payment>>(`/payments/${id}`),
  initiate: (data: { invoice_id: number; payment_method: string; amount: number; phone?: string }) =>
    api.post<ApiResponse<Payment>>('/payments/initiate', data),
};

export const invoicesAPI = {
  getAll: (params?: Record<string, any>) => api.get<ApiResponse<Invoice[]>>('/invoices', { params }),
  getOne: (id: number) => api.get<ApiResponse<Invoice>>(`/invoices/${id}`),
  create: (data: Partial<Invoice>) => api.post<ApiResponse<Invoice>>('/invoices', data),
  update: (id: number, data: Partial<Invoice>) => api.put<ApiResponse<Invoice>>(`/invoices/${id}`, data),
  send: (id: number) => api.post<ApiResponse<Invoice>>(`/invoices/${id}/send`),
};

export const commandCenterAPI = {
  getDashboard: () => api.get<ApiResponse<CommandCenterDashboard>>('/command-center/dashboard'),
  getFleetOverview: () => api.get<ApiResponse<FleetVehicle[]>>('/command-center/fleet'),
  getDemandMap: () => api.get<ApiResponse<DemandPoint[]>>('/command-center/demand-map'),
  getMetrics: () => api.get<ApiResponse<LiveMetrics>>('/command-center/metrics'),
};

export const analyticsAPI = {
  getRevenue: (period?: string) =>
    api.get<ApiResponse<RevenueInsights>>('/analytics/revenue', { params: { period } }),
  getHealth: () => api.get<ApiResponse<SystemHealth>>('/analytics/health'),
  getReport: (data: { start_date: string; end_date: string; metrics: string[] }) =>
    api.post<ApiResponse<any>>('/analytics/report', data),
};
