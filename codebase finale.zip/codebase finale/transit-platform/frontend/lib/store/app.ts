'use client'

import { create } from 'zustand'
import type { Vehicle, Driver, CargoRequest, DashboardKPIs } from '@/types'

interface AppState {
  sidebarOpen: boolean
  currentPortal: 'admin' | 'cargo-owner' | 'driver'
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
  setCurrentPortal: (portal: 'admin' | 'cargo-owner' | 'driver') => void
}

export const useAppStore = create<AppState>((set) => ({
  sidebarOpen: true,
  currentPortal: 'admin',

  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open: boolean) => set({ sidebarOpen: open }),
  setCurrentPortal: (portal: 'admin' | 'cargo-owner' | 'driver') =>
    set({ currentPortal: portal }),
}))

interface NotificationState {
  notifications: Array<{
    id: string
    type: 'success' | 'error' | 'warning' | 'info'
    message: string
    title?: string
  }>
  addNotification: (notification: Omit<NotificationState['notifications'][0], 'id'>) => void
  removeNotification: (id: string) => void
  clearNotifications: () => void
}

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],

  addNotification: (notification) => {
    const id = Math.random().toString(36).substring(2, 9)
    set((state) => ({
      notifications: [...state.notifications, { ...notification, id }],
    }))
    setTimeout(() => {
      set((state) => ({
        notifications: state.notifications.filter((n) => n.id !== id),
      }))
    }, 5000)
  },

  removeNotification: (id) =>
    set((state) => ({
      notifications: state.notifications.filter((n) => n.id !== id),
    })),

  clearNotifications: () => set({ notifications: [] }),
}))
