'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/lib/store/app'
import { LayoutDashboard, Package, Truck } from 'lucide-react'

export function PortalSwitcher() {
  const pathname = usePathname()
  const { currentPortal, setCurrentPortal } = useAppStore()

  const portals = [
    {
      id: 'admin' as const,
      label: 'Admin',
      description: 'Manage fleet, drivers, and operations',
      href: '/dashboard',
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      id: 'cargo-owner' as const,
      label: 'Cargo Owner',
      description: 'Book shipments and track deliveries',
      href: '/portal/cargo-owner/dashboard',
      icon: <Package className="h-5 w-5" />,
    },
    {
      id: 'driver' as const,
      label: 'Driver',
      description: 'Manage trips and view earnings',
      href: '/portal/driver/dashboard',
      icon: <Truck className="h-5 w-5" />,
    },
  ]

  return (
    <div className="flex items-center gap-1 rounded-lg bg-neutral-100 p-1">
      {portals.map((portal) => {
        const isActive = currentPortal === portal.id
        const isOnPortal = pathname.startsWith(portal.href.split('/dashboard')[0])

        return (
          <Link
            key={portal.id}
            href={portal.href}
            onClick={() => setCurrentPortal(portal.id)}
            className={cn(
              'flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-all',
              isActive
                ? 'bg-white text-primary-royal shadow-sm'
                : 'text-neutral-600 hover:text-neutral-900'
            )}
          >
            {portal.icon}
            <span className="hidden xl:inline">{portal.label}</span>
          </Link>
        )
      })}
    </div>
  )
}
