'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { clsx } from 'clsx';
import { useSidebarStore } from '@/lib/store';
import {
  LayoutDashboard, Truck, Users, Package, MapPin, Routes,
  FileText, CreditCard, Warehouse, AlertTriangle, Settings,
  BarChart3, ChevronLeft, ChevronRight, Zap
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Fleet Vehicles', href: '/fleet/vehicles', icon: Truck },
  { name: 'Drivers', href: '/drivers', icon: Users },
  { name: 'Cargo Requests', href: '/cargo/requests', icon: Package },
  { name: 'Routes', href: '/routes', icon: Routes },
  { name: 'Dispatches', href: '/dispatches', icon: MapPin },
  { name: 'Invoices', href: '/payments/invoices', icon: FileText },
  { name: 'Payments', href: '/payments', icon: CreditCard },
  { name: 'Warehouses', href: '/warehouses', icon: Warehouse },
  { name: 'Alerts', href: '/alerts', icon: AlertTriangle },
  { name: 'Analytics', href: '/analytics', icon: BarChart3 },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  const { isOpen, toggle } = useSidebarStore();

  return (
    <aside
      className={clsx(
        'fixed left-0 top-0 h-screen bg-white border-r border-neutral-200 transition-all duration-300 z-40',
        isOpen ? 'w-64' : 'w-16'
      )}
    >
      <div className="flex items-center justify-between h-16 px-4 border-b border-neutral-200">
        {isOpen && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary-royalBlue flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-neutral-900">TRANS-IT</span>
          </div>
        )}
        <button
          onClick={toggle}
          className="p-2 rounded-lg hover:bg-neutral-100 transition-colors"
        >
          {isOpen ? (
            <ChevronLeft className="w-5 h-5 text-neutral-500" />
          ) : (
            <ChevronRight className="w-5 h-5 text-neutral-500" />
          )}
        </button>
      </div>

      <nav className="p-3 space-y-1">
        {navigation.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={clsx(
                'flex items-center gap-3 px-3 py-2 rounded-lg transition-colors',
                isActive
                  ? 'bg-primary-royalBlue text-white'
                  : 'text-neutral-600 hover:bg-neutral-100'
              )}
              title={!isOpen ? item.name : undefined}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {isOpen && <span className="font-medium">{item.name}</span>}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
