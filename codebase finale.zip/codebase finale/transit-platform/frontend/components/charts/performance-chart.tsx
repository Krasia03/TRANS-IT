'use client'

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'

interface PerformanceDataPoint {
  name: string
  value: number
  secondaryValue?: number
}

interface PerformanceChartProps {
  data: PerformanceDataPoint[]
  title?: string
  primaryLabel?: string
  secondaryLabel?: string
  layout?: 'horizontal' | 'vertical'
}

export function PerformanceChart({
  data,
  title = 'Performance',
  primaryLabel = 'Value',
  secondaryLabel,
  layout = 'horizontal',
}: PerformanceChartProps) {
  return (
    <div className="w-full">
      <h3 className="text-lg font-semibold text-neutral-900 mb-4">{title}</h3>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            layout={layout}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={layout === 'horizontal'} />
            {layout === 'horizontal' ? (
              <>
                <XAxis
                  dataKey="name"
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  height={60}
                  angle={-45}
                  textAnchor="end"
                />
                <YAxis
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
              </>
            ) : (
              <>
                <XAxis
                  type="number"
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  dataKey="name"
                  type="category"
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  width={80}
                />
              </>
            )}
            <Tooltip
              contentStyle={{
                backgroundColor: '#FFFFFF',
                border: '1px solid #E5E7EB',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              }}
              formatter={(value: number, name: string) => [
                value,
                name === 'value' ? primaryLabel : secondaryLabel || primaryLabel,
              ]}
              labelStyle={{ color: '#374151', fontWeight: 500 }}
            />
            <Bar
              dataKey="value"
              fill="#2563EB"
              radius={[4, 4, 0, 0]}
              name={primaryLabel}
              maxBarSize={50}
            />
            {secondaryLabel && (
              <Bar
                dataKey="secondaryValue"
                fill="#F5C842"
                radius={[4, 4, 0, 0]}
                name={secondaryLabel}
                maxBarSize={50}
              />
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
