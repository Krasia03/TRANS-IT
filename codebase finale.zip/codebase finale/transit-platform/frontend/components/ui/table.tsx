import { ReactNode } from 'react';
import { clsx } from 'clsx';

interface TableProps {
  children: ReactNode;
  className?: string;
}

export function Table({ children, className }: TableProps) {
  return (
    <div className={clsx('overflow-x-auto', className)}>
      <table className="w-full">{children}</table>
    </div>
  );
}

Table.Header = function TableHeader({ children, className }: TableProps) {
  return (
    <thead className={clsx('bg-neutral-50 border-b border-neutral-200', className)}>
      {children}
    </thead>
  );
};

Table.Head = function TableHead({ children, className }: TableProps) {
  return (
    <th className={clsx('px-4 py-3 text-left text-xs font-semibold text-neutral-600 uppercase tracking-wider', className)}>
      {children}
    </th>
  );
};

Table.Body = function TableBody({ children, className }: TableProps) {
  return (
    <tbody className={clsx('divide-y divide-neutral-200', className)}>
      {children}
    </tbody>
  );
};

Table.Row = function TableRow({ children, className }: TableProps) {
  return (
    <tr className={clsx('hover:bg-neutral-50 transition-colors', className)}>
      {children}
    </tr>
  );
};

Table.Cell = function TableCell({ children, className }: TableProps) {
  return (
    <td className={clsx('px-4 py-3 text-sm text-neutral-700', className)}>
      {children}
    </td>
  );
};
