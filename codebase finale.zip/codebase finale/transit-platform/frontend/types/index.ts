export interface User {
  id: number;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  status: 'active' | 'inactive' | 'suspended';
  roles: string[];
  permissions?: string[];
  last_login_at?: string;
  created_at: string;
  updated_at: string;
}

export interface Vehicle {
  id: number;
  registration_number: string;
  vin?: string;
  make: string;
  model: string;
  year: number;
  type: 'truck' | 'van' | 'pickup' | 'trailer' | 'bus' | 'motorcycle';
  capacity: number;
  fuel_type: 'petrol' | 'diesel' | 'electric' | 'hybrid' | 'lpg';
  status: 'active' | 'inactive' | 'maintenance' | 'decommissioned';
  current_location?: {
    latitude: number;
    longitude: number;
    speed?: number;
    heading?: number;
  };
  last_location_update?: string;
  odometer_reading: number;
  fuel_level?: number;
  insurance_expiry?: string;
  road_tax_expiry?: string;
  inspection_due?: string;
  image_url?: string;
  primary_driver?: Driver;
  created_at: string;
  updated_at: string;
}

export interface Driver {
  id: number;
  employee_id: string;
  first_name: string;
  last_name: string;
  full_name: string;
  email: string;
  phone: string;
  date_of_birth?: string;
  license_number: string;
  license_type: 'A' | 'B' | 'C' | 'D' | 'E' | 'CM';
  license_expiry: string;
  address?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  profile_photo?: string;
  status: 'active' | 'inactive' | 'on_leave' | 'suspended' | 'terminated';
  hire_date: string;
  termination_date?: string;
  rating: number;
  total_ratings: number;
  total_deliveries: number;
  accidents_count: number;
  is_license_valid: boolean;
  user?: User;
  primary_vehicle?: Vehicle;
  created_at: string;
  updated_at: string;
}

export interface DriverPerformance {
  id: number;
  driver_id: number;
  period_start: string;
  period_end: string;
  total_deliveries: number;
  successful_deliveries: number;
  failed_deliveries: number;
  on_time_deliveries: number;
  success_rate: number;
  on_time_rate: number;
  total_distance: number;
  average_delivery_time: number;
  customer_rating: number;
  safety_score: number;
  fuel_efficiency: number;
  incidents_count: number;
  revenue_generated: number;
}

export interface Client {
  id: number;
  client_number: string;
  type: 'corporate' | 'individual';
  company_name?: string;
  contact_person: string;
  display_name: string;
  email: string;
  phone: string;
  address?: string;
  city?: string;
  region?: string;
  country: string;
  postal_code?: string;
  tax_id?: string;
  credit_limit: number;
  payment_terms: string;
  status: 'active' | 'inactive' | 'suspended';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface CargoRequest {
  id: number;
  request_number: string;
  client_id: number;
  client_type: 'corporate' | 'individual';
  vehicle_id?: number;
  driver_id?: number;
  route_id?: number;
  cargo_type: 'general' | 'fragile' | 'hazardous' | 'perishable' | 'livestock' | 'oversized';
  description: string;
  weight: number;
  volume?: number;
  pickup_location: string;
  pickup_latitude?: number;
  pickup_longitude?: number;
  pickup_date: string;
  delivery_location: string;
  delivery_latitude?: number;
  delivery_longitude?: number;
  delivery_date?: string;
  estimated_distance?: number;
  estimated_duration?: number;
  actual_distance?: number;
  actual_duration?: number;
  status: 'pending' | 'confirmed' | 'assigned' | 'at_pickup' | 'in_transit' | 'at_delivery' | 'delivered' | 'completed' | 'cancelled' | 'failed';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  special_requirements?: string[];
  price: number;
  formatted_price: string;
  currency: string;
  tracking_number?: string;
  completed_at?: string;
  cancelled_at?: string;
  cancellation_reason?: string;
  client?: Client;
  vehicle?: Vehicle;
  driver?: Driver;
  route?: Route;
  created_at: string;
  updated_at: string;
}

export interface Route {
  id: number;
  route_number: string;
  name: string;
  origin: string;
  origin_latitude?: number;
  origin_longitude?: number;
  destination: string;
  destination_latitude?: number;
  destination_longitude?: number;
  waypoints?: any[];
  total_distance: number;
  formatted_distance: string;
  estimated_duration: number;
  formatted_duration: string;
  route_type: 'shortest' | 'fastest' | 'scenic' | 'custom';
  status: 'draft' | 'active' | 'inactive' | 'archived';
  optimized_at?: string;
  optimization_score?: number;
  created_at: string;
  updated_at: string;
}

export interface Invoice {
  id: number;
  invoice_number: string;
  cargo_request_id?: number;
  client_id: number;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total_amount: number;
  formatted_total: string;
  currency: string;
  status: 'draft' | 'pending' | 'sent' | 'paid' | 'overdue' | 'cancelled' | 'refunded';
  is_overdue: boolean;
  issue_date: string;
  due_date: string;
  paid_date?: string;
  payment_method?: string;
  payment_reference?: string;
  client?: Client;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: number;
  payment_number: string;
  invoice_id?: number;
  client_id: number;
  amount: number;
  formatted_amount: string;
  currency: string;
  payment_method: 'mpesa' | 'tigo_pesa' | 'airtel_money' | 'bank_transfer' | 'cash' | 'escrow';
  provider_reference?: string;
  status: 'pending' | 'processing' | 'successful' | 'failed' | 'refunded';
  paid_at?: string;
  failed_at?: string;
  failure_reason?: string;
  client?: Client;
  created_at: string;
}

export interface Escrow {
  id: number;
  escrow_number: string;
  cargo_request_id?: number;
  client_id: number;
  amount: number;
  formatted_amount: string;
  currency: string;
  status: 'pending' | 'held' | 'released' | 'refunded' | 'disputed';
  held_at?: string;
  released_at?: string;
  refunded_at?: string;
  refund_reason?: string;
  created_at: string;
}

export interface Alert {
  id: number;
  alert_number: string;
  type: 'speed' | 'geofence' | 'maintenance' | 'fuel' | 'idle' | 'accident' | 'emergency' | 'sos';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  message: string;
  vehicle_id?: number;
  driver_id?: number;
  latitude?: number;
  longitude?: number;
  location_name?: string;
  acknowledged_at?: string;
  resolved_at?: string;
  is_acknowledged: boolean;
  is_resolved: boolean;
  vehicle?: Vehicle;
  driver?: Driver;
  created_at: string;
}

export interface CargoTracking {
  id: number;
  cargo_request_id: number;
  status: string;
  location?: string;
  latitude?: number;
  longitude?: number;
  description: string;
  recorded_at: string;
}

export interface CommandCenterDashboard {
  active_vehicles: number;
  active_drivers: number;
  pending_cargo: number;
  in_transit_cargo: number;
  critical_alerts: number;
  pending_alerts: number;
}

export interface FleetVehicle {
  id: number;
  registration_number: string;
  type: string;
  status: string;
  current_location?: any;
  last_location_update?: string;
  fuel_level?: number;
  driver?: { id: number; name: string };
}

export interface DemandPoint {
  lat: number;
  lng: number;
  demand: number;
}

export interface LiveMetrics {
  today_deliveries: number;
  today_revenue: number;
  vehicle_utilization: {
    total: number;
    active: number;
    percentage: number;
  };
  avg_delivery_time_minutes: number;
}

export interface RevenueInsights {
  period_days: number;
  total_revenue: number;
  total_deliveries: number;
  avg_order_value: number;
  daily_revenue: { date: string; revenue: number; deliveries: number }[];
  revenue_by_status: { status: string; revenue: number; count: number }[];
}

export interface SystemHealth {
  vehicles: {
    total: number;
    active: number;
    maintenance: number;
    insurance_expiring: number;
  };
  cargo: {
    total: number;
    pending: number;
    in_transit: number;
    completed: number;
    failed: number;
  };
  payments: {
    total_transactions: number;
    successful: number;
    pending: number;
    failed: number;
    total_amount: number;
  };
}
