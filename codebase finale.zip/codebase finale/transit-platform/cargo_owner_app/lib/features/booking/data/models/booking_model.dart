import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'booking_model.g.dart';

@JsonSerializable()
class BookingRequest {
  @JsonKey(name: 'pickup_address')
  final String pickupAddress;
  @JsonKey(name: 'pickup_latitude')
  final double pickupLatitude;
  @JsonKey(name: 'pickup_longitude')
  final double pickupLongitude;
  @JsonKey(name: 'delivery_address')
  final String deliveryAddress;
  @JsonKey(name: 'delivery_latitude')
  final double deliveryLatitude;
  @JsonKey(name: 'delivery_longitude')
  final double deliveryLongitude;
  @JsonKey(name: 'pickup_date')
  final String pickupDate;
  @JsonKey(name: 'pickup_time')
  final String pickupTime;
  @JsonKey(name: 'cargo_type')
  final String cargoType;
  final double weight;
  final String description;
  @JsonKey(name: 'special_instructions')
  final String? specialInstructions;

  const BookingRequest({
    required this.pickupAddress,
    required this.pickupLatitude,
    required this.pickupLongitude,
    required this.deliveryAddress,
    required this.deliveryLatitude,
    required this.deliveryLongitude,
    required this.pickupDate,
    required this.pickupTime,
    required this.cargoType,
    required this.weight,
    required this.description,
    this.specialInstructions,
  });

  factory BookingRequest.fromJson(Map<String, dynamic> json) =>
      _$BookingRequestFromJson(json);

  Map<String, dynamic> toJson() => _$BookingRequestToJson(this);
}

@JsonSerializable()
class Booking extends Equatable {
  final String id;
  @JsonKey(name: 'booking_number')
  final String bookingNumber;
  @JsonKey(name: 'pickup_location')
  final Location pickupLocation;
  @JsonKey(name: 'delivery_location')
  final Location deliveryLocation;
  @JsonKey(name: 'pickup_date')
  final DateTime pickupDate;
  final String status;
  final double fare;
  @JsonKey(name: 'cargo_details')
  final CargoDetails cargoDetails;
  @JsonKey(name: 'created_at')
  final DateTime createdAt;

  const Booking({
    required this.id,
    required this.bookingNumber,
    required this.pickupLocation,
    required this.deliveryLocation,
    required this.pickupDate,
    required this.status,
    required this.fare,
    required this.cargoDetails,
    required this.createdAt,
  });

  factory Booking.fromJson(Map<String, dynamic> json) => _$BookingFromJson(json);

  Map<String, dynamic> toJson() => _$BookingToJson(this);

  @override
  List<Object?> get props => [
        id,
        bookingNumber,
        pickupLocation,
        deliveryLocation,
        pickupDate,
        status,
        fare,
        cargoDetails,
        createdAt,
      ];
}

@JsonSerializable()
class Location extends Equatable {
  final String address;
  final double latitude;
  final double longitude;

  const Location({
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  factory Location.fromJson(Map<String, dynamic> json) =>
      _$LocationFromJson(json);

  Map<String, dynamic> toJson() => _$LocationToJson(this);

  @override
  List<Object?> get props => [address, latitude, longitude];
}

@JsonSerializable()
class CargoDetails extends Equatable {
  final String type;
  final double weight;
  final String description;

  const CargoDetails({
    required this.type,
    required this.weight,
    required this.description,
  });

  factory CargoDetails.fromJson(Map<String, dynamic> json) =>
      _$CargoDetailsFromJson(json);

  Map<String, dynamic> toJson() => _$CargoDetailsToJson(this);

  @override
  List<Object?> get props => [type, weight, description];
}

@JsonSerializable()
class FareEstimate extends Equatable {
  final double distance;
  final double fare;
  @JsonKey(name: 'estimated_time')
  final String estimatedTime;

  const FareEstimate({
    required this.distance,
    required this.fare,
    required this.estimatedTime,
  });

  factory FareEstimate.fromJson(Map<String, dynamic> json) =>
      _$FareEstimateFromJson(json);

  Map<String, dynamic> toJson() => _$FareEstimateToJson(this);

  @override
  List<Object?> get props => [distance, fare, estimatedTime];
}
