// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'booking_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BookingRequest _$BookingRequestFromJson(Map<String, dynamic> json) =>
    BookingRequest(
      pickupAddress: json['pickup_address'] as String,
      pickupLatitude: (json['pickup_latitude'] as num).toDouble(),
      pickupLongitude: (json['pickup_longitude'] as num).toDouble(),
      deliveryAddress: json['delivery_address'] as String,
      deliveryLatitude: (json['delivery_latitude'] as num).toDouble(),
      deliveryLongitude: (json['delivery_longitude'] as num).toDouble(),
      pickupDate: json['pickup_date'] as String,
      pickupTime: json['pickup_time'] as String,
      cargoType: json['cargo_type'] as String,
      weight: (json['weight'] as num).toDouble(),
      description: json['description'] as String,
      specialInstructions: json['special_instructions'] as String?,
    );

Map<String, dynamic> _$BookingRequestToJson(BookingRequest instance) =>
    <String, dynamic>{
      'pickup_address': instance.pickupAddress,
      'pickup_latitude': instance.pickupLatitude,
      'pickup_longitude': instance.pickupLongitude,
      'delivery_address': instance.deliveryAddress,
      'delivery_latitude': instance.deliveryLatitude,
      'delivery_longitude': instance.deliveryLongitude,
      'pickup_date': instance.pickupDate,
      'pickup_time': instance.pickupTime,
      'cargo_type': instance.cargoType,
      'weight': instance.weight,
      'description': instance.description,
      'special_instructions': instance.specialInstructions,
    };

Booking _$BookingFromJson(Map<String, dynamic> json) => Booking(
      id: json['id'] as String,
      bookingNumber: json['booking_number'] as String,
      pickupLocation:
          Location.fromJson(json['pickup_location'] as Map<String, dynamic>),
      deliveryLocation:
          Location.fromJson(json['delivery_location'] as Map<String, dynamic>),
      pickupDate: DateTime.parse(json['pickup_date'] as String),
      status: json['status'] as String,
      fare: (json['fare'] as num).toDouble(),
      cargoDetails:
          CargoDetails.fromJson(json['cargo_details'] as Map<String, dynamic>),
      createdAt: DateTime.parse(json['created_at'] as String),
    );

Map<String, dynamic> _$BookingToJson(Booking instance) => <String, dynamic>{
      'id': instance.id,
      'booking_number': instance.bookingNumber,
      'pickup_location': instance.pickupLocation,
      'delivery_location': instance.deliveryLocation,
      'pickup_date': instance.pickupDate.toIso8601String(),
      'status': instance.status,
      'fare': instance.fare,
      'cargo_details': instance.cargoDetails,
      'created_at': instance.createdAt.toIso8601String(),
    };

Location _$LocationFromJson(Map<String, dynamic> json) => Location(
      address: json['address'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
    );

Map<String, dynamic> _$LocationToJson(Location instance) => <String, dynamic>{
      'address': instance.address,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
    };

CargoDetails _$CargoDetailsFromJson(Map<String, dynamic> json) => CargoDetails(
      type: json['type'] as String,
      weight: (json['weight'] as num).toDouble(),
      description: json['description'] as String,
    );

Map<String, dynamic> _$CargoDetailsToJson(CargoDetails instance) =>
    <String, dynamic>{
      'type': instance.type,
      'weight': instance.weight,
      'description': instance.description,
    };

FareEstimate _$FareEstimateFromJson(Map<String, dynamic> json) => FareEstimate(
      distance: (json['distance'] as num).toDouble(),
      fare: (json['fare'] as num).toDouble(),
      estimatedTime: json['estimated_time'] as String,
    );

Map<String, dynamic> _$FareEstimateToJson(FareEstimate instance) =>
    <String, dynamic>{
      'distance': instance.distance,
      'fare': instance.fare,
      'estimated_time': instance.estimatedTime,
    };
