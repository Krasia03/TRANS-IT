import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../bloc/booking_bloc.dart';
import '../../../../shared/widgets/custom_button.dart';
import '../../../../shared/widgets/custom_text_field.dart';

class NewBookingPage extends StatefulWidget {
  const NewBookingPage({super.key});

  @override
  State<NewBookingPage> createState() => _NewBookingPageState();
}

class _NewBookingPageState extends State<NewBookingPage> {
  final PageController _pageController = PageController();
  int _currentStep = 0;

  final _pickupController = TextEditingController();
  final _deliveryController = TextEditingController();
  final _dateController = TextEditingController();
  final _timeController = TextEditingController();
  final _weightController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _instructionsController = TextEditingController();
  String _selectedCargoType = 'General Goods';

  final List<String> _cargoTypes = [
    'General Goods',
    'Electronics',
    'Fragile Items',
    'Perishable',
    'Heavy Machinery',
    'Documents',
    'Medical Supplies',
    'Other',
  ];

  @override
  void dispose() {
    _pageController.dispose();
    _pickupController.dispose();
    _deliveryController.dispose();
    _dateController.dispose();
    _timeController.dispose();
    _weightController.dispose();
    _descriptionController.dispose();
    _instructionsController.dispose();
    super.dispose();
  }

  void _nextStep() {
    if (_currentStep < 2) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      setState(() {
        _currentStep++;
      });
    }
  }

  void _previousStep() {
    if (_currentStep > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      setState(() {
        _currentStep--;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.newBooking),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () {
            context.read<BookingBloc>().add(BookingReset());
            context.pop();
          },
        ),
      ),
      body: BlocListener<BookingBloc, BookingState>(
        listener: (context, state) {
          if (state is BookingSuccess) {
            context.go('/booking-confirm/${state.booking.id}');
          } else if (state is BookingError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.error,
              ),
            );
          }
        },
        child: Column(
          children: [
            // Stepper Progress
            _buildStepper(),

            // Step Content
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _buildLocationStep(),
                  _buildDateTimeStep(),
                  _buildCargoStep(),
                ],
              ),
            ),

            // Navigation Buttons
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  if (_currentStep > 0)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _previousStep,
                        child: const Text(AppStrings.back),
                      ),
                    ),
                  if (_currentStep > 0) const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: BlocBuilder<BookingBloc, BookingState>(
                      builder: (context, state) {
                        return CustomButton(
                          text: _currentStep == 2
                              ? AppStrings.confirmBooking
                              : AppStrings.next,
                          onPressed: () {
                            if (_currentStep == 2) {
                              _submitBooking();
                            } else {
                              _nextStep();
                            }
                          },
                          isLoading: state is BookingSubmitting,
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepper() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          _buildStepIndicator(0, 'Location'),
          _buildStepLine(0),
          _buildStepIndicator(1, 'Schedule'),
          _buildStepLine(1),
          _buildStepIndicator(2, 'Cargo'),
        ],
      ),
    );
  }

  Widget _buildStepIndicator(int step, String label) {
    final isActive = _currentStep >= step;
    final isCurrent = _currentStep == step;

    return Expanded(
      child: Column(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: isActive ? AppColors.primary : AppColors.border,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: isActive && !isCurrent
                  ? const Icon(Icons.check, color: Colors.white, size: 18)
                  : Text(
                      '${step + 1}',
                      style: TextStyle(
                        color: isActive ? Colors.white : AppColors.textTertiary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: isCurrent ? AppColors.primary : AppColors.textSecondary,
                  fontWeight: isCurrent ? FontWeight.w600 : FontWeight.normal,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepLine(int afterStep) {
    final isActive = _currentStep > afterStep;
    return Expanded(
      child: Container(
        height: 2,
        color: isActive ? AppColors.primary : AppColors.border,
      ),
    );
  }

  Widget _buildLocationStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Pickup & Delivery Locations',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'Enter the pickup and delivery addresses for your shipment',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
          const SizedBox(height: 24),
          Text(
            AppStrings.pickupLocation,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          CustomTextField(
            controller: _pickupController,
            label: 'Enter pickup address',
            prefixIcon: Icons.location_on,
          ),
          const SizedBox(height: 24),
          Text(
            AppStrings.deliveryLocation,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          CustomTextField(
            controller: _deliveryController,
            label: 'Enter delivery address',
            prefixIcon: Icons.location_on_outlined,
          ),
        ],
      ),
    );
  }

  Widget _buildDateTimeStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Pickup Schedule',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'When should we pick up your shipment?',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
          const SizedBox(height: 24),
          Text(
            AppStrings.selectDate,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          CustomTextField(
            controller: _dateController,
            label: 'Select date',
            prefixIcon: Icons.calendar_today,
            suffixIcon: IconButton(
              icon: const Icon(Icons.arrow_drop_down),
              onPressed: () async {
                final date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now().add(const Duration(days: 1)),
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 30)),
                );
                if (date != null) {
                  _dateController.text =
                      '${date.day}/${date.month}/${date.year}';
                }
              },
            ),
          ),
          const SizedBox(height: 24),
          Text(
            AppStrings.selectTime,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          CustomTextField(
            controller: _timeController,
            label: 'Select time',
            prefixIcon: Icons.access_time,
            suffixIcon: IconButton(
              icon: const Icon(Icons.arrow_drop_down),
              onPressed: () async {
                final time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (time != null) {
                  _timeController.text = time.format(context);
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCargoStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Cargo Information',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'Tell us about what you\'re shipping',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
          const SizedBox(height: 24),
          Text(
            AppStrings.cargoType,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _selectedCargoType,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.inventory_2),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            items: _cargoTypes.map((type) {
              return DropdownMenuItem(value: type, child: Text(type));
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedCargoType = value!;
              });
            },
          ),
          const SizedBox(height: 16),
          CustomTextField(
            controller: _weightController,
            label: AppStrings.cargoWeight,
            prefixIcon: Icons.scale,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          CustomTextField(
            controller: _descriptionController,
            label: AppStrings.cargoDescription,
            prefixIcon: Icons.description,
            maxLines: 3,
          ),
          const SizedBox(height: 16),
          CustomTextField(
            controller: _instructionsController,
            label: '${AppStrings.specialInstructions} (Optional)',
            prefixIcon: Icons.note,
            maxLines: 2,
          ),
        ],
      ),
    );
  }

  void _submitBooking() {
    context.read<BookingBloc>().add(BookingLocationUpdated(
          pickupAddress: _pickupController.text,
          pickupLat: -6.7924,
          pickupLng: 39.2083,
          deliveryAddress: _deliveryController.text,
          deliveryLat: -6.3690,
          deliveryLng: 34.8888,
        ));

    context.read<BookingBloc>().add(BookingDateTimeUpdated(
          pickupDate: _dateController.text,
          pickupTime: _timeController.text,
        ));

    context.read<BookingBloc>().add(BookingCargoUpdated(
          cargoType: _selectedCargoType,
          weight: double.tryParse(_weightController.text) ?? 0,
          description: _descriptionController.text,
          specialInstructions: _instructionsController.text,
        ));

    context.read<BookingBloc>().add(BookingSubmitted());
  }
}
