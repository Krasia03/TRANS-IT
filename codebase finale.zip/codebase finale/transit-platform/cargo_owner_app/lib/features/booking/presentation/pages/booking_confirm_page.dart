import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../../../../shared/widgets/custom_button.dart';

class BookingConfirmPage extends StatelessWidget {
  final String bookingId;

  const BookingConfirmPage({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(),
              // Success Icon
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_circle,
                  color: AppColors.success,
                  size: 80,
                ),
              ),
              const SizedBox(height: 32),
              Text(
                AppStrings.success,
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.success,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Your booking has been confirmed',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppColors.textSecondary,
                    ),
              ),
              const SizedBox(height: 32),

              // Booking Details Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildDetailRow(
                        context,
                        'Booking Number',
                        'BKG-${DateTime.now().millisecondsSinceEpoch}',
                      ),
                      const Divider(height: 24),
                      _buildDetailRow(
                        context,
                        'Pickup',
                        'Kariakoo Market, Dar es Salaam',
                      ),
                      const Divider(height: 24),
                      _buildDetailRow(
                        context,
                        'Delivery',
                        'Mwanza City Center',
                      ),
                      const Divider(height: 24),
                      _buildDetailRow(
                        context,
                        'Scheduled Date',
                        'January 18, 2024',
                      ),
                      const Divider(height: 24),
                      _buildDetailRow(
                        context,
                        'Est. Fare',
                        CurrencyFormatter.format(150000),
                        valueColor: AppColors.success,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Notification Text
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.info.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: AppColors.info),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'A driver will be assigned to your shipment soon. You\'ll receive a notification.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppColors.info,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),

              // Action Buttons
              CustomButton(
                text: 'Track Shipment',
                onPressed: () {
                  context.go('/shipments');
                },
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () {
                  context.go('/dashboard');
                },
                child: const Text('Back to Dashboard'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(
    BuildContext context,
    String label,
    String value, {
    Color? valueColor,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: valueColor ?? AppColors.textPrimary,
                ),
            textAlign: TextAlign.end,
          ),
        ),
      ],
    );
  }
}
