import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../data/models/booking_model.dart';

// Events
abstract class BookingEvent extends Equatable {
  const BookingEvent();

  @override
  List<Object?> get props => [];
}

class BookingInitiated extends BookingEvent {}

class BookingLocationUpdated extends BookingEvent {
  final String? pickupAddress;
  final double? pickupLat;
  final double? pickupLng;
  final String? deliveryAddress;
  final double? deliveryLat;
  final double? deliveryLng;

  const BookingLocationUpdated({
    this.pickupAddress,
    this.pickupLat,
    this.pickupLng,
    this.deliveryAddress,
    this.deliveryLat,
    this.deliveryLng,
  });

  @override
  List<Object?> get props => [
        pickupAddress,
        pickupLat,
        pickupLng,
        deliveryAddress,
        deliveryLat,
        deliveryLng,
      ];
}

class BookingDateTimeUpdated extends BookingEvent {
  final String? pickupDate;
  final String? pickupTime;

  const BookingDateTimeUpdated({this.pickupDate, this.pickupTime});

  @override
  List<Object?> get props => [pickupDate, pickupTime];
}

class BookingCargoUpdated extends BookingEvent {
  final String? cargoType;
  final double? weight;
  final String? description;
  final String? specialInstructions;

  const BookingCargoUpdated({
    this.cargoType,
    this.weight,
    this.description,
    this.specialInstructions,
  });

  @override
  List<Object?> get props => [cargoType, weight, description, specialInstructions];
}

class BookingSubmitted extends BookingEvent {}

class BookingReset extends BookingEvent {}

// States
abstract class BookingState extends Equatable {
  const BookingState();

  @override
  List<Object?> get props => [];
}

class BookingInitial extends BookingState {}

class BookingInProgress extends BookingState {
  final String? pickupAddress;
  final double? pickupLat;
  final double? pickupLng;
  final String? deliveryAddress;
  final double? deliveryLat;
  final double? deliveryLng;
  final String? pickupDate;
  final String? pickupTime;
  final String? cargoType;
  final double? weight;
  final String? description;
  final String? specialInstructions;

  const BookingInProgress({
    this.pickupAddress,
    this.pickupLat,
    this.pickupLng,
    this.deliveryAddress,
    this.deliveryLat,
    this.deliveryLng,
    this.pickupDate,
    this.pickupTime,
    this.cargoType,
    this.weight,
    this.description,
    this.specialInstructions,
  });

  BookingInProgress copyWith({
    String? pickupAddress,
    double? pickupLat,
    double? pickupLng,
    String? deliveryAddress,
    double? deliveryLat,
    double? deliveryLng,
    String? pickupDate,
    String? pickupTime,
    String? cargoType,
    double? weight,
    String? description,
    String? specialInstructions,
  }) {
    return BookingInProgress(
      pickupAddress: pickupAddress ?? this.pickupAddress,
      pickupLat: pickupLat ?? this.pickupLat,
      pickupLng: pickupLng ?? this.pickupLng,
      deliveryAddress: deliveryAddress ?? this.deliveryAddress,
      deliveryLat: deliveryLat ?? this.deliveryLat,
      deliveryLng: deliveryLng ?? this.deliveryLng,
      pickupDate: pickupDate ?? this.pickupDate,
      pickupTime: pickupTime ?? this.pickupTime,
      cargoType: cargoType ?? this.cargoType,
      weight: weight ?? this.weight,
      description: description ?? this.description,
      specialInstructions: specialInstructions ?? this.specialInstructions,
    );
  }

  @override
  List<Object?> get props => [
        pickupAddress,
        pickupLat,
        pickupLng,
        deliveryAddress,
        deliveryLat,
        deliveryLng,
        pickupDate,
        pickupTime,
        cargoType,
        weight,
        description,
        specialInstructions,
      ];
}

class BookingSubmitting extends BookingState {}

class BookingSuccess extends BookingState {
  final Booking booking;

  const BookingSuccess(this.booking);

  @override
  List<Object?> get props => [booking];
}

class BookingError extends BookingState {
  final String message;

  const BookingError(this.message);

  @override
  List<Object?> get props => [message];
}

// BLoC
class BookingBloc extends Bloc<BookingEvent, BookingState> {
  BookingBloc() : super(BookingInitial()) {
    on<BookingInitiated>(_onBookingInitiated);
    on<BookingLocationUpdated>(_onBookingLocationUpdated);
    on<BookingDateTimeUpdated>(_onBookingDateTimeUpdated);
    on<BookingCargoUpdated>(_onBookingCargoUpdated);
    on<BookingSubmitted>(_onBookingSubmitted);
    on<BookingReset>(_onBookingReset);
  }

  void _onBookingInitiated(
    BookingInitiated event,
    Emitter<BookingState> emit,
  ) {
    emit(const BookingInProgress());
  }

  void _onBookingLocationUpdated(
    BookingLocationUpdated event,
    Emitter<BookingState> emit,
  ) {
    if (state is BookingInProgress) {
      emit((state as BookingInProgress).copyWith(
        pickupAddress: event.pickupAddress,
        pickupLat: event.pickupLat,
        pickupLng: event.pickupLng,
        deliveryAddress: event.deliveryAddress,
        deliveryLat: event.deliveryLat,
        deliveryLng: event.deliveryLng,
      ));
    }
  }

  void _onBookingDateTimeUpdated(
    BookingDateTimeUpdated event,
    Emitter<BookingState> emit,
  ) {
    if (state is BookingInProgress) {
      emit((state as BookingInProgress).copyWith(
        pickupDate: event.pickupDate,
        pickupTime: event.pickupTime,
      ));
    }
  }

  void _onBookingCargoUpdated(
    BookingCargoUpdated event,
    Emitter<BookingState> emit,
  ) {
    if (state is BookingInProgress) {
      emit((state as BookingInProgress).copyWith(
        cargoType: event.cargoType,
        weight: event.weight,
        description: event.description,
        specialInstructions: event.specialInstructions,
      ));
    }
  }

  Future<void> _onBookingSubmitted(
    BookingSubmitted event,
    Emitter<BookingState> emit,
  ) async {
    if (state is BookingInProgress) {
      final bookingData = state as BookingInProgress;

      // Validate required fields
      if (bookingData.pickupAddress == null ||
          bookingData.deliveryAddress == null ||
          bookingData.pickupDate == null ||
          bookingData.cargoType == null) {
        emit(const BookingError('Please complete all required fields'));
        emit(bookingData);
        return;
      }

      emit(BookingSubmitting());

      try {
        // Simulate API call - replace with actual repository call
        await Future.delayed(const Duration(seconds: 2));

        final mockBooking = Booking(
          id: '123',
          bookingNumber: 'BKG-${DateTime.now().millisecondsSinceEpoch}',
          pickupLocation: Location(
            address: bookingData.pickupAddress!,
            latitude: bookingData.pickupLat ?? 0,
            longitude: bookingData.pickupLng ?? 0,
          ),
          deliveryLocation: Location(
            address: bookingData.deliveryAddress!,
            latitude: bookingData.deliveryLat ?? 0,
            longitude: bookingData.deliveryLng ?? 0,
          ),
          pickupDate: DateTime.now(),
          status: 'confirmed',
          fare: 150000,
          cargoDetails: CargoDetails(
            type: bookingData.cargoType!,
            weight: bookingData.weight ?? 0,
            description: bookingData.description ?? '',
          ),
          createdAt: DateTime.now(),
        );

        emit(BookingSuccess(mockBooking));
      } catch (e) {
        emit(BookingError(e.toString()));
        emit(bookingData);
      }
    }
  }

  void _onBookingReset(
    BookingReset event,
    Emitter<BookingState> emit,
  ) {
    emit(BookingInitial());
  }
}
