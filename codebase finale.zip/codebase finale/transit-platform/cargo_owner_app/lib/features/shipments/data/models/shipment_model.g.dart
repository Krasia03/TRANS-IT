// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shipment_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Shipment _$ShipmentFromJson(Map<String, dynamic> json) => Shipment(
      id: json['id'] as String,
      shipmentNumber: json['shipment_number'] as String,
      pickupLocation:
          Location.fromJson(json['pickup_location'] as Map<String, dynamic>),
      deliveryLocation:
          Location.fromJson(json['delivery_location'] as Map<String, dynamic>),
      pickupTime: DateTime.parse(json['pickup_time'] as String),
      estimatedDelivery: DateTime.parse(json['estimated_delivery'] as String),
      status: json['status'] as String,
      fare: (json['fare'] as num).toDouble(),
      cargoDetails:
          CargoDetails.fromJson(json['cargo_details'] as Map<String, dynamic>),
      driverInfo: json['driver_info'] == null
          ? null
          : DriverInfo.fromJson(json['driver_info'] as Map<String, dynamic>),
      currentLocation: json['current_location'] == null
          ? null
          : Location.fromJson(json['current_location'] as Map<String, dynamic>),
      timeline: (json['timeline'] as List<dynamic>)
          .map((e) => TimelineEvent.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ShipmentToJson(Shipment instance) => <String, dynamic>{
      'id': instance.id,
      'shipment_number': instance.shipmentNumber,
      'pickup_location': instance.pickupLocation,
      'delivery_location': instance.deliveryLocation,
      'pickup_time': instance.pickupTime.toIso8601String(),
      'estimated_delivery': instance.estimatedDelivery.toIso8601String(),
      'status': instance.status,
      'fare': instance.fare,
      'cargo_details': instance.cargoDetails,
      'driver_info': instance.driverInfo,
      'current_location': instance.currentLocation,
      'timeline': instance.timeline,
    };

Location _$LocationFromJson(Map<String, dynamic> json) => Location(
      address: json['address'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
    );

Map<String, dynamic> _$LocationToJson(Location instance) => <String, dynamic>{
      'address': instance.address,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
    };

CargoDetails _$CargoDetailsFromJson(Map<String, dynamic> json) => CargoDetails(
      type: json['type'] as String,
      weight: (json['weight'] as num).toDouble(),
      description: json['description'] as String,
    );

Map<String, dynamic> _$CargoDetailsToJson(CargoDetails instance) =>
    <String, dynamic>{
      'type': instance.type,
      'weight': instance.weight,
      'description': instance.description,
    };

DriverInfo _$DriverInfoFromJson(Map<String, dynamic> json) => DriverInfo(
      id: json['id'] as String,
      name: json['name'] as String,
      phone: json['phone'] as String,
      vehiclePlate: json['vehicle_plate'] as String,
      vehicleType: json['vehicle_type'] as String,
      rating: (json['rating'] as num).toDouble(),
    );

Map<String, dynamic> _$DriverInfoToJson(DriverInfo instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'phone': instance.phone,
      'vehicle_plate': instance.vehiclePlate,
      'vehicle_type': instance.vehicleType,
      'rating': instance.rating,
    };

TimelineEvent _$TimelineEventFromJson(Map<String, dynamic> json) =>
    TimelineEvent(
      id: json['id'] as String,
      status: json['status'] as String,
      description: json['description'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      location: json['location'] as String?,
    );

Map<String, dynamic> _$TimelineEventToJson(TimelineEvent instance) =>
    <String, dynamic>{
      'id': instance.id,
      'status': instance.status,
      'description': instance.description,
      'timestamp': instance.timestamp.toIso8601String(),
      'location': instance.location,
    };
