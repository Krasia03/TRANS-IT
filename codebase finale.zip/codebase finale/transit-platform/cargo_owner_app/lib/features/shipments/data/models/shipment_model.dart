import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'shipment_model.g.dart';

@JsonSerializable()
class Shipment extends Equatable {
  final String id;
  @JsonKey(name: 'shipment_number')
  final String shipmentNumber;
  @JsonKey(name: 'pickup_location')
  final Location pickupLocation;
  @JsonKey(name: 'delivery_location')
  final Location deliveryLocation;
  @JsonKey(name: 'pickup_time')
  final DateTime pickupTime;
  @JsonKey(name: 'estimated_delivery')
  final DateTime estimatedDelivery;
  final String status;
  final double fare;
  @JsonKey(name: 'cargo_details')
  final CargoDetails cargoDetails;
  @JsonKey(name: 'driver_info')
  final DriverInfo? driverInfo;
  @JsonKey(name: 'current_location')
  final Location? currentLocation;
  final List<TimelineEvent> timeline;

  const Shipment({
    required this.id,
    required this.shipmentNumber,
    required this.pickupLocation,
    required this.deliveryLocation,
    required this.pickupTime,
    required this.estimatedDelivery,
    required this.status,
    required this.fare,
    required this.cargoDetails,
    this.driverInfo,
    this.currentLocation,
    required this.timeline,
  });

  factory Shipment.fromJson(Map<String, dynamic> json) =>
      _$ShipmentFromJson(json);

  Map<String, dynamic> toJson() => _$ShipmentToJson(this);

  @override
  List<Object?> get props => [
        id,
        shipmentNumber,
        pickupLocation,
        deliveryLocation,
        pickupTime,
        estimatedDelivery,
        status,
        fare,
        cargoDetails,
        driverInfo,
        currentLocation,
        timeline,
      ];
}

@JsonSerializable()
class Location extends Equatable {
  final String address;
  final double latitude;
  final double longitude;

  const Location({
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  factory Location.fromJson(Map<String, dynamic> json) =>
      _$LocationFromJson(json);

  Map<String, dynamic> toJson() => _$LocationToJson(this);

  @override
  List<Object?> get props => [address, latitude, longitude];
}

@JsonSerializable()
class CargoDetails extends Equatable {
  final String type;
  final double weight;
  final String description;

  const CargoDetails({
    required this.type,
    required this.weight,
    required this.description,
  });

  factory CargoDetails.fromJson(Map<String, dynamic> json) =>
      _$CargoDetailsFromJson(json);

  Map<String, dynamic> toJson() => _$CargoDetailsToJson(this);

  @override
  List<Object?> get props => [type, weight, description];
}

@JsonSerializable()
class DriverInfo extends Equatable {
  final String id;
  final String name;
  final String phone;
  @JsonKey(name: 'vehicle_plate')
  final String vehiclePlate;
  @JsonKey(name: 'vehicle_type')
  final String vehicleType;
  final double rating;

  const DriverInfo({
    required this.id,
    required this.name,
    required this.phone,
    required this.vehiclePlate,
    required this.vehicleType,
    required this.rating,
  });

  factory DriverInfo.fromJson(Map<String, dynamic> json) =>
      _$DriverInfoFromJson(json);

  Map<String, dynamic> toJson() => _$DriverInfoToJson(this);

  @override
  List<Object?> get props => [id, name, phone, vehiclePlate, vehicleType, rating];
}

@JsonSerializable()
class TimelineEvent extends Equatable {
  final String id;
  final String status;
  final String description;
  final DateTime timestamp;
  final String? location;

  const TimelineEvent({
    required this.id,
    required this.status,
    required this.description,
    required this.timestamp,
    this.location,
  });

  factory TimelineEvent.fromJson(Map<String, dynamic> json) =>
      _$TimelineEventFromJson(json);

  Map<String, dynamic> toJson() => _$TimelineEventToJson(this);

  @override
  List<Object?> get props => [id, status, description, timestamp, location];
}
