import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../bloc/shipment_bloc.dart';

class LiveTrackingPage extends StatefulWidget {
  final String shipmentId;

  const LiveTrackingPage({super.key, required this.shipmentId});

  @override
  State<LiveTrackingPage> createState() => _LiveTrackingPageState();
}

class _LiveTrackingPageState extends State<LiveTrackingPage> {
  GoogleMapController? _mapController;

  @override
  void initState() {
    super.initState();
    context.read<ShipmentBloc>().add(ShipmentTrackRequested(widget.shipmentId));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<ShipmentBloc, ShipmentState>(
        builder: (context, state) {
          if (state is ShipmentLoading) {
            return const LoadingIndicator();
          }

          if (state is ShipmentTrackingLoaded) {
            return Stack(
              children: [
                // Map
                GoogleMap(
                  onMapCreated: (controller) {
                    _mapController = controller;
                    _fitBounds(
                      state.currentLocation.latitude,
                      state.currentLocation.longitude,
                      state.destination.latitude,
                      state.destination.longitude,
                    );
                  },
                  initialCameraPosition: CameraPosition(
                    target: LatLng(
                      state.currentLocation.latitude,
                      state.currentLocation.longitude,
                    ),
                    zoom: 10,
                  ),
                  markers: {
                    Marker(
                      markerId: const MarkerId('driver'),
                      position: LatLng(
                        state.currentLocation.latitude,
                        state.currentLocation.longitude,
                      ),
                      infoWindow: InfoWindow(
                        title: 'Driver Location',
                        snippet: state.currentLocation.address,
                      ),
                      icon: BitmapDescriptor.defaultMarkerWithHue(
                        BitmapDescriptor.hueBlue,
                      ),
                    ),
                    Marker(
                      markerId: const MarkerId('destination'),
                      position: LatLng(
                        state.destination.latitude,
                        state.destination.longitude,
                      ),
                      infoWindow: InfoWindow(
                        title: 'Destination',
                        snippet: state.destination.address,
                      ),
                      icon: BitmapDescriptor.defaultMarkerWithHue(
                        BitmapDescriptor.hueRed,
                      ),
                    ),
                  },
                  polylines: {
                    Polyline(
                      polylineId: const PolylineId('route'),
                      points: [
                        LatLng(
                          state.currentLocation.latitude,
                          state.currentLocation.longitude,
                        ),
                        LatLng(
                          state.destination.latitude,
                          state.destination.longitude,
                        ),
                      ],
                      color: AppColors.primary,
                      width: 4,
                    ),
                  },
                  myLocationEnabled: true,
                  myLocationButtonEnabled: false,
                  zoomControlsEnabled: false,
                ),

                // Top Bar
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.white,
                          child: IconButton(
                            icon: const Icon(Icons.arrow_back,
                                color: AppColors.primary),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ),
                        const Spacer(),
                        CircleAvatar(
                          backgroundColor: Colors.white,
                          child: IconButton(
                            icon: const Icon(Icons.my_location,
                                color: AppColors.primary),
                            onPressed: () {
                              _mapController?.animateCamera(
                                CameraUpdate.newLatLng(
                                  LatLng(
                                    state.currentLocation.latitude,
                                    state.currentLocation.longitude,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Bottom Info Card
                Positioned(
                  bottom: 16,
                  left: 16,
                  right: 16,
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.local_shipping,
                                  color: AppColors.primary,
                                  size: 32,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Your shipment is on the way',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge
                                          ?.copyWith(
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Driver: John Mwakasege',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium
                                          ?.copyWith(
                                            color: AppColors.textSecondary,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _buildInfoItem(
                                context,
                                'Distance',
                                '245 km',
                              ),
                              _buildInfoItem(
                                context,
                                'ETA',
                                '2h 30m',
                              ),
                              _buildInfoItem(
                                context,
                                'Progress',
                                '65%',
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          }

          return const Center(child: Text('Unable to load tracking'));
        },
      ),
    );
  }

  void _fitBounds(
    double lat1,
    double lng1,
    double lat2,
    double lng2,
  ) {
    final bounds = LatLngBounds(
      southwest: LatLng(
        lat1 < lat2 ? lat1 : lat2,
        lng1 < lng2 ? lng1 : lng2,
      ),
      northeast: LatLng(
        lat1 > lat2 ? lat1 : lat2,
        lng1 > lng2 ? lng1 : lng2,
      ),
    );
    _mapController?.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 50),
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }

  Widget _buildInfoItem(BuildContext context, String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.primary,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.textSecondary,
              ),
        ),
      ],
    );
  }
}
