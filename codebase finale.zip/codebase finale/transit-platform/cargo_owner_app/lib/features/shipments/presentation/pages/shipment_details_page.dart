import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../bloc/shipment_bloc.dart';
import '../../data/models/shipment_model.dart';

class ShipmentDetailsPage extends StatelessWidget {
  final String shipmentId;

  const ShipmentDetailsPage({super.key, required this.shipmentId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.shipmentDetails),
        actions: [
          IconButton(
            icon: const Icon(Icons.phone),
            onPressed: () {},
          ),
        ],
      ),
      body: BlocBuilder<ShipmentBloc, ShipmentState>(
        builder: (context, state) {
          if (state is ShipmentLoading) {
            return const LoadingIndicator();
          }

          if (state is ShipmentDetailsLoaded) {
            return _buildShipmentDetails(context, state.shipment);
          }

          return const Center(child: Text('Shipment not found'));
        },
      ),
    );
  }

  Widget _buildShipmentDetails(BuildContext context, Shipment shipment) {
    Color statusColor;
    String statusLabel;
    switch (shipment.status) {
      case 'pending':
        statusColor = AppColors.shipmentPending;
        statusLabel = 'Pending';
        break;
      case 'in_transit':
        statusColor = AppColors.shipmentInTransit;
        statusLabel = 'In Transit';
        break;
      case 'delivered':
        statusColor = AppColors.shipmentDelivered;
        statusLabel = 'Delivered';
        break;
      default:
        statusColor = AppColors.textSecondary;
        statusLabel = shipment.status;
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Status Header
          Container(
            width: double.infinity,
            color: statusColor.withOpacity(0.1),
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Icon(
                  shipment.status == 'delivered'
                      ? Icons.check_circle
                      : Icons.local_shipping,
                  color: statusColor,
                  size: 48,
                ),
                const SizedBox(height: 12),
                Text(
                  statusLabel,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: statusColor,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  shipment.shipmentNumber,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Driver Info Card
                if (shipment.driverInfo != null) ...[
                  _buildDriverCard(context, shipment.driverInfo!),
                  const SizedBox(height: 24),
                ],

                // Route Info
                Text(
                  'Route',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildLocationRow(
                          context,
                          Icons.radio_button_checked,
                          'Pickup',
                          shipment.pickupLocation.address,
                          DateFormatter.formatDateTime(shipment.pickupTime),
                          AppColors.primary,
                        ),
                        const SizedBox(height: 16),
                        _buildLocationRow(
                          context,
                          Icons.location_on,
                          'Delivery',
                          shipment.deliveryLocation.address,
                          'ETA: ${DateFormatter.formatDateTime(shipment.estimatedDelivery)}',
                          AppColors.error,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Cargo Info
                Text(
                  'Cargo Information',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildInfoRow('Type', shipment.cargoDetails.type),
                        const Divider(),
                        _buildInfoRow(
                          'Weight',
                          '${shipment.cargoDetails.weight} kg',
                        ),
                        const Divider(),
                        _buildInfoRow(
                          'Description',
                          shipment.cargoDetails.description,
                        ),
                        const Divider(),
                        _buildInfoRow(
                          'Fare',
                          CurrencyFormatter.format(shipment.fare),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Timeline
                Text(
                  AppStrings.shipmentTimeline,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 12),
                _buildTimeline(context, shipment.timeline),

                const SizedBox(height: 24),

                // Action Button
                if (shipment.status == 'in_transit')
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        context.push('/live-tracking/${shipment.id}');
                      },
                      icon: const Icon(Icons.location_on),
                      label: const Text(AppStrings.liveTracking),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDriverCard(BuildContext context, DriverInfo driver) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: AppColors.primary,
              child: Text(
                driver.name.substring(0, 1),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    driver.name,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        Icons.star,
                        size: 16,
                        color: AppColors.accent,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        driver.rating.toStringAsFixed(1),
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${driver.vehicleType} - ${driver.vehiclePlate}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.phone, color: AppColors.success),
                  style: IconButton.styleFrom(
                    backgroundColor: AppColors.success.withOpacity(0.1),
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.message, color: AppColors.primary),
                  style: IconButton.styleFrom(
                    backgroundColor: AppColors.primary.withOpacity(0.1),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationRow(
    BuildContext context,
    IconData icon,
    String label,
    String address,
    String time,
    Color color,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textTertiary,
                    ),
              ),
              const SizedBox(height: 2),
              Text(
                address,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 2),
              Text(
                time,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeline(BuildContext context, List<TimelineEvent> timeline) {
    if (timeline.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: Text(
              'No timeline events yet',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppColors.textSecondary,
                  ),
            ),
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: timeline.asMap().entries.map((entry) {
            final index = entry.key;
            final event = entry.value;
            final isLast = index == timeline.length - 1;

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                    ),
                    if (!isLast)
                      Container(
                        width: 2,
                        height: 50,
                        color: AppColors.border,
                      ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        event.description,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        DateFormatter.formatDateTime(event.timestamp),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: AppColors.textSecondary,
                            ),
                      ),
                      if (event.location != null) ...[
                        const SizedBox(height: 2),
                        Text(
                          event.location!,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: AppColors.textTertiary,
                              ),
                        ),
                      ],
                      if (!isLast) const SizedBox(height: 16),
                    ],
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}
