import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../bloc/shipment_bloc.dart';
import '../../data/models/shipment_model.dart';

class ShipmentsListPage extends StatefulWidget {
  const ShipmentsListPage({super.key});

  @override
  State<ShipmentsListPage> createState() => _ShipmentsListPageState();
}

class _ShipmentsListPageState extends State<ShipmentsListPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  String _selectedFilter = 'all';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadShipments();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _loadShipments() {
    context.read<ShipmentBloc>().add(const ShipmentsFetchRequested());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.shipments),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: AppStrings.all),
            Tab(text: AppStrings.pending),
            Tab(text: AppStrings.inTransit),
            Tab(text: AppStrings.delivered),
          ],
        ),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: AppStrings.searchShipments,
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),

          // Shipments List
          Expanded(
            child: BlocBuilder<ShipmentBloc, ShipmentState>(
              builder: (context, state) {
                if (state is ShipmentLoading) {
                  return const LoadingIndicator();
                }

                if (state is ShipmentError) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(state.message),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _loadShipments,
                          child: const Text(AppStrings.retry),
                        ),
                      ],
                    ),
                  );
                }

                if (state is ShipmentsLoaded) {
                  return TabBarView(
                    controller: _tabController,
                    children: [
                      _buildShipmentsList(state.shipments),
                      _buildShipmentsList(state.shipments
                          .where((s) => s.status == 'pending')
                          .toList()),
                      _buildShipmentsList(state.shipments
                          .where((s) => s.status == 'in_transit')
                          .toList()),
                      _buildShipmentsList(state.shipments
                          .where((s) => s.status == 'delivered')
                          .toList()),
                    ],
                  );
                }

                return const Center(child: Text(AppStrings.noData));
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShipmentsList(List<Shipment> shipments) {
    if (shipments.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox_outlined,
              size: 64,
              color: AppColors.textTertiary,
            ),
            const SizedBox(height: 16),
            Text(
              'No shipments found',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppColors.textSecondary,
                  ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async => _loadShipments(),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: shipments.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          return _buildShipmentCard(shipments[index]);
        },
      ),
    );
  }

  Widget _buildShipmentCard(Shipment shipment) {
    Color statusColor;
    switch (shipment.status) {
      case 'pending':
        statusColor = AppColors.shipmentPending;
        break;
      case 'in_transit':
        statusColor = AppColors.shipmentInTransit;
        break;
      case 'delivered':
        statusColor = AppColors.shipmentDelivered;
        break;
      default:
        statusColor = AppColors.textSecondary;
    }

    String statusLabel;
    switch (shipment.status) {
      case 'pending':
        statusLabel = 'Pending';
        break;
      case 'in_transit':
        statusLabel = 'In Transit';
        break;
      case 'delivered':
        statusLabel = 'Delivered';
        break;
      default:
        statusLabel = shipment.status;
    }

    return Card(
      child: InkWell(
        onTap: () {
          context.push('/shipment-details/${shipment.id}');
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    shipment.shipmentNumber,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      statusLabel,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: statusColor,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    children: [
                      Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                      ),
                      Container(
                        width: 1,
                        height: 30,
                        color: AppColors.border,
                      ),
                      Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: AppColors.error,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          shipment.pickupLocation.address,
                          style: Theme.of(context).textTheme.bodyMedium,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 24),
                        Text(
                          shipment.deliveryLocation.address,
                          style: Theme.of(context).textTheme.bodyMedium,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              if (shipment.status == 'in_transit') ...[
                const SizedBox(height: 12),
                Divider(color: AppColors.divider),
                const SizedBox(height: 12),
                Row(
                  children: [
                    if (shipment.driverInfo != null) ...[
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: AppColors.primary,
                        child: Text(
                          shipment.driverInfo!.name.substring(0, 1),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              shipment.driverInfo!.name,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                            Text(
                              shipment.driverInfo!.vehiclePlate,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppColors.textSecondary,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      TextButton.icon(
                        onPressed: () {
                          context.push('/live-tracking/${shipment.id}');
                        },
                        icon: const Icon(Icons.location_on, size: 18),
                        label: const Text('Track'),
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
