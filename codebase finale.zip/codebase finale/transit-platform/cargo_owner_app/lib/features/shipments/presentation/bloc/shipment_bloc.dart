import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../data/models/shipment_model.dart';

// Events
abstract class ShipmentEvent extends Equatable {
  const ShipmentEvent();

  @override
  List<Object?> get props => [];
}

class ShipmentsFetchRequested extends ShipmentEvent {
  final String? status;

  const ShipmentsFetchRequested({this.status});

  @override
  List<Object?> get props => [status];
}

class ShipmentDetailsFetchRequested extends ShipmentEvent {
  final String shipmentId;

  const ShipmentDetailsFetchRequested(this.shipmentId);

  @override
  List<Object?> get props => [shipmentId];
}

class ShipmentTrackRequested extends ShipmentEvent {
  final String shipmentId;

  const ShipmentTrackRequested(this.shipmentId);

  @override
  List<Object?> get props => [shipmentId];
}

// States
abstract class ShipmentState extends Equatable {
  const ShipmentState();

  @override
  List<Object?> get props => [];
}

class ShipmentInitial extends ShipmentState {}

class ShipmentLoading extends ShipmentState {}

class ShipmentsLoaded extends ShipmentState {
  final List<Shipment> shipments;

  const ShipmentsLoaded(this.shipments);

  @override
  List<Object?> get props => [shipments];
}

class ShipmentDetailsLoaded extends ShipmentState {
  final Shipment shipment;

  const ShipmentDetailsLoaded(this.shipment);

  @override
  List<Object?> get props => [shipment];
}

class ShipmentTrackingLoaded extends ShipmentState {
  final Location currentLocation;
  final Location destination;

  const ShipmentTrackingLoaded({
    required this.currentLocation,
    required this.destination,
  });

  @override
  List<Object?> get props => [currentLocation, destination];
}

class ShipmentError extends ShipmentState {
  final String message;

  const ShipmentError(this.message);

  @override
  List<Object?> get props => [message];
}

// BLoC
class ShipmentBloc extends Bloc<ShipmentEvent, ShipmentState> {
  ShipmentBloc() : super(ShipmentInitial()) {
    on<ShipmentsFetchRequested>(_onShipmentsFetchRequested);
    on<ShipmentDetailsFetchRequested>(_onShipmentDetailsFetchRequested);
    on<ShipmentTrackRequested>(_onShipmentTrackRequested);
  }

  Future<void> _onShipmentsFetchRequested(
    ShipmentsFetchRequested event,
    Emitter<ShipmentState> emit,
  ) async {
    emit(ShipmentLoading());
    try {
      // Simulate API call - replace with actual repository call
      await Future.delayed(const Duration(seconds: 1));

      final mockShipments = [
        Shipment(
          id: '1',
          shipmentNumber: 'SHP-001234',
          pickupLocation: const Location(
            address: 'Kariakoo Market, Dar es Salaam',
            latitude: -6.7924,
            longitude: 39.2083,
          ),
          deliveryLocation: const Location(
            address: 'Mwanza City Center',
            latitude: -6.3690,
            longitude: 34.8888,
          ),
          pickupTime: DateTime.now().subtract(const Duration(hours: 5)),
          estimatedDelivery: DateTime.now().add(const Duration(hours: 8)),
          status: 'in_transit',
          fare: 150000,
          cargoDetails: const CargoDetails(
            type: 'Electronics',
            weight: 250,
            description: 'Laptop computers and accessories',
          ),
          driverInfo: const DriverInfo(
            id: 'd1',
            name: 'John Mwakasege',
            phone: '+255 712 345 678',
            vehiclePlate: 'T 123 ABC',
            vehicleType: 'Truck',
            rating: 4.8,
          ),
          currentLocation: const Location(
            address: 'Singida Region',
            latitude: -6.8,
            longitude: 34.5,
          ),
          timeline: const [],
        ),
        Shipment(
          id: '2',
          shipmentNumber: 'SHP-001235',
          pickupLocation: const Location(
            address: 'Arusha Bus Station',
            latitude: -3.3667,
            longitude: 36.6833,
          ),
          deliveryLocation: const Location(
            address: 'Dodoma University',
            latitude: -6.1832,
            longitude: 35.7413,
          ),
          pickupTime: DateTime.now().add(const Duration(hours: 2)),
          estimatedDelivery: DateTime.now().add(const Duration(hours: 10)),
          status: 'pending',
          fare: 95000,
          cargoDetails: const CargoDetails(
            type: 'Documents',
            weight: 5,
            description: 'Official documents',
          ),
          timeline: const [],
        ),
      ];

      emit(ShipmentsLoaded(mockShipments));
    } catch (e) {
      emit(ShipmentError(e.toString()));
    }
  }

  Future<void> _onShipmentDetailsFetchRequested(
    ShipmentDetailsFetchRequested event,
    Emitter<ShipmentState> emit,
  ) async {
    emit(ShipmentLoading());
    try {
      await Future.delayed(const Duration(seconds: 1));

      final mockShipment = Shipment(
        id: event.shipmentId,
        shipmentNumber: 'SHP-${event.shipmentId}',
        pickupLocation: const Location(
          address: 'Kariakoo Market, Dar es Salaam',
          latitude: -6.7924,
          longitude: 39.2083,
        ),
        deliveryLocation: const Location(
          address: 'Mwanza City Center',
          latitude: -6.3690,
          longitude: 34.8888,
        ),
        pickupTime: DateTime.now().subtract(const Duration(hours: 5)),
        estimatedDelivery: DateTime.now().add(const Duration(hours: 8)),
        status: 'in_transit',
        fare: 150000,
        cargoDetails: const CargoDetails(
          type: 'Electronics',
          weight: 250,
          description: 'Laptop computers and accessories',
        ),
        driverInfo: const DriverInfo(
          id: 'd1',
          name: 'John Mwakasege',
          phone: '+255 712 345 678',
          vehiclePlate: 'T 123 ABC',
          vehicleType: 'Truck',
          rating: 4.8,
        ),
        currentLocation: const Location(
          address: 'Singida Region',
          latitude: -6.8,
          longitude: 34.5,
        ),
        timeline: [
          TimelineEvent(
            id: 't1',
            status: 'confirmed',
            description: 'Booking confirmed',
            timestamp: DateTime.now().subtract(const Duration(hours: 6)),
            location: 'System',
          ),
          TimelineEvent(
            id: 't2',
            status: 'picked_up',
            description: 'Package picked up from sender',
            timestamp: DateTime.now().subtract(const Duration(hours: 5)),
            location: 'Kariakoo Market',
          ),
          TimelineEvent(
            id: 't3',
            status: 'in_transit',
            description: 'Shipment in transit',
            timestamp: DateTime.now().subtract(const Duration(hours: 4)),
            location: 'Morogoro Road',
          ),
        ],
      );

      emit(ShipmentDetailsLoaded(mockShipment));
    } catch (e) {
      emit(ShipmentError(e.toString()));
    }
  }

  Future<void> _onShipmentTrackRequested(
    ShipmentTrackRequested event,
    Emitter<ShipmentState> emit,
  ) async {
    emit(ShipmentLoading());
    try {
      await Future.delayed(const Duration(milliseconds: 500));

      emit(ShipmentTrackingLoaded(
        currentLocation: const Location(
          address: 'Singida Region',
          latitude: -6.8,
          longitude: 34.5,
        ),
        destination: const Location(
          address: 'Mwanza City Center',
          latitude: -6.3690,
          longitude: 34.8888,
        ),
      ));
    } catch (e) {
      emit(ShipmentError(e.toString()));
    }
  }
}
