class AppStrings {
  AppStrings._();

  // App Info
  static const String appName = 'TRANS-IT';
  static const String appTagline = 'Smart Logistics Platform';

  // Auth Strings
  static const String login = 'Login';
  static const String register = 'Register';
  static const String logout = 'Logout';
  static const String email = 'Email';
  static const String phone = 'Phone';
  static const String password = 'Password';
  static const String confirmPassword = 'Confirm Password';
  static const String forgotPassword = 'Forgot Password?';
  static const String rememberMe = 'Remember me';
  static const String dontHaveAccount = "Don't have an account?";
  static const String alreadyHaveAccount = 'Already have an account?';
  static const String signUp = 'Sign Up';
  static const String signIn = 'Sign In';
  static const String fullName = 'Full Name';
  static const String createAccount = 'Create Account';
  static const String selectAccountType = 'Select Account Type';
  static const String cargoOwner = 'Cargo Owner';
  static const String driver = 'Driver';

  // Dashboard Strings
  static const String dashboard = 'Dashboard';
  static const String welcome = 'Welcome';
  static const String activeShipments = 'Active Shipments';
  static const String completedShipments = 'Completed Shipments';
  static const String pendingPayments = 'Pending Payments';
  static const String quickBook = 'Quick Book';
  static const String recentShipments = 'Recent Shipments';
  static const String viewAll = 'View All';

  // Booking Strings
  static const String newBooking = 'New Booking';
  static const String pickupLocation = 'Pickup Location';
  static const String deliveryLocation = 'Delivery Location';
  static const String pickupDate = 'Pickup Date';
  static const String deliveryDate = 'Delivery Date';
  static const String cargoDetails = 'Cargo Details';
  static const String cargoType = 'Cargo Type';
  static const String cargoWeight = 'Weight (kg)';
  static const String cargoDescription = 'Description';
  static const String estimatedPrice = 'Estimated Price';
  static const String confirmBooking = 'Confirm Booking';
  static const String bookingConfirmed = 'Booking Confirmed!';
  static const String bookingReference = 'Booking Reference';
  static const String next = 'Next';
  static const String previous = 'Previous';
  static const String step = 'Step';
  static const String of = 'of';

  // Shipment Strings
  static const String shipments = 'Shipments';
  static const String allShipments = 'All Shipments';
  static const String shipmentDetails = 'Shipment Details';
  static const String liveTracking = 'Live Tracking';
  static const String tracking = 'Tracking';
  static const String status = 'Status';
  static const String driverInfo = 'Driver Info';
  static const String vehicleInfo = 'Vehicle Info';
  static const String routeMap = 'Route Map';
  static const String timeline = 'Timeline';
  static const String estimatedArrival = 'Estimated Arrival';
  static const String searchShipments = 'Search shipments...';
  static const String filter = 'Filter';
  static const String sortBy = 'Sort By';

  // Status Strings
  static const String pending = 'Pending';
  static const String confirmed = 'Confirmed';
  static const String inTransit = 'In Transit';
  static const String outForDelivery = 'Out for Delivery';
  static const String delivered = 'Delivered';
  static const String cancelled = 'Cancelled';

  // Payment Strings
  static const String payments = 'Payments';
  static const String paymentMethods = 'Payment Methods';
  static const String addPaymentMethod = 'Add Payment Method';
  static const String recentPayments = 'Recent Payments';
  static const String paymentDetails = 'Payment Details';
  static const String amount = 'Amount';
  static const String paymentDate = 'Payment Date';
  static const String transactionId = 'Transaction ID';
  static const String paymentStatus = 'Payment Status';
  static const String completed = 'Completed';
  static const String failed = 'Failed';

  // Invoice Strings
  static const String invoices = 'Invoices';
  static const String invoiceDetails = 'Invoice Details';
  static const String invoiceNumber = 'Invoice Number';
  static const String dueDate = 'Due Date';
  static const String downloadInvoice = 'Download Invoice';

  // Documents Strings
  static const String documents = 'Documents';
  static const String uploadDocument = 'Upload Document';
  static const String documentType = 'Document Type';
  static const String idCard = 'ID Card';
  static const String businessLicense = 'Business License';
  static const String taxCertificate = 'Tax Certificate';
  static const String other = 'Other';

  // Support Strings
  static const String support = 'Support';
  static const String faq = 'FAQ';
  static const String tickets = 'Tickets';
  static const String newTicket = 'New Ticket';
  static const String subject = 'Subject';
  static const String message = 'Message';
  static const String submit = 'Submit';
  static const String open = 'Open';
  static const String resolved = 'Resolved';

  // Profile Strings
  static const String profile = 'Profile';
  static const String editProfile = 'Edit Profile';
  static const String settings = 'Settings';
  static const String notifications = 'Notifications';
  static const String privacy = 'Privacy';
  static const String termsOfService = 'Terms of Service';
  static const String about = 'About';
  static const String version = 'Version';

  // Common Strings
  static const String loading = 'Loading...';
  static const String error = 'Error';
  static const String retry = 'Retry';
  static const String cancel = 'Cancel';
  static const String save = 'Save';
  static const String delete = 'Delete';
  static const String edit = 'Edit';
  static const String close = 'Close';
  static const String confirm = 'Confirm';
  static const String yes = 'Yes';
  static const String no = 'No';
  static const String ok = 'OK';
  static const String back = 'Back';
  static const String done = 'Done';
  static const String noData = 'No data available';
  static const String somethingWentWrong = 'Something went wrong';
  static const String networkError = 'Network error. Please check your connection.';
  static const String currency = 'TZS';
}
