import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors
  static const Color primary = Color(0xFF2563EB); // Royal Blue
  static const Color accent = Color(0xFFF5C842); // Golden Yellow

  // Background
  static const Color background = Color(0xFFF9FAFB);
  static const Color surface = Color(0xFFFFFFFF);

  // Status Colors
  static const Color success = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color error = Color(0xFFEF4444);
  static const Color info = Color(0xFF3B82F6);

  // Text Colors
  static const Color textPrimary = Color(0xFF111827);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textTertiary = Color(0xFF9CA3AF);
  static const Color textOnPrimary = Color(0xFFFFFFFF);

  // Border & Divider
  static const Color border = Color(0xFFE5E7EB);
  static const Color divider = Color(0xFFE5E7EB);

  // Shipment Status Colors
  static const Color shipmentPending = Color(0xFFFBBF24);
  static const Color shipmentInTransit = Color(0xFF3B82F6);
  static const Color shipmentDelivered = Color(0xFF10B981);
  static const Color shipmentCancelled = Color(0xFFEF4444);

  // Booking Status Colors
  static const Color bookingConfirmed = Color(0xFF10B981);
  static const Color bookingPending = Color(0xFFFBBF24);

  // Gradient
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primary, Color(0xFF1E40AF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
