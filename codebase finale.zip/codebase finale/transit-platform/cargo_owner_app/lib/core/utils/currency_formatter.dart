import 'package:intl/intl.dart';
import '../constants/app_strings.dart';

class CurrencyFormatter {
  static final NumberFormat _formatter = NumberFormat.currency(
    symbol: '${AppStrings.currency} ',
    decimalDigits: 0,
  );

  static String format(double amount) {
    return _formatter.format(amount);
  }

  static String formatWithDecimals(double amount) {
    final formatter = NumberFormat.currency(
      symbol: '${AppStrings.currency} ',
      decimalDigits: 2,
    );
    return formatter.format(amount);
  }
}
