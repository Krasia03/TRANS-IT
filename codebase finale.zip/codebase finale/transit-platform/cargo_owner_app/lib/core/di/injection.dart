import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get_it/get_it.dart';

import '../network/api_client.dart';
import '../../features/auth/data/repositories/auth_repository.dart';
import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/shipments/presentation/bloc/shipment_bloc.dart';
import '../../features/booking/presentation/bloc/booking_bloc.dart';

final getIt = GetIt.instance;

Future<void> setupDependencies() async {
  // External
  getIt.registerLazySingleton(() => const FlutterSecureStorage());

  // Core
  getIt.registerLazySingleton(() => ApiClient(getIt()));

  // Repositories
  getIt.registerLazySingleton(() => AuthRepository(getIt(), getIt()));

  // BLoCs
  getIt.registerFactory(() => AuthBloc(getIt()));
  getIt.registerFactory(() => ShipmentBloc());
  getIt.registerFactory(() => BookingBloc());
}
