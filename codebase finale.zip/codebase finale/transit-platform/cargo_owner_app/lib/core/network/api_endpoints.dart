class ApiEndpoints {
  ApiEndpoints._();

  // Base
  static const String baseUrl = 'https://api.transit.co.tz/api/v1';
  static const String wsUrl = 'wss://api.transit.co.tz/ws';

  // Auth
  static const String login = '/auth/login';
  static const String register = '/auth/register';
  static const String logout = '/auth/logout';
  static const String me = '/auth/me';
  static const String refreshToken = '/auth/refresh';

  // Cargo Requests
  static const String cargoRequests = '/cargo-requests';
  static const String cargoRequestById = '/cargo-requests/{id}';
  static const String cargoRequestTracking = '/cargo-requests/{id}/tracking';
  static const String cargoRequestDocuments = '/cargo-requests/{id}/documents';

  // Vehicles
  static const String vehicles = '/vehicles';
  static const String vehicleById = '/vehicles/{id}';
  static const String vehicleMaintenance = '/vehicles/{id}/maintenance';
  static const String vehicleInspections = '/vehicles/{id}/inspections';

  // Drivers
  static const String drivers = '/drivers';
  static const String driverById = '/drivers/{id}';
  static const String driverPerformance = '/drivers/{id}/performance';
  static const String driverPayroll = '/drivers/{id}/payroll';

  // Payments
  static const String escrow = '/escrow';
  static const String escrowById = '/escrow/{id}';
  static const String escrowRelease = '/escrow/{id}/release';
  static const String invoices = '/invoices';
  static const String invoiceById = '/invoices/{id}';
  static const String payments = '/payments';
  static const String paymentById = '/payments/{id}';

  // Command Center
  static const String liveFleet = '/command-center/live-fleet';
  static const String h3DemandMap = '/command-center/h3-demand-map';
  static const String alerts = '/command-center/alerts';

  // Support
  static const String supportTickets = '/support-tickets';
  static const String supportTicketById = '/support-tickets/{id}';
  static const String faq = '/faq';

  // User Profile
  static const String userProfile = '/profile';
  static const String updateProfile = '/profile';
  static const String changePassword = '/profile/password';
  static const String uploadDocument = '/documents';

  static String getCargoRequestTracking(String id) =>
      cargoRequestTracking.replaceAll('{id}', id);

  static String getCargoRequestDocuments(String id) =>
      cargoRequestDocuments.replaceAll('{id}', id);

  static String getVehicleById(String id) =>
      vehicleById.replaceAll('{id}', id);

  static String getDriverById(String id) =>
      driverById.replaceAll('{id}', id);
}
