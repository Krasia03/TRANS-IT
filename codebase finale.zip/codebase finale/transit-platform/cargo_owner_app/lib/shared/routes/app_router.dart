import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/dashboard/presentation/pages/dashboard_page.dart';
import '../../features/booking/presentation/pages/new_booking_page.dart';
import '../../features/booking/presentation/pages/booking_confirm_page.dart';
import '../../features/shipments/presentation/pages/shipments_list_page.dart';
import '../../features/shipments/presentation/pages/shipment_details_page.dart';
import '../../features/shipments/presentation/pages/live_tracking_page.dart';
import '../../features/payments/presentation/pages/payments_page.dart';
import '../../features/invoices/presentation/pages/invoices_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';

class AppRouter {
  final AuthBloc authBloc;
  late final GoRouter router;

  AppRouter(this.authBloc) {
    router = GoRouter(
      initialLocation: '/login',
      redirect: (context, state) {
        final isAuthenticated = authBloc.state is AuthAuthenticated;
        final isLoggingIn = state.matchedLocation == '/login';

        if (!isAuthenticated && !isLoggingIn && state.matchedLocation != '/register') {
          return '/login';
        }

        if (isAuthenticated && (isLoggingIn || state.matchedLocation == '/register')) {
          return '/dashboard';
        }

        return null;
      },
      routes: [
        GoRoute(
          path: '/login',
          builder: (context, state) => const LoginPage(),
        ),
        GoRoute(
          path: '/register',
          builder: (context, state) => const RegisterPage(),
        ),
        GoRoute(
          path: '/dashboard',
          builder: (context, state) => const DashboardPage(),
        ),
        GoRoute(
          path: '/new-booking',
          builder: (context, state) => const NewBookingPage(),
        ),
        GoRoute(
          path: '/booking-confirm/:id',
          builder: (context, state) {
            final id = state.pathParameters['id']!;
            return BookingConfirmPage(bookingId: id);
          },
        ),
        GoRoute(
          path: '/shipments',
          builder: (context, state) => const ShipmentsListPage(),
        ),
        GoRoute(
          path: '/shipment-details/:id',
          builder: (context, state) {
            final id = state.pathParameters['id']!;
            return ShipmentDetailsPage(shipmentId: id);
          },
        ),
        GoRoute(
          path: '/live-tracking/:id',
          builder: (context, state) {
            final id = state.pathParameters['id']!;
            return LiveTrackingPage(shipmentId: id);
          },
        ),
        GoRoute(
          path: '/payments',
          builder: (context, state) => const PaymentsPage(),
        ),
        GoRoute(
          path: '/invoices',
          builder: (context, state) => const InvoicesPage(),
        ),
        GoRoute(
          path: '/profile',
          builder: (context, state) => const ProfilePage(),
        ),
      ],
    );
  }

  void dispose() {
    // Clean up if needed
  }
}
