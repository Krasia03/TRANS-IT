# TRANS-IT Cargo Owner App

A Flutter mobile application for cargo owners/shippers in the TRANS-IT fleet/logistics management platform.

## Features

- **Authentication**: Login and registration with account type selection (Individual/Business)
- **Dashboard**: Overview of active shipments, bookings, and quick booking access
- **Booking Management**: Multi-step booking flow (Location, Schedule, Cargo)
- **Shipment Tracking**: Real-time shipment tracking with live map
- **Payment History**: View payments and transaction history
- **Invoices**: Download and share invoices
- **Profile Management**: User info, settings, and account management

## Design System

- **Primary Color**: Royal Blue (#2563EB)
- **Accent Color**: Golden Yellow (#F5C842)
- **Background**: #F9FAFB
- **Currency**: TZS (Tanzanian Shilling)

## Tech Stack

- **Framework**: Flutter 3.0+
- **State Management**: BLoC (flutter_bloc)
- **Navigation**: GoRouter
- **HTTP Client**: Dio
- **Local Storage**: Hive + Flutter Secure Storage
- **Maps**: Google Maps Flutter
- **Dependency Injection**: GetIt

## Project Structure

```
lib/
├── core/                    # Core utilities and configuration
│   ├── constants/          # App colors, strings
│   ├── di/                 # Dependency injection
│   ├── network/            # API client, endpoints
│   ├── theme/              # App theme
│   └── utils/              # Formatters
├── features/               # Feature modules
│   ├── auth/              # Authentication
│   ├── booking/           # New booking flow
│   ├── dashboard/         # Dashboard
│   ├── invoices/          # Invoice management
│   ├── payments/          # Payment history
│   ├── profile/           # Profile management
│   └── shipments/         # Shipment tracking
└── shared/                # Shared widgets and routing
    ├── routes/            # App routing
    └── widgets/          # Reusable components
```

## Getting Started

### Prerequisites

- Flutter SDK 3.0 or higher
- Dart SDK 3.0 or higher
- Google Maps API Key

### Installation

1. Install dependencies
```bash
flutter pub get
```

2. Generate code
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

3. Configure Google Maps API Key in Android/iOS configs

4. Run the app
```bash
flutter run
```

## Build

### Android APK
```bash
flutter build apk --release
```

### iOS IPA
```bash
flutter build ios --release
```

## License

Copyright © 2024 TRANS-IT Platform. All rights reserved.
