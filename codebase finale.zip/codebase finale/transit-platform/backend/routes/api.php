<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\RoleController;
use App\Http\Controllers\Api\VehicleController;
use App\Http\Controllers\Api\DriverController;
use App\Http\Controllers\Api\CargoController;
use App\Http\Controllers\Api\ClientController;
use App\Http\Controllers\Api\RouteController as RouteManagementController;
use App\Http\Controllers\Api\DispatchController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\EscrowController;
use App\Http\Controllers\Api\InvoiceController;
use App\Http\Controllers\Api\WarehouseController;
use App\Http\Controllers\Api\AlertController;
use App\Http\Controllers\Api\SupportTicketController;
use App\Http\Controllers\Api\CommandCenterController;
use App\Http\Controllers\Api\AnalyticsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Public Routes
Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
});

// Protected Routes
Route::middleware('auth:sanctum')->group(function () {
    
    // Auth
    Route::prefix('auth')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);
        Route::post('/refresh', [AuthController::class, 'refresh']);
    });

    // Users
    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, 'index']);
        Route::post('/', [UserController::class, 'store']);
        Route::get('/{user}', [UserController::class, 'show']);
        Route::put('/{user}', [UserController::class, 'update']);
        Route::delete('/{user}', [UserController::class, 'destroy']);
        Route::post('/{user}/roles', [UserController::class, 'assignRole']);
    });

    // Roles & Permissions
    Route::prefix('roles')->group(function () {
        Route::get('/', [RoleController::class, 'index']);
        Route::post('/', [RoleController::class, 'store']);
        Route::get('/permissions', [RoleController::class, 'permissions']);
        Route::get('/{role}', [RoleController::class, 'show']);
        Route::put('/{role}', [RoleController::class, 'update']);
        Route::delete('/{role}', [RoleController::class, 'destroy']);
    });

    // Vehicles
    Route::prefix('vehicles')->group(function () {
        Route::get('/', [VehicleController::class, 'index']);
        Route::post('/', [VehicleController::class, 'store']);
        Route::get('/{vehicle}', [VehicleController::class, 'show']);
        Route::put('/{vehicle}', [VehicleController::class, 'update']);
        Route::delete('/{vehicle}', [VehicleController::class, 'destroy']);
        Route::post('/{vehicle}/location', [VehicleController::class, 'updateLocation']);
        Route::get('/{vehicle}/location-history', [VehicleController::class, 'locationHistory']);
    });

    // Drivers
    Route::prefix('drivers')->group(function () {
        Route::get('/', [DriverController::class, 'index']);
        Route::post('/', [DriverController::class, 'store']);
        Route::get('/{driver}', [DriverController::class, 'show']);
        Route::put('/{driver}', [DriverController::class, 'update']);
        Route::delete('/{driver}', [DriverController::class, 'destroy']);
        Route::get('/{driver}/performance', [DriverController::class, 'performance']);
        Route::post('/{driver}/payroll', [DriverController::class, 'processPayroll']);
    });

    // Cargo
    Route::prefix('cargo')->group(function () {
        Route::get('/', [CargoController::class, 'index']);
        Route::post('/', [CargoController::class, 'store']);
        Route::get('/{cargoRequest}', [CargoController::class, 'show']);
        Route::put('/{cargoRequest}', [CargoController::class, 'update']);
        Route::post('/{cargoRequest}/assign', [CargoController::class, 'assign']);
        Route::post('/{cargoRequest}/status', [CargoController::class, 'updateStatus']);
        Route::get('/{cargoRequest}/track', [CargoController::class, 'track']);
    });

    // Clients
    Route::prefix('clients')->group(function () {
        Route::get('/', [ClientController::class, 'index']);
        Route::post('/', [ClientController::class, 'store']);
        Route::get('/{client}', [ClientController::class, 'show']);
        Route::put('/{client}', [ClientController::class, 'update']);
        Route::delete('/{client}', [ClientController::class, 'destroy']);
    });

    // Routes
    Route::prefix('routes')->group(function () {
        Route::get('/', [RouteManagementController::class, 'index']);
        Route::post('/', [RouteManagementController::class, 'store']);
        Route::get('/{route}', [RouteManagementController::class, 'show']);
        Route::put('/{route}', [RouteManagementController::class, 'update']);
        Route::delete('/{route}', [RouteManagementController::class, 'destroy']);
    });

    // Dispatches
    Route::prefix('dispatches')->group(function () {
        Route::get('/', [DispatchController::class, 'index']);
        Route::post('/', [DispatchController::class, 'store']);
        Route::get('/{dispatch}', [DispatchController::class, 'show']);
        Route::put('/{dispatch}', [DispatchController::class, 'update']);
        Route::post('/{dispatch}/start', [DispatchController::class, 'start']);
        Route::post('/{dispatch}/complete', [DispatchController::class, 'complete']);
    });

    // Payments
    Route::prefix('payments')->group(function () {
        Route::get('/', [PaymentController::class, 'index']);
        Route::get('/{payment}', [PaymentController::class, 'show']);
        Route::post('/initiate', [PaymentController::class, 'initiate']);
        Route::post('/{payment}/callback', [PaymentController::class, 'callback']);
    });

    // Escrow
    Route::prefix('escrows')->group(function () {
        Route::get('/', [EscrowController::class, 'index']);
        Route::post('/', [EscrowController::class, 'store']);
        Route::get('/{escrow}', [EscrowController::class, 'show']);
        Route::post('/{escrow}/hold', [EscrowController::class, 'hold']);
        Route::post('/{escrow}/release', [EscrowController::class, 'release']);
        Route::post('/{escrow}/refund', [EscrowController::class, 'refund']);
    });

    // Invoices
    Route::prefix('invoices')->group(function () {
        Route::get('/', [InvoiceController::class, 'index']);
        Route::post('/', [InvoiceController::class, 'store']);
        Route::get('/{invoice}', [InvoiceController::class, 'show']);
        Route::put('/{invoice}', [InvoiceController::class, 'update']);
        Route::post('/{invoice}/send', [InvoiceController::class, 'send']);
    });

    // Warehouses
    Route::prefix('warehouses')->group(function () {
        Route::get('/', [WarehouseController::class, 'index']);
        Route::post('/', [WarehouseController::class, 'store']);
        Route::get('/{warehouse}', [WarehouseController::class, 'show']);
        Route::put('/{warehouse}', [WarehouseController::class, 'update']);
        Route::delete('/{warehouse}', [WarehouseController::class, 'destroy']);
    });

    // Alerts
    Route::prefix('alerts')->group(function () {
        Route::get('/', [AlertController::class, 'index']);
        Route::post('/{alert}/acknowledge', [AlertController::class, 'acknowledge']);
        Route::post('/{alert}/resolve', [AlertController::class, 'resolve']);
        Route::get('/stats', [AlertController::class, 'stats']);
    });

    // Support Tickets
    Route::prefix('tickets')->group(function () {
        Route::get('/', [SupportTicketController::class, 'index']);
        Route::post('/', [SupportTicketController::class, 'store']);
        Route::get('/{supportTicket}', [SupportTicketController::class, 'show']);
        Route::post('/{supportTicket}/respond', [SupportTicketController::class, 'respond']);
        Route::post('/{supportTicket}/assign', [SupportTicketController::class, 'assign']);
        Route::post('/{supportTicket}/resolve', [SupportTicketController::class, 'resolve']);
    });

    // Command Center
    Route::prefix('command-center')->group(function () {
        Route::get('/dashboard', [CommandCenterController::class, 'dashboard']);
        Route::get('/fleet', [CommandCenterController::class, 'fleetOverview']);
        Route::get('/demand-map', [CommandCenterController::class, 'h3DemandMap']);
        Route::get('/metrics', [CommandCenterController::class, 'liveMetrics']);
    });

    // Analytics
    Route::prefix('analytics')->group(function () {
        Route::get('/revenue', [AnalyticsController::class, 'revenueInsights']);
        Route::get('/health', [AnalyticsController::class, 'systemHealth']);
        Route::post('/report', [AnalyticsController::class, 'customReport']);
    });
});
