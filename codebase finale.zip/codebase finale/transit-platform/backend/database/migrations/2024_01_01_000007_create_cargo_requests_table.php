<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cargo_requests', function (Blueprint $table) {
            $table->id();
            $table->string('request_number')->unique();
            $table->foreignId('client_id')->constrained()->onDelete('cascade');
            $table->enum('client_type', ['corporate', 'individual']);
            $table->foreignId('vehicle_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('driver_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('route_id')->nullable()->constrained()->onDelete('set null');
            $table->enum('cargo_type', ['general', 'fragile', 'hazardous', 'perishable', 'livestock', 'oversized']);
            $table->text('description');
            $table->decimal('weight', 10, 2)->comment('Kilograms');
            $table->decimal('volume', 10, 2)->nullable()->comment('Cubic meters');
            $table->text('pickup_location');
            $table->decimal('pickup_latitude', 10, 8)->nullable();
            $table->decimal('pickup_longitude', 11, 8)->nullable();
            $table->timestamp('pickup_date');
            $table->text('delivery_location');
            $table->decimal('delivery_latitude', 10, 8)->nullable();
            $table->decimal('delivery_longitude', 11, 8)->nullable();
            $table->timestamp('delivery_date')->nullable();
            $table->decimal('estimated_distance', 10, 2)->nullable()->comment('Kilometers');
            $table->unsignedInteger('estimated_duration')->nullable()->comment('Minutes');
            $table->decimal('actual_distance', 10, 2)->nullable();
            $table->unsignedInteger('actual_duration')->nullable();
            $table->enum('status', [
                'pending', 'confirmed', 'assigned', 'at_pickup', 'in_transit',
                'at_delivery', 'delivered', 'completed', 'cancelled', 'failed'
            ])->default('pending');
            $table->enum('priority', ['low', 'normal', 'high', 'urgent'])->default('normal');
            $table->json('special_requirements')->nullable();
            $table->decimal('price', 14, 2)->default(0);
            $table->string('currency', 3)->default('TZS');
            $table->foreignId('insurance_id')->nullable()->constrained()->onDelete('set null');
            $table->json('document_ids')->nullable();
            $table->string('tracking_number')->nullable();
            $table->string('proof_of_delivery')->nullable();
            $table->string('signature_url')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->text('cancellation_reason')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index('priority');
            $table->index('tracking_number');
            $table->index(['client_id', 'status']);
        });

        Schema::create('cargo_tracking', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cargo_request_id')->constrained()->onDelete('cascade');
            $table->string('status');
            $table->text('location')->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->text('description');
            $table->foreignId('recorded_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamp('recorded_at');
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['cargo_request_id', 'recorded_at']);
        });

        Schema::create('cargo_waypoints', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cargo_request_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->decimal('latitude', 10, 8);
            $table->decimal('longitude', 11, 8);
            $table->text('address')->nullable();
            $table->unsignedInteger('order');
            $table->enum('type', ['pickup', 'delivery', 'checkpoint'])->default('checkpoint');
            $table->timestamp('estimated_arrival')->nullable();
            $table->timestamp('actual_arrival')->nullable();
            $table->enum('status', ['pending', 'arrived', 'completed', 'skipped'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('cargo_request_id');
        });

        Schema::create('cargo_documents', function (Blueprint $table) {
            $table->primary(['cargo_request_id', 'document_id']);
            $table->foreignId('cargo_request_id')->constrained()->onDelete('cascade');
            $table->foreignId('document_id')->constrained()->onDelete('cascade');
        });

        Schema::create('cargo_insurances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cargo_request_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('client_id')->nullable()->constrained()->onDelete('set null');
            $table->string('policy_number')->unique();
            $table->string('insurer_name');
            $table->string('coverage_type');
            $table->decimal('coverage_amount', 14, 2);
            $table->decimal('premium', 12, 2);
            $table->string('currency', 3)->default('TZS');
            $table->date('start_date');
            $table->date('end_date');
            $table->enum('status', ['active', 'expired', 'cancelled', 'claimed'])->default('active');
            $table->string('claim_number')->nullable();
            $table->decimal('claim_amount', 14, 2)->nullable();
            $table->enum('claim_status', ['none', 'filed', 'under_review', 'approved', 'rejected'])->default('none');
            $table->string('beneficiary')->nullable();
            $table->text('terms')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cargo_insurances');
        Schema::dropIfExists('cargo_documents');
        Schema::dropIfExists('cargo_waypoints');
        Schema::dropIfExists('cargo_tracking');
        Schema::dropIfExists('cargo_requests');
    }
};
