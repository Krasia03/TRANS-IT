<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('routes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('set null');
            $table->string('route_number')->unique();
            $table->string('name');
            $table->text('origin');
            $table->decimal('origin_latitude', 10, 8)->nullable();
            $table->decimal('origin_longitude', 11, 8)->nullable();
            $table->text('destination');
            $table->decimal('destination_latitude', 10, 8)->nullable();
            $table->decimal('destination_longitude', 11, 8)->nullable();
            $table->json('waypoints')->nullable();
            $table->decimal('total_distance', 10, 2)->comment('Kilometers');
            $table->unsignedInteger('estimated_duration')->comment('Minutes');
            $table->enum('route_type', ['shortest', 'fastest', 'scenic', 'custom'])->default('fastest');
            $table->enum('status', ['draft', 'active', 'inactive', 'archived'])->default('draft');
            $table->timestamp('optimized_at')->nullable();
            $table->decimal('optimization_score', 5, 2)->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index('route_number');
        });

        Schema::create('route_waypoints', function (Blueprint $table) {
            $table->id();
            $table->foreignId('route_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->decimal('latitude', 10, 8);
            $table->decimal('longitude', 11, 8);
            $table->text('address')->nullable();
            $table->unsignedInteger('order');
            $table->enum('type', ['pickup', 'delivery', 'stop', 'checkpoint'])->default('stop');
            $table->timestamp('estimated_arrival')->nullable();
            $table->timestamp('actual_arrival')->nullable();
            $table->timestamp('estimated_departure')->nullable();
            $table->timestamp('actual_departure')->nullable();
            $table->unsignedInteger('duration_minutes')->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('route_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('route_waypoints');
        Schema::dropIfExists('routes');
    }
};
