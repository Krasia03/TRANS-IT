<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
            $table->string('registration_number')->unique();
            $table->string('vin')->unique()->nullable();
            $table->string('make');
            $table->string('model');
            $table->year('year');
            $table->enum('type', ['truck', 'van', 'pickup', 'trailer', 'bus', 'motorcycle']);
            $table->decimal('capacity', 10, 2)->comment('Capacity in kg');
            $table->enum('fuel_type', ['petrol', 'diesel', 'electric', 'hybrid', 'lpg']);
            $table->enum('status', ['active', 'inactive', 'maintenance', 'decommissioned'])->default('active');
            $table->json('current_location')->nullable();
            $table->timestamp('last_location_update')->nullable();
            $table->unsignedInteger('odometer_reading')->default(0);
            $table->decimal('fuel_level', 5, 2)->nullable()->comment('Percentage 0-100');
            $table->date('insurance_expiry')->nullable();
            $table->date('road_tax_expiry')->nullable();
            $table->date('inspection_due')->nullable();
            $table->string('image_url')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index('type');
            $table->index('registration_number');
        });

        Schema::create('vehicle_driver', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained()->onDelete('cascade');
            $table->foreignId('driver_id')->constrained()->onDelete('cascade');
            $table->boolean('is_primary')->default(false);
            $table->timestamp('assigned_at')->useCurrent();
            $table->timestamp('unassigned_at')->nullable();
            $table->timestamps();

            $table->unique(['vehicle_id', 'driver_id']);
        });

        Schema::create('vehicle_locations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained()->onDelete('cascade');
            $table->decimal('latitude', 10, 8);
            $table->decimal('longitude', 11, 8);
            $table->decimal('altitude', 6, 2)->nullable();
            $table->decimal('speed', 6, 2)->nullable()->comment('Speed in km/h');
            $table->unsignedInteger('heading')->nullable()->comment('Degrees 0-360');
            $table->decimal('accuracy', 6, 2)->nullable();
            $table->enum('location_type', ['gps', 'cell', 'manual'])->default('gps');
            $table->string('location_name')->nullable();
            $table->timestamp('recorded_at');
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['vehicle_id', 'recorded_at']);
            $table->index('recorded_at');
        });

        Schema::create('maintenance_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained()->onDelete('cascade');
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
            $table->enum('maintenance_type', ['preventive', 'corrective', 'inspection', 'recall']);
            $table->text('description');
            $table->date('scheduled_date');
            $table->date('completed_date')->nullable();
            $table->decimal('cost', 12, 2)->default(0);
            $table->string('currency', 3)->default('TZS');
            $table->string('vendor')->nullable();
            $table->string('vendor_phone')->nullable();
            $table->json('parts_replaced')->nullable();
            $table->unsignedInteger('odometer_reading')->nullable();
            $table->date('next_service_due')->nullable();
            $table->string('technician_name')->nullable();
            $table->enum('status', ['pending', 'in_progress', 'completed', 'cancelled'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index('maintenance_type');
        });

        Schema::create('fuel_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained()->onDelete('cascade');
            $table->foreignId('driver_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
            $table->timestamp('transaction_date');
            $table->enum('fuel_type', ['petrol', 'diesel', 'lpg', 'electric']);
            $table->decimal('quantity', 10, 3)->comment('Liters');
            $table->decimal('unit_price', 10, 2);
            $table->decimal('total_cost', 12, 2);
            $table->string('currency', 3)->default('TZS');
            $table->unsignedInteger('odometer_reading')->nullable();
            $table->string('station_name')->nullable();
            $table->string('station_location')->nullable();
            $table->enum('payment_method', ['cash', 'card', 'company_account', 'mpesa'])->default('cash');
            $table->string('invoice_number')->nullable();
            $table->enum('status', ['pending', 'completed', 'cancelled'])->default('completed');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['vehicle_id', 'transaction_date']);
            $table->index('transaction_date');
        });

        Schema::create('vehicle_inspections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained()->onDelete('cascade');
            $table->foreignId('driver_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('inspector_id')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamp('inspection_date');
            $table->enum('inspection_type', ['pre_trip', 'post_trip', 'periodic', 'accident']);
            $table->enum('overall_status', ['passed', 'failed', 'needs_attention']);
            $table->unsignedInteger('odometer_reading');
            $table->decimal('fuel_level', 5, 2)->nullable();
            $table->enum('tire_condition', ['excellent', 'good', 'fair', 'poor', 'critical'])->default('good');
            $table->enum('brake_status', ['excellent', 'good', 'fair', 'poor', 'critical'])->default('good');
            $table->enum('lights_status', ['excellent', 'good', 'fair', 'poor', 'critical'])->default('good');
            $table->enum('engine_status', ['excellent', 'good', 'fair', 'poor', 'critical'])->default('good');
            $table->enum('body_condition', ['excellent', 'good', 'fair', 'poor', 'critical'])->default('good');
            $table->enum('interior_condition', ['excellent', 'good', 'fair', 'poor', 'critical'])->default('good');
            $table->json('safety_equipment')->nullable();
            $table->json('findings')->nullable();
            $table->json('recommendations')->nullable();
            $table->date('next_inspection_due')->nullable();
            $table->enum('status', ['pending', 'completed'])->default('completed');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['vehicle_id', 'inspection_date']);
            $table->index('overall_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehicle_inspections');
        Schema::dropIfExists('fuel_transactions');
        Schema::dropIfExists('maintenance_records');
        Schema::dropIfExists('vehicle_locations');
        Schema::dropIfExists('vehicle_driver');
        Schema::dropIfExists('vehicles');
    }
};
