<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('dispatches', function (Blueprint $table) {
            $table->id();
            $table->string('dispatch_number')->unique();
            $table->foreignId('route_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('vehicle_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('driver_id')->nullable()->constrained()->onDelete('set null');
            $table->timestamp('scheduled_start');
            $table->timestamp('scheduled_end');
            $table->timestamp('actual_start')->nullable();
            $table->timestamp('actual_end')->nullable();
            $table->enum('status', ['pending', 'in_progress', 'completed', 'cancelled', 'delayed'])->default('pending');
            $table->decimal('fuel_assigned', 10, 2)->nullable()->comment('Liters');
            $table->decimal('distance_covered', 10, 2)->nullable()->comment('Kilometers');
            $table->unsignedInteger('cargo_count')->default(0);
            $table->unsignedInteger('deliveries_completed')->default(0);
            $table->unsignedInteger('deliveries_failed')->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index(['driver_id', 'status']);
            $table->index(['vehicle_id', 'status']);
        });

        Schema::create('dispatch_waypoints', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dispatch_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->decimal('latitude', 10, 8);
            $table->decimal('longitude', 11, 8);
            $table->text('address')->nullable();
            $table->unsignedInteger('order');
            $table->enum('type', ['pickup', 'delivery', 'stop'])->default('stop');
            $table->timestamp('scheduled_arrival')->nullable();
            $table->timestamp('actual_arrival')->nullable();
            $table->timestamp('scheduled_departure')->nullable();
            $table->timestamp('actual_departure')->nullable();
            $table->enum('status', ['pending', 'arrived', 'completed', 'skipped'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('dispatch_id');
        });

        Schema::create('route_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('driver_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('route_id')->nullable()->constrained()->onDelete('set null');
            $table->foreignId('dispatch_id')->nullable()->constrained()->onDelete('set null');
            $table->date('assignment_date');
            $table->time('start_time');
            $table->time('end_time');
            $table->enum('status', ['scheduled', 'in_progress', 'completed', 'cancelled'])->default('scheduled');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['vehicle_id', 'assignment_date']);
            $table->index(['driver_id', 'assignment_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('route_assignments');
        Schema::dropIfExists('dispatch_waypoints');
        Schema::dropIfExists('dispatches');
    }
};
