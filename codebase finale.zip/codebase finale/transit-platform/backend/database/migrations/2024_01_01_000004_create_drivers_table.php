<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
            $table->string('employee_id')->unique();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->string('phone')->unique();
            $table->date('date_of_birth')->nullable();
            $table->string('license_number')->unique();
            $table->enum('license_type', ['A', 'B', 'C', 'D', 'E', 'CM'])->comment('Tanzania license classes');
            $table->date('license_expiry');
            $table->text('address')->nullable();
            $table->string('emergency_contact_name')->nullable();
            $table->string('emergency_contact_phone')->nullable();
            $table->string('profile_photo')->nullable();
            $table->enum('status', ['active', 'inactive', 'on_leave', 'suspended', 'terminated'])->default('active');
            $table->date('hire_date');
            $table->date('termination_date')->nullable();
            $table->decimal('rating', 3, 2)->default(0);
            $table->unsignedInteger('total_ratings')->default(0);
            $table->unsignedInteger('total_deliveries')->default(0);
            $table->unsignedInteger('accidents_count')->default(0);
            $table->timestamps();

            $table->index('status');
            $table->index('employee_id');
        });

        Schema::create('driver_payrolls', function (Blueprint $table) {
            $table->id();
            $table->foreignId('driver_id')->constrained()->onDelete('cascade');
            $table->foreignId('processed_by')->nullable()->constrained('users')->onDelete('set null');
            $table->string('payroll_number')->unique();
            $table->date('period_start');
            $table->date('period_end');
            $table->decimal('base_salary', 12, 2)->default(0);
            $table->decimal('allowances', 12, 2)->default(0);
            $table->decimal('deductions', 12, 2)->default(0);
            $table->decimal('bonuses', 12, 2)->default(0);
            $table->decimal('gross_salary', 12, 2)->default(0);
            $table->decimal('net_salary', 12, 2)->default(0);
            $table->string('currency', 3)->default('TZS');
            $table->enum('status', ['pending', 'processed', 'paid', 'cancelled'])->default('pending');
            $table->timestamp('processed_at')->nullable();
            $table->string('bank_name')->nullable();
            $table->string('bank_account')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index(['driver_id', 'period_start']);
        });

        Schema::create('driver_performances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('driver_id')->constrained()->onDelete('cascade');
            $table->date('period_start');
            $table->date('period_end');
            $table->unsignedInteger('total_deliveries')->default(0);
            $table->unsignedInteger('successful_deliveries')->default(0);
            $table->unsignedInteger('failed_deliveries')->default(0);
            $table->unsignedInteger('on_time_deliveries')->default(0);
            $table->decimal('total_distance', 10, 2)->default(0);
            $table->unsignedInteger('average_delivery_time')->default(0)->comment('Minutes');
            $table->decimal('customer_rating', 3, 2)->default(0);
            $table->decimal('safety_score', 3, 2)->default(0);
            $table->decimal('fuel_efficiency', 8, 2)->default(0)->comment('km per liter');
            $table->unsignedInteger('incidents_count')->default(0);
            $table->decimal('revenue_generated', 14, 2)->default(0);
            $table->string('currency', 3)->default('TZS');
            $table->json('data')->nullable();
            $table->timestamps();

            $table->index(['driver_id', 'period_start']);
        });

        Schema::create('driver_trainings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('driver_id')->constrained()->onDelete('cascade');
            $table->enum('training_type', ['safety', 'technical', 'compliance', 'customer_service', 'other']);
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('provider');
            $table->date('start_date');
            $table->date('end_date');
            $table->unsignedInteger('duration_hours');
            $table->string('location')->nullable();
            $table->string('certification_number')->nullable();
            $table->date('certification_expiry')->nullable();
            $table->enum('status', ['scheduled', 'in_progress', 'completed', 'cancelled'])->default('scheduled');
            $table->decimal('score', 5, 2)->nullable();
            $table->boolean('passed')->default(false);
            $table->string('certificate_url')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->index('training_type');
        });

        Schema::create('driver_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('driver_id')->constrained()->onDelete('cascade');
            $table->date('date');
            $table->time('start_time');
            $table->time('end_time');
            $table->string('shift_type')->comment('morning, afternoon, night');
            $table->foreignId('vehicle_id')->nullable()->constrained()->onDelete('set null');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['driver_id', 'date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('driver_schedules');
        Schema::dropIfExists('driver_trainings');
        Schema::dropIfExists('driver_performances');
        Schema::dropIfExists('driver_payrolls');
        Schema::dropIfExists('drivers');
    }
};
