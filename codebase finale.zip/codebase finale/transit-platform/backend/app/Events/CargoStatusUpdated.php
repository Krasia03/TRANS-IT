<?php

namespace App\Events;

use App\Models\CargoRequest;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class CargoStatusUpdated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public CargoRequest $cargoRequest,
        public string $oldStatus,
        public string $newStatus
    ) {}
}
