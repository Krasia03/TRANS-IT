<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DriverPerformance extends Model
{
    use HasFactory;

    protected $fillable = [
        'driver_id',
        'period_start',
        'period_end',
        'total_deliveries',
        'successful_deliveries',
        'failed_deliveries',
        'on_time_deliveries',
        'total_distance',
        'average_delivery_time',
        'customer_rating',
        'safety_score',
        'fuel_efficiency',
        'incidents_count',
        'revenue_generated',
        'currency',
        'data',
    ];

    protected function casts(): array
    {
        return [
            'period_start' => 'date',
            'period_end' => 'date',
            'total_distance' => 'decimal:2',
            'average_delivery_time' => 'integer',
            'customer_rating' => 'decimal:2',
            'safety_score' => 'decimal:2',
            'fuel_efficiency' => 'decimal:2',
            'revenue_generated' => 'decimal:2',
            'data' => 'array',
        ];
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function getSuccessRateAttribute(): float
    {
        if ($this->total_deliveries == 0) return 0;
        return ($this->successful_deliveries / $this->total_deliveries) * 100;
    }

    public function getOnTimeRateAttribute(): float
    {
        if ($this->successful_deliveries == 0) return 0;
        return ($this->on_time_deliveries / $this->successful_deliveries) * 100;
    }
}
