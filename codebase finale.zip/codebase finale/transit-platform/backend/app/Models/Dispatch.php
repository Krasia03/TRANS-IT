<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Dispatch extends Model
{
    use HasFactory;

    protected $fillable = [
        'dispatch_number',
        'route_id',
        'vehicle_id',
        'driver_id',
        'scheduled_start',
        'scheduled_end',
        'actual_start',
        'actual_end',
        'status',
        'fuel_assigned',
        'distance_covered',
        'cargo_count',
        'deliveries_completed',
        'deliveries_failed',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'scheduled_start' => 'datetime',
            'scheduled_end' => 'datetime',
            'actual_start' => 'datetime',
            'actual_end' => 'datetime',
            'fuel_assigned' => 'decimal:2',
            'distance_covered' => 'decimal:2',
        ];
    }

    public function route(): BelongsTo
    {
        return $this->belongsTo(Route::class);
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function cargoRequests(): HasMany
    {
        return $this->hasMany(CargoRequest::class);
    }

    public function waypoints(): HasMany
    {
        return $this->hasMany(DispatchWaypoint::class);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeInProgress($query)
    {
        return $query->where('status', 'in_progress');
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    public function getDurationAttribute(): int
    {
        if (!$this->actual_start || !$this->actual_end) {
            return 0;
        }
        return $this->actual_start->diffInMinutes($this->actual_end);
    }
}
