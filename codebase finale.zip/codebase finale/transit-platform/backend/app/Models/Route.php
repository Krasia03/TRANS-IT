<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Route extends Model
{
    use HasFactory;

    protected $fillable = [
        'route_number',
        'name',
        'origin',
        'origin_latitude',
        'origin_longitude',
        'destination',
        'destination_latitude',
        'destination_longitude',
        'waypoints',
        'total_distance',
        'estimated_duration',
        'route_type',
        'status',
        'created_by',
        'optimized_at',
        'optimization_score',
    ];

    protected function casts(): array
    {
        return [
            'waypoints' => 'array',
            'total_distance' => 'decimal:2',
            'estimated_duration' => 'integer',
            'optimized_at' => 'datetime',
        ];
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function waypoints(): HasMany
    {
        return $this->hasMany(RouteWaypoint::class)->orderBy('order');
    }

    public function cargoRequests(): HasMany
    {
        return $this->hasMany(CargoRequest::class);
    }

    public function dispatches(): HasMany
    {
        return $this->hasMany(Dispatch::class);
    }

    public function routeAssignments(): HasMany
    {
        return $this->hasMany(RouteAssignment::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function getFormattedDistanceAttribute(): string
    {
        return number_format($this->total_distance, 2) . ' km';
    }

    public function getFormattedDurationAttribute(): string
    {
        $hours = floor($this->estimated_duration / 60);
        $minutes = $this->estimated_duration % 60;
        return "{$hours}h {$minutes}m";
    }
}
