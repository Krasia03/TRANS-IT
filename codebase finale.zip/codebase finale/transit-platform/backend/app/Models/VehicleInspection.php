<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VehicleInspection extends Model
{
    use HasFactory;

    protected $fillable = [
        'vehicle_id',
        'driver_id',
        'inspector_id',
        'inspection_date',
        'inspection_type',
        'overall_status',
        'odometer_reading',
        'fuel_level',
        'tire_condition',
        'brake_status',
        'lights_status',
        'engine_status',
        'body_condition',
        'interior_condition',
        'safety_equipment',
        'findings',
        'recommendations',
        'next_inspection_due',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'inspection_date' => 'datetime',
            'next_inspection_due' => 'date',
            'fuel_level' => 'decimal:2',
            'findings' => 'array',
            'recommendations' => 'array',
        ];
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function inspector(): BelongsTo
    {
        return $this->belongsTo(User::class, 'inspector_id');
    }

    public function scopePassed($query)
    {
        return $query->where('overall_status', 'passed');
    }

    public function scopeFailed($query)
    {
        return $query->where('overall_status', 'failed');
    }

    public function isPassed(): bool
    {
        return $this->overall_status === 'passed';
    }
}
