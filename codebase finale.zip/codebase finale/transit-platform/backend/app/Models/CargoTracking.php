<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CargoTracking extends Model
{
    use HasFactory;

    protected $fillable = [
        'cargo_request_id',
        'status',
        'location',
        'latitude',
        'longitude',
        'description',
        'recorded_by',
        'recorded_at',
        'metadata',
    ];

    protected function casts(): array
    {
        return [
            'latitude' => 'decimal:8',
            'longitude' => 'decimal:8',
            'recorded_at' => 'datetime',
            'metadata' => 'array',
        ];
    }

    public function cargoRequest(): BelongsTo
    {
        return $this->belongsTo(CargoRequest::class);
    }

    public function recorder(): BelongsTo
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }
}
