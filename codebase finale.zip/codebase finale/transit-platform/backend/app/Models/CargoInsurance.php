<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CargoInsurance extends Model
{
    use HasFactory;

    protected $fillable = [
        'policy_number',
        'cargo_request_id',
        'client_id',
        'insurer_name',
        'coverage_type',
        'coverage_amount',
        'premium',
        'currency',
        'start_date',
        'end_date',
        'status',
        'claim_number',
        'claim_amount',
        'claim_status',
        'beneficiary',
        'terms',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'coverage_amount' => 'decimal:2',
            'premium' => 'decimal:2',
            'claim_amount' => 'decimal:2',
            'start_date' => 'date',
            'end_date' => 'date',
        ];
    }

    public function cargoRequest(): BelongsTo
    {
        return $this->belongsTo(CargoRequest::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active')
            ->where('end_date', '>=', now());
    }

    public function scopeExpired($query)
    {
        return $query->where('end_date', '<', now());
    }

    public function getIsActiveAttribute(): bool
    {
        return $this->status === 'active' && $this->end_date->isFuture();
    }
}
