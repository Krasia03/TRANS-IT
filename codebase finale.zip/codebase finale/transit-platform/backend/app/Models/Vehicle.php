<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Vehicle extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'registration_number',
        'vin',
        'make',
        'model',
        'year',
        'type',
        'capacity',
        'fuel_type',
        'status',
        'current_location',
        'last_location_update',
        'odometer_reading',
        'fuel_level',
        'insurance_expiry',
        'road_tax_expiry',
        'inspection_due',
        'image_url',
    ];

    protected function casts(): array
    {
        return [
            'last_location_update' => 'datetime',
            'insurance_expiry' => 'date',
            'road_tax_expiry' => 'date',
            'inspection_due' => 'date',
            'current_location' => 'array',
        ];
    }

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function drivers(): BelongsToMany(Driver::class, 'vehicle_driver')
        ->withPivot(['assigned_at', 'unassigned_at', 'is_primary'])
        ->withTimestamps();
    }

    public function primaryDriver(): BelongsTo
    {
        return $this->belongsTo(Driver::class, 'primary_driver_id');
    }

    public function maintenanceRecords(): HasMany
    {
        return $this->hasMany(MaintenanceRecord::class);
    }

    public function fuelTransactions(): HasMany
    {
        return $this->hasMany(FuelTransaction::class);
    }

    public function inspections(): HasMany
    {
        return $this->hasMany(VehicleInspection::class);
    }

    public function cargoRequests(): HasMany
    {
        return $this->hasMany(CargoRequest::class);
    }

    public function routeAssignments(): HasMany
    {
        return $this->hasMany(RouteAssignment::class);
    }

    public function locationHistory(): HasMany
    {
        return $this->hasMany(VehicleLocation::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeAvailable($query)
    {
        return $query->where('status', 'active')
            ->whereNull('current_dispatch_id');
    }
}
