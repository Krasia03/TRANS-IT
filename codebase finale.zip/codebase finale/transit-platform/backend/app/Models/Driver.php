<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Driver extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'employee_id',
        'first_name',
        'last_name',
        'email',
        'phone',
        'date_of_birth',
        'license_number',
        'license_type',
        'license_expiry',
        'address',
        'emergency_contact_name',
        'emergency_contact_phone',
        'profile_photo',
        'status',
        'hire_date',
        'termination_date',
        'rating',
        'total_ratings',
        'total_deliveries',
        'accidents_count',
    ];

    protected function casts(): array
    {
        return [
            'date_of_birth' => 'date',
            'license_expiry' => 'date',
            'hire_date' => 'date',
            'termination_date' => 'date',
            'rating' => 'decimal:2',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function vehicles(): BelongsToMany(Vehicle::class, 'vehicle_driver')
        ->withPivot(['assigned_at', 'unassigned_at', 'is_primary'])
        ->withTimestamps();
    }

    public function primaryVehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class, 'primary_vehicle_id');
    }

    public function payrolls(): HasMany
    {
        return $this->hasMany(DriverPayroll::class);
    }

    public function trainingRecords(): HasMany
    {
        return $this->hasMany(DriverTraining::class);
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(DriverSchedule::class);
    }

    public function performanceMetrics(): HasMany
    {
        return $this->hasMany(DriverPerformance::class);
    }

    public function inspections(): HasMany
    {
        return $this->hasMany(VehicleInspection::class);
    }

    public function routeAssignments(): HasMany
    {
        return $this->hasMany(RouteAssignment::class);
    }

    public function cargoRequests(): HasMany
    {
        return $this->hasMany(CargoRequest::class);
    }

    public function supportTickets(): HasMany
    {
        return $this->hasMany(SupportTicket::class);
    }

    public function getFullNameAttribute(): string
    {
        return "{$this->first_name} {$this->last_name}";
    }

    public function isLicenseValid(): bool
    {
        return $this->license_expiry && $this->license_expiry->isFuture();
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }
}
