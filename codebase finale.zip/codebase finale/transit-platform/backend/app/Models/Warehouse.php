<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Warehouse extends Model
{
    use HasFactory;

    protected $fillable = [
        'warehouse_code',
        'name',
        'description',
        'address',
        'city',
        'region',
        'country',
        'latitude',
        'longitude',
        'capacity',
        'current_utilization',
        'manager_id',
        'status',
        'operating_hours',
        'contact_phone',
        'contact_email',
    ];

    protected function casts(): array
    {
        return [
            'capacity' => 'decimal:2',
            'current_utilization' => 'decimal:2',
            'latitude' => 'decimal:8',
            'longitude' => 'decimal:8',
            'operating_hours' => 'array',
        ];
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    public function staff(): HasMany
    {
        return $this->hasMany(WarehouseStaff::class);
    }

    public function inventory(): HasMany
    {
        return $this->hasMany(Inventory::class);
    }

    public function inventoryTransactions(): HasMany
    {
        return $this->hasMany(InventoryTransaction::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function getUtilizationPercentageAttribute(): float
    {
        if ($this->capacity == 0) return 0;
        return ($this->current_utilization / $this->capacity) * 100;
    }

    public function getAvailableCapacityAttribute(): float
    {
        return $this->capacity - $this->current_utilization;
    }
}
