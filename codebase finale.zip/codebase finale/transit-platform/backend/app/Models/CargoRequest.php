<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class CargoRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'request_number',
        'client_id',
        'client_type',
        'vehicle_id',
        'driver_id',
        'route_id',
        'cargo_type',
        'description',
        'weight',
        'volume',
        'pickup_location',
        'pickup_latitude',
        'pickup_longitude',
        'pickup_date',
        'delivery_location',
        'delivery_latitude',
        'delivery_longitude',
        'delivery_date',
        'estimated_distance',
        'estimated_duration',
        'actual_distance',
        'actual_duration',
        'status',
        'priority',
        'special_requirements',
        'price',
        'currency',
        'insurance_id',
        'document_ids',
        'tracking_number',
        'proof_of_delivery',
        'signature_url',
        'completed_at',
        'cancelled_at',
        'cancellation_reason',
    ];

    protected function casts(): array
    {
        return [
            'pickup_date' => 'datetime',
            'delivery_date' => 'datetime',
            'completed_at' => 'datetime',
            'cancelled_at' => 'datetime',
            'pickup_location' => 'array',
            'delivery_location' => 'array',
            'special_requirements' => 'array',
            'document_ids' => 'array',
            'weight' => 'decimal:2',
            'volume' => 'decimal:2',
            'price' => 'decimal:2',
        ];
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function route(): BelongsTo
    {
        return $this->belongsTo(Route::class);
    }

    public function insurance(): BelongsTo
    {
        return $this->belongsTo(CargoInsurance::class);
    }

    public function documents(): BelongsToMany(Document::class, 'cargo_documents')
        ->withTimestamps();
    }

    public function trackingUpdates(): HasMany
    {
        return $this->hasMany(CargoTracking::class)->orderBy('created_at', 'desc');
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function escrow(): HasMany
    {
        return $this->hasMany(Escrow::class);
    }

    public function waypoints(): HasMany
    {
        return $this->hasMany(CargoWaypoint::class);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeInTransit($query)
    {
        return $query->where('status', 'in_transit');
    }

    public function scopeDelivered($query)
    {
        return $query->where('status', 'delivered');
    }

    public function getFormattedPriceAttribute(): string
    {
        return number_format($this->price, 2) . ' ' . $this->currency;
    }
}
