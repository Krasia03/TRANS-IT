<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FuelTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'vehicle_id',
        'driver_id',
        'transaction_date',
        'fuel_type',
        'quantity',
        'unit_price',
        'total_cost',
        'currency',
        'odometer_reading',
        'station_name',
        'station_location',
        'payment_method',
        'invoice_number',
        'status',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'transaction_date' => 'datetime',
            'quantity' => 'decimal:2',
            'unit_price' => 'decimal:2',
            'total_cost' => 'decimal:2',
            'odometer_reading' => 'integer',
        ];
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function scopeRecent($query, $days = 30)
    {
        return $query->where('transaction_date', '>=', now()->subDays($days));
    }

    public function getFormattedCostAttribute(): string
    {
        return number_format($this->total_cost, 2) . ' ' . $this->currency;
    }

    public function getFormattedQuantityAttribute(): string
    {
        return number_format($this->quantity, 2) . ' L';
    }
}
