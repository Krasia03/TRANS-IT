<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Alert extends Model
{
    use HasFactory;

    protected $fillable = [
        'alert_number',
        'type',
        'severity',
        'title',
        'message',
        'vehicle_id',
        'driver_id',
        'user_id',
        'related_entity_type',
        'related_entity_id',
        'latitude',
        'longitude',
        'location_name',
        'acknowledged_at',
        'acknowledged_by',
        'resolved_at',
        'resolved_by',
        'metadata',
    ];

    protected function casts(): array
    {
        return [
            'acknowledged_at' => 'datetime',
            'resolved_at' => 'datetime',
            'latitude' => 'decimal:8',
            'longitude' => 'decimal:8',
            'metadata' => 'array',
        ];
    }

    public const TYPE_SPEED = 'speed';
    public const TYPE_GEOFENCE = 'geofence';
    public const TYPE_MAINTENANCE = 'maintenance';
    public const TYPE_FUEL = 'fuel';
    public const TYPE_IDLE = 'idle';
    public const TYPE_ACCIDENT = 'accident';
    public const TYPE_EMERGENCY = 'emergency';

    public const SEVERITY_LOW = 'low';
    public const SEVERITY_MEDIUM = 'medium';
    public const SEVERITY_HIGH = 'high';
    public const SEVERITY_CRITICAL = 'critical';

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function acknowledger(): BelongsTo
    {
        return $this->belongsTo(User::class, 'acknowledged_by');
    }

    public function resolver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }

    public function scopeUnacknowledged($query)
    {
        return $query->whereNull('acknowledged_at');
    }

    public function scopeUnresolved($query)
    {
        return $query->whereNull('resolved_at');
    }

    public function scopeCritical($query)
    {
        return $query->where('severity', self::SEVERITY_CRITICAL);
    }

    public function isAcknowledged(): bool
    {
        return $this->acknowledged_at !== null;
    }

    public function isResolved(): bool
    {
        return $this->resolved_at !== null;
    }
}
