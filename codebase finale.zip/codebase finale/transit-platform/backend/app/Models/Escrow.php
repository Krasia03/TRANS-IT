<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Escrow extends Model
{
    use HasFactory;

    protected $fillable = [
        'escrow_number',
        'cargo_request_id',
        'client_id',
        'amount',
        'currency',
        'status',
        'held_at',
        'released_at',
        'released_to',
        'refunded_at',
        'refund_reason',
        'payment_reference',
        'release_reference',
        'metadata',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'held_at' => 'datetime',
            'released_at' => 'datetime',
            'refunded_at' => 'datetime',
            'metadata' => 'array',
        ];
    }

    public function cargoRequest(): BelongsTo
    {
        return $this->belongsTo(CargoRequest::class);
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function heldBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'held_by');
    }

    public function releasedToUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'released_to');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeHeld($query)
    {
        return $query->where('status', 'held');
    }

    public function scopeReleased($query)
    {
        return $query->where('status', 'released');
    }

    public function scopeRefunded($query)
    {
        return $query->where('status', 'refunded');
    }

    public function getFormattedAmountAttribute(): string
    {
        return number_format($this->amount, 2) . ' ' . $this->currency;
    }

    public function isReleasable(): bool
    {
        return $this->status === 'held';
    }
}
