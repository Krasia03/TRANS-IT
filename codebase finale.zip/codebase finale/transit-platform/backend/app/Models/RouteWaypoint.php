<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RouteWaypoint extends Model
{
    use HasFactory;

    protected $fillable = [
        'route_id',
        'name',
        'latitude',
        'longitude',
        'address',
        'order',
        'type',
        'estimated_arrival',
        'actual_arrival',
        'estimated_departure',
        'actual_departure',
        'duration_minutes',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'latitude' => 'decimal:8',
            'longitude' => 'decimal:8',
            'estimated_arrival' => 'datetime',
            'actual_arrival' => 'datetime',
            'estimated_departure' => 'datetime',
            'actual_departure' => 'datetime',
            'duration_minutes' => 'integer',
        ];
    }

    public function route(): BelongsTo
    {
        return $this->belongsTo(Route::class);
    }
}
