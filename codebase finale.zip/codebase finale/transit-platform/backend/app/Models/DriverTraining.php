<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DriverTraining extends Model
{
    use HasFactory;

    protected $fillable = [
        'driver_id',
        'training_type',
        'title',
        'description',
        'provider',
        'start_date',
        'end_date',
        'duration_hours',
        'location',
        'certification_number',
        'certification_expiry',
        'status',
        'score',
        'passed',
        'certificate_url',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'start_date' => 'date',
            'end_date' => 'date',
            'certification_expiry' => 'date',
            'duration_hours' => 'integer',
            'score' => 'decimal:2',
        ];
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    public function scopeValid($query)
    {
        return $query->where('passed', true)
            ->where(function ($q) {
                $q->whereNull('certification_expiry')
                    ->orWhere('certification_expiry', '>=', now());
            });
    }

    public function isValid(): bool
    {
        return $this->passed && ($this->certification_expiry === null || $this->certification_expiry->isFuture());
    }
}
