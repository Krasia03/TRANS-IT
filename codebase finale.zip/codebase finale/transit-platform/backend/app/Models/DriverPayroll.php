<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DriverPayroll extends Model
{
    use HasFactory;

    protected $fillable = [
        'payroll_number',
        'driver_id',
        'period_start',
        'period_end',
        'base_salary',
        'allowances',
        'deductions',
        'bonuses',
        'gross_salary',
        'net_salary',
        'currency',
        'status',
        'processed_at',
        'processed_by',
        'bank_name',
        'bank_account',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'period_start' => 'date',
            'period_end' => 'date',
            'processed_at' => 'datetime',
            'base_salary' => 'decimal:2',
            'allowances' => 'decimal:2',
            'deductions' => 'decimal:2',
            'bonuses' => 'decimal:2',
            'gross_salary' => 'decimal:2',
            'net_salary' => 'decimal:2',
        ];
    }

    public function driver(): BelongsTo
    {
        return $this->belongsTo(Driver::class);
    }

    public function processor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'processed_by');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeProcessed($query)
    {
        return $query->where('status', 'processed');
    }

    public function getFormattedNetSalaryAttribute(): string
    {
        return number_format($this->net_salary, 2) . ' ' . $this->currency;
    }
}
