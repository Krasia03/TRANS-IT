<?php

namespace App\Listeners;

use App\Events\AlertCreated;
use App\Models\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendAlertNotification implements ShouldQueue
{
    public function handle(AlertCreated $event): void
    {
        $alert = $event->alert;

        $userIds = $alert->vehicle->owner_id 
            ? [$alert->vehicle->owner_id] 
            : [];

        foreach ($userIds as $userId) {
            Notification::create([
                'user_id' => $userId,
                'type' => 'alert',
                'title' => $alert->title,
                'message' => $alert->message,
                'data' => [
                    'alert_id' => $alert->id,
                    'alert_number' => $alert->alert_number,
                    'severity' => $alert->severity,
                    'type' => $alert->type,
                ],
                'action_url' => "/alerts/{$alert->id}",
                'action_label' => 'View Alert',
            ]);
        }
    }
}
