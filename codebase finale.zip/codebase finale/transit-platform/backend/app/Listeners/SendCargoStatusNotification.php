<?php

namespace App\Listeners;

use App\Events\CargoStatusUpdated;
use App\Models\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendCargoStatusNotification implements ShouldQueue
{
    public function handle(CargoStatusUpdated $event): void
    {
        $cargo = $event->cargoRequest;

        Notification::create([
            'user_id' => $cargo->client->user_id,
            'type' => 'cargo_status',
            'title' => 'Cargo Status Update',
            'message' => "Your cargo {$cargo->tracking_number} status changed to {$event->newStatus}",
            'data' => [
                'cargo_id' => $cargo->id,
                'tracking_number' => $cargo->tracking_number,
                'old_status' => $event->oldStatus,
                'new_status' => $event->newStatus,
            ],
            'action_url' => "/cargo/{$cargo->id}",
            'action_label' => 'View Details',
        ]);
    }
}
