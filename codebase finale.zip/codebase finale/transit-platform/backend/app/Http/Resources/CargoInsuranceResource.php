<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CargoInsuranceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'cargo_request_id' => $this->cargo_request_id,
            'client_id' => $this->client_id,
            'policy_number' => $this->policy_number,
            'insurer_name' => $this->insurer_name,
            'coverage_type' => $this->coverage_type,
            'coverage_amount' => $this->coverage_amount,
            'premium' => $this->premium,
            'currency' => $this->currency,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'status' => $this->status,
            'is_active' => $this->is_active,
            'claim_number' => $this->claim_number,
            'claim_amount' => $this->claim_amount,
            'claim_status' => $this->claim_status,
            'beneficiary' => $this->beneficiary,
            'terms' => $this->terms,
            'notes' => $this->notes,
            'cargo_request' => new CargoRequestResource($this->whenLoaded('cargoRequest')),
            'client' => new ClientResource($this->whenLoaded('client')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
