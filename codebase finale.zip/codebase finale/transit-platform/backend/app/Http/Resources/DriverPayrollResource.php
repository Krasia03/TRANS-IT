<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DriverPayrollResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'driver_id' => $this->driver_id,
            'payroll_number' => $this->payroll_number,
            'period_start' => $this->period_start,
            'period_end' => $this->period_end,
            'base_salary' => $this->base_salary,
            'allowances' => $this->allowances,
            'deductions' => $this->deductions,
            'bonuses' => $this->bonuses,
            'gross_salary' => $this->gross_salary,
            'net_salary' => $this->net_salary,
            'formatted_net_salary' => $this->formatted_net_salary,
            'currency' => $this->currency,
            'status' => $this->status,
            'processed_at' => $this->processed_at,
            'bank_name' => $this->bank_name,
            'bank_account' => $this->bank_account,
            'notes' => $this->notes,
            'driver' => new DriverResource($this->whenLoaded('driver')),
            'processor' => new UserResource($this->whenLoaded('processor')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
