<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CargoTrackingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'cargo_request_id' => $this->cargo_request_id,
            'status' => $this->status,
            'location' => $this->location,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'description' => $this->description,
            'recorded_by' => $this->recorded_by,
            'recorded_at' => $this->recorded_at,
            'recorder' => new UserResource($this->whenLoaded('recorder')),
            'created_at' => $this->created_at,
        ];
    }
}
