<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'invoice_number' => $this->invoice_number,
            'cargo_request_id' => $this->cargo_request_id,
            'client_id' => $this->client_id,
            'subtotal' => $this->subtotal,
            'tax_rate' => $this->tax_rate,
            'tax_amount' => $this->tax_amount,
            'total_amount' => $this->total_amount,
            'formatted_total' => $this->formatted_total,
            'currency' => $this->currency,
            'status' => $this->status,
            'is_overdue' => $this->isOverdue(),
            'issue_date' => $this->issue_date,
            'due_date' => $this->due_date,
            'paid_date' => $this->paid_date,
            'payment_method' => $this->payment_method,
            'payment_reference' => $this->payment_reference,
            'notes' => $this->notes,
            'terms' => $this->terms,
            'cargo_request' => new CargoRequestResource($this->whenLoaded('cargoRequest')),
            'client' => new ClientResource($this->whenLoaded('client')),
            'items' => InvoiceItemResource::collection($this->whenLoaded('items')),
            'payments' => PaymentResource::collection($this->whenLoaded('payments')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
