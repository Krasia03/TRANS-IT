<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RouteResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'route_number' => $this->route_number,
            'name' => $this->name,
            'origin' => $this->origin,
            'origin_latitude' => $this->origin_latitude,
            'origin_longitude' => $this->origin_longitude,
            'destination' => $this->destination,
            'destination_latitude' => $this->destination_latitude,
            'destination_longitude' => $this->destination_longitude,
            'waypoints' => $this->waypoints,
            'total_distance' => $this->total_distance,
            'formatted_distance' => $this->formatted_distance,
            'estimated_duration' => $this->estimated_duration,
            'formatted_duration' => $this->formatted_duration,
            'route_type' => $this->route_type,
            'status' => $this->status,
            'optimized_at' => $this->optimized_at,
            'optimization_score' => $this->optimization_score,
            'waypoints_detail' => RouteWaypointResource::collection($this->whenLoaded('waypoints')),
            'creator' => new UserResource($this->whenLoaded('creator')),
            'cargo_requests' => CargoRequestResource::collection($this->whenLoaded('cargoRequests')),
            'dispatches' => DispatchResource::collection($this->whenLoaded('dispatches')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
