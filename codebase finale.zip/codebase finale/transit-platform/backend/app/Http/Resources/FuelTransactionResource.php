<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FuelTransactionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'vehicle_id' => $this->vehicle_id,
            'driver_id' => $this->driver_id,
            'transaction_date' => $this->transaction_date,
            'fuel_type' => $this->fuel_type,
            'quantity' => $this->quantity,
            'formatted_quantity' => $this->formatted_quantity,
            'unit_price' => $this->unit_price,
            'total_cost' => $this->total_cost,
            'formatted_cost' => $this->formatted_cost,
            'currency' => $this->currency,
            'odometer_reading' => $this->odometer_reading,
            'station_name' => $this->station_name,
            'station_location' => $this->station_location,
            'payment_method' => $this->payment_method,
            'invoice_number' => $this->invoice_number,
            'status' => $this->status,
            'notes' => $this->notes,
            'vehicle' => new VehicleResource($this->whenLoaded('vehicle')),
            'driver' => new DriverResource($this->whenLoaded('driver')),
            'user' => new UserResource($this->whenLoaded('user')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
