<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VehicleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'registration_number' => $this->registration_number,
            'vin' => $this->vin,
            'make' => $this->make,
            'model' => $this->model,
            'year' => $this->year,
            'type' => $this->type,
            'capacity' => $this->capacity,
            'fuel_type' => $this->fuel_type,
            'status' => $this->status,
            'current_location' => $this->current_location,
            'last_location_update' => $this->last_location_update,
            'odometer_reading' => $this->odometer_reading,
            'fuel_level' => $this->fuel_level,
            'insurance_expiry' => $this->insurance_expiry,
            'road_tax_expiry' => $this->road_tax_expiry,
            'inspection_due' => $this->inspection_due,
            'image_url' => $this->image_url,
            'primary_driver' => new DriverResource($this->whenLoaded('primaryDriver')),
            'drivers' => DriverResource::collection($this->whenLoaded('drivers')),
            'maintenance_records' => MaintenanceRecordResource::collection($this->whenLoaded('maintenanceRecords')),
            'fuel_transactions' => FuelTransactionResource::collection($this->whenLoaded('fuelTransactions')),
            'inspections' => VehicleInspectionResource::collection($this->whenLoaded('inspections')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
