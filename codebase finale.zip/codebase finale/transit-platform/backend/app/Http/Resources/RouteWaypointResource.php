<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RouteWaypointResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'route_id' => $this->route_id,
            'name' => $this->name,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'address' => $this->address,
            'order' => $this->order,
            'type' => $this->type,
            'estimated_arrival' => $this->estimated_arrival,
            'actual_arrival' => $this->actual_arrival,
            'estimated_departure' => $this->estimated_departure,
            'actual_departure' => $this->actual_departure,
            'duration_minutes' => $this->duration_minutes,
            'notes' => $this->notes,
            'route' => new RouteResource($this->whenLoaded('route')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
