<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VehicleInspectionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'vehicle_id' => $this->vehicle_id,
            'driver_id' => $this->driver_id,
            'inspector_id' => $this->inspector_id,
            'inspection_date' => $this->inspection_date,
            'inspection_type' => $this->inspection_type,
            'overall_status' => $this->overall_status,
            'odometer_reading' => $this->odometer_reading,
            'fuel_level' => $this->fuel_level,
            'tire_condition' => $this->tire_condition,
            'brake_status' => $this->brake_status,
            'lights_status' => $this->lights_status,
            'engine_status' => $this->engine_status,
            'body_condition' => $this->body_condition,
            'interior_condition' => $this->interior_condition,
            'safety_equipment' => $this->safety_equipment,
            'findings' => $this->findings,
            'recommendations' => $this->recommendations,
            'next_inspection_due' => $this->next_inspection_due,
            'status' => $this->status,
            'notes' => $this->notes,
            'vehicle' => new VehicleResource($this->whenLoaded('vehicle')),
            'driver' => new DriverResource($this->whenLoaded('driver')),
            'inspector' => new UserResource($this->whenLoaded('inspector')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
