<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MaintenanceRecordResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'vehicle_id' => $this->vehicle_id,
            'maintenance_type' => $this->maintenance_type,
            'description' => $this->description,
            'scheduled_date' => $this->scheduled_date,
            'completed_date' => $this->completed_date,
            'cost' => $this->cost,
            'formatted_cost' => $this->formatted_cost,
            'currency' => $this->currency,
            'vendor' => $this->vendor,
            'vendor_phone' => $this->vendor_phone,
            'parts_replaced' => $this->parts_replaced,
            'odometer_reading' => $this->odometer_reading,
            'next_service_due' => $this->next_service_due,
            'technician_name' => $this->technician_name,
            'status' => $this->status,
            'notes' => $this->notes,
            'vehicle' => new VehicleResource($this->whenLoaded('vehicle')),
            'user' => new UserResource($this->whenLoaded('user')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
