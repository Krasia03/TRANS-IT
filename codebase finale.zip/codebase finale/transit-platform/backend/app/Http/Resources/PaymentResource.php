<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PaymentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'payment_number' => $this->payment_number,
            'invoice_id' => $this->invoice_id,
            'client_id' => $this->client_id,
            'escrow_id' => $this->escrow_id,
            'amount' => $this->amount,
            'formatted_amount' => $this->formatted_amount,
            'currency' => $this->currency,
            'payment_method' => $this->payment_method,
            'provider_reference' => $this->provider_reference,
            'provider_status' => $this->provider_status,
            'status' => $this->status,
            'is_successful' => $this->isSuccessful(),
            'paid_at' => $this->paid_at,
            'failed_at' => $this->failed_at,
            'failure_reason' => $this->failure_reason,
            'invoice' => new InvoiceResource($this->whenLoaded('invoice')),
            'client' => new ClientResource($this->whenLoaded('client')),
            'escrow' => new EscrowResource($this->whenLoaded('escrow')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
