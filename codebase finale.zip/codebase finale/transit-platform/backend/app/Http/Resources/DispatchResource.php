<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DispatchResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'dispatch_number' => $this->dispatch_number,
            'route_id' => $this->route_id,
            'vehicle_id' => $this->vehicle_id,
            'driver_id' => $this->driver_id,
            'scheduled_start' => $this->scheduled_start,
            'scheduled_end' => $this->scheduled_end,
            'actual_start' => $this->actual_start,
            'actual_end' => $this->actual_end,
            'duration' => $this->duration,
            'status' => $this->status,
            'fuel_assigned' => $this->fuel_assigned,
            'distance_covered' => $this->distance_covered,
            'cargo_count' => $this->cargo_count,
            'deliveries_completed' => $this->deliveries_completed,
            'deliveries_failed' => $this->deliveries_failed,
            'notes' => $this->notes,
            'route' => new RouteResource($this->whenLoaded('route')),
            'vehicle' => new VehicleResource($this->whenLoaded('vehicle')),
            'driver' => new DriverResource($this->whenLoaded('driver')),
            'waypoints' => DispatchWaypointResource::collection($this->whenLoaded('waypoints')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
