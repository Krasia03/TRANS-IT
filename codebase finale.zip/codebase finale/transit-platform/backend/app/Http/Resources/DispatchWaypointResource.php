<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DispatchWaypointResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'dispatch_id' => $this->dispatch_id,
            'name' => $this->name,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'address' => $this->address,
            'order' => $this->order,
            'type' => $this->type,
            'scheduled_arrival' => $this->scheduled_arrival,
            'actual_arrival' => $this->actual_arrival,
            'scheduled_departure' => $this->scheduled_departure,
            'actual_departure' => $this->actual_departure,
            'status' => $this->status,
            'notes' => $this->notes,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
