<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WarehouseResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'warehouse_code' => $this->warehouse_code,
            'name' => $this->name,
            'description' => $this->description,
            'address' => $this->address,
            'city' => $this->city,
            'region' => $this->region,
            'country' => $this->country,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'capacity' => $this->capacity,
            'current_utilization' => $this->current_utilization,
            'utilization_percentage' => $this->utilization_percentage,
            'available_capacity' => $this->available_capacity,
            'status' => $this->status,
            'operating_hours' => $this->operating_hours,
            'contact_phone' => $this->contact_phone,
            'contact_email' => $this->contact_email,
            'manager' => new UserResource($this->whenLoaded('manager')),
            'staff' => WarehouseStaffResource::collection($this->whenLoaded('staff')),
            'inventory' => InventoryResource::collection($this->whenLoaded('inventory')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
