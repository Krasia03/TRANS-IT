<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EscrowResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'escrow_number' => $this->escrow_number,
            'cargo_request_id' => $this->cargo_request_id,
            'client_id' => $this->client_id,
            'amount' => $this->amount,
            'formatted_amount' => $this->formatted_amount,
            'currency' => $this->currency,
            'status' => $this->status,
            'held_at' => $this->held_at,
            'released_at' => $this->released_at,
            'refunded_at' => $this->refunded_at,
            'refund_reason' => $this->refund_reason,
            'payment_reference' => $this->payment_reference,
            'release_reference' => $this->release_reference,
            'is_releasable' => $this->isReleasable(),
            'cargo_request' => new CargoRequestResource($this->whenLoaded('cargoRequest')),
            'client' => new ClientResource($this->whenLoaded('client')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
