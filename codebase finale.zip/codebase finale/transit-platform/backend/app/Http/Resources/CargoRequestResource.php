<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CargoRequestResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'request_number' => $this->request_number,
            'client_id' => $this->client_id,
            'client_type' => $this->client_type,
            'vehicle_id' => $this->vehicle_id,
            'driver_id' => $this->driver_id,
            'route_id' => $this->route_id,
            'cargo_type' => $this->cargo_type,
            'description' => $this->description,
            'weight' => $this->weight,
            'volume' => $this->volume,
            'pickup_location' => $this->pickup_location,
            'pickup_latitude' => $this->pickup_latitude,
            'pickup_longitude' => $this->pickup_longitude,
            'pickup_date' => $this->pickup_date,
            'delivery_location' => $this->delivery_location,
            'delivery_latitude' => $this->delivery_latitude,
            'delivery_longitude' => $this->delivery_longitude,
            'delivery_date' => $this->delivery_date,
            'estimated_distance' => $this->estimated_distance,
            'estimated_duration' => $this->estimated_duration,
            'actual_distance' => $this->actual_distance,
            'actual_duration' => $this->actual_duration,
            'status' => $this->status,
            'priority' => $this->priority,
            'special_requirements' => $this->special_requirements,
            'price' => $this->price,
            'formatted_price' => $this->formatted_price,
            'currency' => $this->currency,
            'tracking_number' => $this->tracking_number,
            'proof_of_delivery' => $this->proof_of_delivery,
            'signature_url' => $this->signature_url,
            'completed_at' => $this->completed_at,
            'cancelled_at' => $this->cancelled_at,
            'cancellation_reason' => $this->cancellation_reason,
            'client' => new ClientResource($this->whenLoaded('client')),
            'vehicle' => new VehicleResource($this->whenLoaded('vehicle')),
            'driver' => new DriverResource($this->whenLoaded('driver')),
            'route' => new RouteResource($this->whenLoaded('route')),
            'insurance' => new CargoInsuranceResource($this->whenLoaded('insurance')),
            'tracking_updates' => CargoTrackingResource::collection($this->whenLoaded('trackingUpdates')),
            'documents' => DocumentResource::collection($this->whenLoaded('documents')),
            'waypoints' => CargoWaypointResource::collection($this->whenLoaded('waypoints')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
