<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DriverPerformanceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'driver_id' => $this->driver_id,
            'period_start' => $this->period_start,
            'period_end' => $this->period_end,
            'total_deliveries' => $this->total_deliveries,
            'successful_deliveries' => $this->successful_deliveries,
            'failed_deliveries' => $this->failed_deliveries,
            'on_time_deliveries' => $this->on_time_deliveries,
            'success_rate' => $this->success_rate,
            'on_time_rate' => $this->on_time_rate,
            'total_distance' => $this->total_distance,
            'average_delivery_time' => $this->average_delivery_time,
            'customer_rating' => $this->customer_rating,
            'safety_score' => $this->safety_score,
            'fuel_efficiency' => $this->fuel_efficiency,
            'incidents_count' => $this->incidents_count,
            'revenue_generated' => $this->revenue_generated,
            'currency' => $this->currency,
            'driver' => new DriverResource($this->whenLoaded('driver')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
