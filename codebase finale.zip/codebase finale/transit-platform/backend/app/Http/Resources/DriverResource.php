<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DriverResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'employee_id' => $this->employee_id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'full_name' => $this->full_name,
            'email' => $this->email,
            'phone' => $this->phone,
            'date_of_birth' => $this->date_of_birth,
            'license_number' => $this->license_number,
            'license_type' => $this->license_type,
            'license_expiry' => $this->license_expiry,
            'address' => $this->address,
            'emergency_contact_name' => $this->emergency_contact_name,
            'emergency_contact_phone' => $this->emergency_contact_phone,
            'profile_photo' => $this->profile_photo,
            'status' => $this->status,
            'hire_date' => $this->hire_date,
            'termination_date' => $this->termination_date,
            'rating' => $this->rating,
            'total_ratings' => $this->total_ratings,
            'total_deliveries' => $this->total_deliveries,
            'accidents_count' => $this->accidents_count,
            'is_license_valid' => $this->isLicenseValid(),
            'user' => new UserResource($this->whenLoaded('user')),
            'primary_vehicle' => new VehicleResource($this->whenLoaded('primaryVehicle')),
            'vehicles' => VehicleResource::collection($this->whenLoaded('vehicles')),
            'payrolls' => DriverPayrollResource::collection($this->whenLoaded('payrolls')),
            'performance' => DriverPerformanceResource::collection($this->whenLoaded('performanceMetrics')),
            'trainings' => DriverTrainingResource::collection($this->whenLoaded('trainingRecords')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
