<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\InvoiceResource;
use App\Models\Invoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $invoices = Invoice::with(['client', 'cargoRequest'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->when($request->overdue, fn($q) => $q->overdue())
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => InvoiceResource::collection($invoices),
            'meta' => [
                'current_page' => $invoices->currentPage(),
                'last_page' => $invoices->lastPage(),
                'per_page' => $invoices->perPage(),
                'total' => $invoices->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'cargo_request_id' => ['nullable', 'exists:cargo_requests,id'],
            'client_id' => ['required', 'exists:clients,id'],
            'subtotal' => ['required', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0'],
            'currency' => ['nullable', 'string', 'size:3'],
            'issue_date' => ['required', 'date'],
            'due_date' => ['required', 'date', 'after:issue_date'],
            'notes' => ['nullable', 'string'],
            'terms' => ['nullable', 'string'],
        ]);

        $taxRate = $request->tax_rate ?? 0;
        $subtotal = $request->subtotal;
        $taxAmount = $subtotal * ($taxRate / 100);

        $invoice = Invoice::create([
            'invoice_number' => 'INV-' . date('Y') . '-' . strtoupper(uniqid()),
            'cargo_request_id' => $request->cargo_request_id,
            'client_id' => $request->client_id,
            'user_id' => $request->user()->id,
            'subtotal' => $subtotal,
            'tax_rate' => $taxRate,
            'tax_amount' => $taxAmount,
            'total_amount' => $subtotal + $taxAmount,
            'currency' => $request->currency ?? 'TZS',
            'status' => 'draft',
            'issue_date' => $request->issue_date,
            'due_date' => $request->due_date,
            'notes' => $request->notes,
            'terms' => $request->terms,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Invoice created successfully',
            'data' => new InvoiceResource($invoice->load(['client', 'cargoRequest', 'items'])),
        ], 201);
    }

    public function show(Invoice $invoice): JsonResponse
    {
        $invoice->load(['client', 'cargoRequest', 'items', 'payments']);

        return response()->json([
            'success' => true,
            'data' => new InvoiceResource($invoice),
        ]);
    }

    public function update(Request $request, Invoice $invoice): JsonResponse
    {
        if ($invoice->status !== 'draft') {
            return response()->json([
                'success' => false,
                'message' => 'Only draft invoices can be updated',
            ], 400);
        }

        $invoice->update($request->only([
            'subtotal', 'tax_rate', 'issue_date', 'due_date', 'notes', 'terms'
        ]));

        $subtotal = $invoice->subtotal;
        $taxAmount = $subtotal * ($invoice->tax_rate / 100);
        $invoice->update([
            'tax_amount' => $taxAmount,
            'total_amount' => $subtotal + $taxAmount,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Invoice updated successfully',
            'data' => new InvoiceResource($invoice->load(['client', 'items'])),
        ]);
    }

    public function send(Invoice $invoice): JsonResponse
    {
        if ($invoice->status !== 'draft') {
            return response()->json([
                'success' => false,
                'message' => 'Invoice cannot be sent in current status',
            ], 400);
        }

        $invoice->update(['status' => 'sent']);

        return response()->json([
            'success' => true,
            'message' => 'Invoice sent successfully',
            'data' => new InvoiceResource($invoice),
        ]);
    }
}
