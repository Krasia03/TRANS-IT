<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AlertResource;
use App\Models\Alert;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AlertController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $alerts = Alert::with(['vehicle', 'driver'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->severity, fn($q) => $q->where('severity', $request->severity))
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->acknowledged === 'false', fn($q) => $q->whereNull('acknowledged_at'))
            ->when($request->resolved === 'false', fn($q) => $q->whereNull('resolved_at'))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => AlertResource::collection($alerts),
            'meta' => [
                'current_page' => $alerts->currentPage(),
                'last_page' => $alerts->lastPage(),
                'per_page' => $alerts->perPage(),
                'total' => $alerts->total(),
            ],
        ]);
    }

    public function acknowledge(Request $request, Alert $alert): JsonResponse
    {
        $alert->update([
            'acknowledged_at' => now(),
            'acknowledged_by' => $request->user()->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Alert acknowledged',
            'data' => new AlertResource($alert->load(['vehicle', 'driver'])),
        ]);
    }

    public function resolve(Request $request, Alert $alert): JsonResponse
    {
        $alert->update([
            'resolved_at' => now(),
            'resolved_by' => $request->user()->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Alert resolved',
            'data' => new AlertResource($alert->load(['vehicle', 'driver'])),
        ]);
    }

    public function stats(): JsonResponse
    {
        $stats = [
            'total' => Alert::count(),
            'critical' => Alert::where('severity', 'critical')->whereNull('acknowledged_at')->count(),
            'unacknowledged' => Alert::whereNull('acknowledged_at')->count(),
            'unresolved' => Alert::whereNull('resolved_at')->count(),
            'by_type' => Alert::whereNull('resolved_at')
                ->selectRaw('type, count(*) as count')
                ->groupBy('type')
                ->pluck('count', 'type'),
        ];

        return response()->json([
            'success' => true,
            'data' => $stats,
        ]);
    }
}
