<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\DispatchResource;
use App\Models\Dispatch;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DispatchController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $dispatches = Dispatch::with(['route', 'vehicle', 'driver'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->date, fn($q) => $q->whereDate('scheduled_start', $request->date))
            ->when($request->driver_id, fn($q) => $q->where('driver_id', $request->driver_id))
            ->when($request->vehicle_id, fn($q) => $q->where('vehicle_id', $request->vehicle_id))
            ->orderBy('scheduled_start', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => DispatchResource::collection($dispatches),
            'meta' => [
                'current_page' => $dispatches->currentPage(),
                'last_page' => $dispatches->lastPage(),
                'per_page' => $dispatches->perPage(),
                'total' => $dispatches->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'route_id' => ['nullable', 'exists:routes,id'],
            'vehicle_id' => ['required', 'exists:vehicles,id'],
            'driver_id' => ['required', 'exists:drivers,id'],
            'scheduled_start' => ['required', 'date'],
            'scheduled_end' => ['required', 'date', 'after:scheduled_start'],
            'fuel_assigned' => ['nullable', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string'],
        ]);

        $dispatch = Dispatch::create([
            'dispatch_number' => 'DSP-' . strtoupper(uniqid()),
            'route_id' => $request->route_id,
            'vehicle_id' => $request->vehicle_id,
            'driver_id' => $request->driver_id,
            'scheduled_start' => $request->scheduled_start,
            'scheduled_end' => $request->scheduled_end,
            'fuel_assigned' => $request->fuel_assigned,
            'status' => 'pending',
            'notes' => $request->notes,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Dispatch created successfully',
            'data' => new DispatchResource($dispatch->load(['route', 'vehicle', 'driver'])),
        ], 201);
    }

    public function show(Dispatch $dispatch): JsonResponse
    {
        $dispatch->load(['route', 'vehicle', 'driver', 'waypoints', 'cargoRequests']);

        return response()->json([
            'success' => true,
            'data' => new DispatchResource($dispatch),
        ]);
    }

    public function update(Request $request, Dispatch $dispatch): JsonResponse
    {
        $dispatch->update($request->only([
            'route_id', 'vehicle_id', 'driver_id', 'scheduled_start',
            'scheduled_end', 'actual_start', 'actual_end', 'status',
            'fuel_assigned', 'distance_covered', 'cargo_count',
            'deliveries_completed', 'deliveries_failed', 'notes'
        ]));

        return response()->json([
            'success' => true,
            'message' => 'Dispatch updated successfully',
            'data' => new DispatchResource($dispatch->load(['route', 'vehicle', 'driver'])),
        ]);
    }

    public function start(Request $request, Dispatch $dispatch): JsonResponse
    {
        $dispatch->update([
            'status' => 'in_progress',
            'actual_start' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Dispatch started',
            'data' => new DispatchResource($dispatch),
        ]);
    }

    public function complete(Request $request, Dispatch $dispatch): JsonResponse
    {
        $dispatch->update([
            'status' => 'completed',
            'actual_end' => now(),
            'distance_covered' => $request->distance_covered ?? $dispatch->distance_covered,
            'deliveries_completed' => $request->deliveries_completed ?? $dispatch->deliveries_completed,
            'deliveries_failed' => $request->deliveries_failed ?? $dispatch->deliveries_failed,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Dispatch completed',
            'data' => new DispatchResource($dispatch),
        ]);
    }
}
