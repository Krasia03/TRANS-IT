<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Vehicle\StoreVehicleRequest;
use App\Http\Requests\Vehicle\UpdateVehicleRequest;
use App\Http\Resources\VehicleResource;
use App\Models\Vehicle;
use App\Models\VehicleLocation;
use App\Services\VehicleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class VehicleController extends Controller
{
    public function __construct(private VehicleService $vehicleService)
    {}

    public function index(Request $request): JsonResponse
    {
        $vehicles = Vehicle::with(['primaryDriver', 'maintenanceRecords'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->search, fn($q) => $q->where('registration_number', 'like', "%{$request->search}%")
                ->orWhere('make', 'like', "%{$request->search}%")
                ->orWhere('model', 'like', "%{$request->search}%"))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => VehicleResource::collection($vehicles),
            'meta' => [
                'current_page' => $vehicles->currentPage(),
                'last_page' => $vehicles->lastPage(),
                'per_page' => $vehicles->perPage(),
                'total' => $vehicles->total(),
            ],
        ]);
    }

    public function store(StoreVehicleRequest $request): JsonResponse
    {
        $vehicle = $this->vehicleService->createVehicle($request->validated());

        return response()->json([
            'success' => true,
            'message' => 'Vehicle created successfully',
            'data' => new VehicleResource($vehicle->load(['primaryDriver'])),
        ], 201);
    }

    public function show(Vehicle $vehicle): JsonResponse
    {
        $vehicle->load(['primaryDriver', 'drivers', 'maintenanceRecords', 'fuelTransactions', 'inspections']);

        return response()->json([
            'success' => true,
            'data' => new VehicleResource($vehicle),
        ]);
    }

    public function update(UpdateVehicleRequest $request, Vehicle $vehicle): JsonResponse
    {
        $vehicle = $this->vehicleService->updateVehicle($vehicle, $request->validated());

        return response()->json([
            'success' => true,
            'message' => 'Vehicle updated successfully',
            'data' => new VehicleResource($vehicle->load(['primaryDriver'])),
        ]);
    }

    public function destroy(Vehicle $vehicle): JsonResponse
    {
        $this->vehicleService->deleteVehicle($vehicle);

        return response()->json([
            'success' => true,
            'message' => 'Vehicle deleted successfully',
        ]);
    }

    public function updateLocation(Request $request, Vehicle $vehicle): JsonResponse
    {
        $request->validate([
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'speed' => ['nullable', 'numeric', 'min:0'],
            'heading' => ['nullable', 'integer', 'between:0,360'],
        ]);

        $location = $this->vehicleService->updateLocation($vehicle, $request->only([
            'latitude', 'longitude', 'speed', 'heading', 'altitude', 'accuracy'
        ]));

        return response()->json([
            'success' => true,
            'message' => 'Location updated successfully',
            'data' => $location,
        ]);
    }

    public function locationHistory(Request $request, Vehicle $vehicle): JsonResponse
    {
        $locations = VehicleLocation::where('vehicle_id', $vehicle->id)
            ->when($request->from, fn($q) => $q->where('recorded_at', '>=', $request->from))
            ->when($request->to, fn($q) => $q->where('recorded_at', '<=', $request->to))
            ->orderBy('recorded_at', 'desc')
            ->paginate($request->per_page ?? 100);

        return response()->json([
            'success' => true,
            'data' => $locations,
        ]);
    }
}
