<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Alert;
use App\Models\CargoRequest;
use App\Models\Vehicle;
use App\Models\Driver;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CommandCenterController extends Controller
{
    public function dashboard(): JsonResponse
    {
        $activeVehicles = Vehicle::where('status', 'active')->count();
        $activeDrivers = Driver::where('status', 'active')->count();
        $pendingCargo = CargoRequest::whereIn('status', ['pending', 'confirmed'])->count();
        $inTransitCargo = CargoRequest::where('status', 'in_transit')->count();
        $criticalAlerts = Alert::where('severity', 'critical')->whereNull('acknowledged_at')->count();
        $pendingAlerts = Alert::whereNull('acknowledged_at')->count();

        return response()->json([
            'success' => true,
            'data' => [
                'active_vehicles' => $activeVehicles,
                'active_drivers' => $activeDrivers,
                'pending_cargo' => $pendingCargo,
                'in_transit_cargo' => $inTransitCargo,
                'critical_alerts' => $criticalAlerts,
                'pending_alerts' => $pendingAlerts,
            ],
        ]);
    }

    public function fleetOverview(): JsonResponse
    {
        $vehicles = Vehicle::where('status', 'active')
            ->with('primaryDriver')
            ->get()
            ->map(function ($vehicle) {
                return [
                    'id' => $vehicle->id,
                    'registration_number' => $vehicle->registration_number,
                    'type' => $vehicle->type,
                    'status' => $vehicle->status,
                    'current_location' => $vehicle->current_location,
                    'last_location_update' => $vehicle->last_location_update,
                    'fuel_level' => $vehicle->fuel_level,
                    'driver' => $vehicle->primaryDriver ? [
                        'id' => $vehicle->primaryDriver->id,
                        'name' => $vehicle->primaryDriver->full_name,
                    ] : null,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $vehicles,
        ]);
    }

    public function h3DemandMap(): JsonResponse
    {
        $demandData = CargoRequest::select(
            DB::raw('ROUND(pickup_latitude, 2) as lat'),
            DB::raw('ROUND(pickup_longitude, 2) as lng'),
            DB::raw('COUNT(*) as demand')
        )
            ->whereNotNull('pickup_latitude')
            ->whereNotNull('pickup_longitude')
            ->whereIn('status', ['pending', 'confirmed'])
            ->groupBy(DB::raw('ROUND(pickup_latitude, 2)'), DB::raw('ROUND(pickup_longitude, 2)'))
            ->get();

        return response()->json([
            'success' => true,
            'data' => $demandData,
        ]);
    }

    public function liveMetrics(): JsonResponse
    {
        $todayDeliveries = CargoRequest::whereDate('completed_at', today())->count();
        $todayRevenue = CargoRequest::whereDate('completed_at', today())
            ->where('status', 'completed')
            ->sum('price');

        $vehicleUtilization = Vehicle::where('status', 'active')
            ->selectRaw('COUNT(*) as total, SUM(CASE WHEN last_location_update > NOW() - INTERVAL 1 HOUR THEN 1 ELSE 0 END) as active')
            ->first();

        $avgDeliveryTime = CargoRequest::where('status', 'completed')
            ->whereNotNull('actual_duration')
            ->whereDate('completed_at', '>=', now()->subDays(7))
            ->avg('actual_duration');

        return response()->json([
            'success' => true,
            'data' => [
                'today_deliveries' => $todayDeliveries,
                'today_revenue' => $todayRevenue,
                'vehicle_utilization' => [
                    'total' => $vehicleUtilization->total ?? 0,
                    'active' => $vehicleUtilization->active ?? 0,
                    'percentage' => $vehicleUtilization->total > 0
                        ? round(($vehicleUtilization->active / $vehicleUtilization->total) * 100, 1)
                        : 0,
                ],
                'avg_delivery_time_minutes' => round($avgDeliveryTime ?? 0),
            ],
        ]);
    }
}
