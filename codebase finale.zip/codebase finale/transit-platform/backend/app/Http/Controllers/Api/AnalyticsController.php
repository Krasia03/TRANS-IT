<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CargoRequest;
use App\Models\Payment;
use App\Models\Vehicle;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AnalyticsController extends Controller
{
    public function revenueInsights(Request $request): JsonResponse
    {
        $period = $request->period ?? '30';
        $startDate = now()->subDays($period);

        $dailyRevenue = CargoRequest::where('status', 'completed')
            ->where('completed_at', '>=', $startDate)
            ->select(
                DB::raw('DATE(completed_at) as date'),
                DB::raw('SUM(price) as revenue'),
                DB::raw('COUNT(*) as deliveries')
            )
            ->groupBy(DB::raw('DATE(completed_at)'))
            ->orderBy('date')
            ->get();

        $totalRevenue = $dailyRevenue->sum('revenue');
        $totalDeliveries = $dailyRevenue->sum('deliveries');
        $avgOrderValue = $totalDeliveries > 0 ? $totalRevenue / $totalDeliveries : 0;

        $revenueByStatus = CargoRequest::where('completed_at', '>=', $startDate)
            ->select('status', DB::raw('SUM(price) as revenue'), DB::raw('COUNT(*) as count'))
            ->groupBy('status')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'period_days' => $period,
                'total_revenue' => $totalRevenue,
                'total_deliveries' => $totalDeliveries,
                'avg_order_value' => round($avgOrderValue, 2),
                'daily_revenue' => $dailyRevenue,
                'revenue_by_status' => $revenueByStatus,
            ],
        ]);
    }

    public function systemHealth(): JsonResponse
    {
        $vehicleHealth = [
            'total' => Vehicle::count(),
            'active' => Vehicle::where('status', 'active')->count(),
            'maintenance' => Vehicle::where('status', 'maintenance')->count(),
            'insurance_expiring' => Vehicle::where('insurance_expiry', '<=', now()->addDays(30))
                ->where('insurance_expiry', '>=', now())
                ->count(),
        ];

        $cargoHealth = [
            'total' => CargoRequest::count(),
            'pending' => CargoRequest::where('status', 'pending')->count(),
            'in_transit' => CargoRequest::where('status', 'in_transit')->count(),
            'completed' => CargoRequest::where('status', 'completed')->count(),
            'failed' => CargoRequest::where('status', 'failed')->count(),
        ];

        $paymentHealth = [
            'total_transactions' => Payment::count(),
            'successful' => Payment::where('status', 'successful')->count(),
            'pending' => Payment::where('status', 'pending')->count(),
            'failed' => Payment::where('status', 'failed')->count(),
            'total_amount' => Payment::where('status', 'successful')->sum('amount'),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'vehicles' => $vehicleHealth,
                'cargo' => $cargoHealth,
                'payments' => $paymentHealth,
            ],
        ]);
    }

    public function customReport(Request $request): JsonResponse
    {
        $request->validate([
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after:start_date'],
            'metrics' => ['required', 'array'],
        ]);

        $startDate = $request->start_date;
        $endDate = $request->end_date;
        $metrics = $request->metrics;

        $data = [];

        if (in_array('revenue', $metrics)) {
            $data['revenue'] = CargoRequest::whereBetween('completed_at', [$startDate, $endDate])
                ->where('status', 'completed')
                ->select(
                    DB::raw('DATE(completed_at) as date'),
                    DB::raw('SUM(price) as total')
                )
                ->groupBy('date')
                ->get();
        }

        if (in_array('deliveries', $metrics)) {
            $data['deliveries'] = CargoRequest::whereBetween('completed_at', [$startDate, $endDate])
                ->where('status', 'completed')
                ->select(DB::raw('DATE(completed_at) as date'), DB::raw('COUNT(*) as count'))
                ->groupBy('date')
                ->get();
        }

        if (in_array('vehicles', $metrics)) {
            $data['vehicles'] = [
                'usage' => Vehicle::where('status', 'active')
                    ->withCount(['routeAssignments' => fn($q) => $q->whereBetween('assignment_date', [$startDate, $endDate])])
                    ->get(),
            ];
        }

        return response()->json([
            'success' => true,
            'data' => $data,
        ]);
    }
}
