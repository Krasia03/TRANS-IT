<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ClientResource;
use App\Models\Client;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $clients = Client::with(['user', 'contacts'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->search, fn($q) => $q->where('company_name', 'like', "%{$request->search}%")
                ->orWhere('contact_person', 'like', "%{$request->search}%")
                ->orWhere('client_number', 'like', "%{$request->search}%"))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => ClientResource::collection($clients),
            'meta' => [
                'current_page' => $clients->currentPage(),
                'last_page' => $clients->lastPage(),
                'per_page' => $clients->perPage(),
                'total' => $clients->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'type' => ['required', 'in:corporate,individual'],
            'company_name' => ['nullable', 'string'],
            'contact_person' => ['required', 'string'],
            'email' => ['required', 'email'],
            'phone' => ['required', 'string'],
            'address' => ['nullable', 'string'],
            'city' => ['nullable', 'string'],
            'region' => ['nullable', 'string'],
            'country' => ['nullable', 'string'],
            'postal_code' => ['nullable', 'string'],
            'tax_id' => ['nullable', 'string'],
            'credit_limit' => ['nullable', 'numeric', 'min:0'],
            'payment_terms' => ['nullable', 'string'],
            'status' => ['nullable', 'in:active,inactive,suspended'],
        ]);

        $client = Client::create([
            'client_number' => 'CLT-' . strtoupper(uniqid()),
            'type' => $request->type,
            'company_name' => $request->company_name,
            'contact_person' => $request->contact_person,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'city' => $request->city,
            'region' => $request->region,
            'country' => $request->country ?? 'Tanzania',
            'postal_code' => $request->postal_code,
            'tax_id' => $request->tax_id,
            'credit_limit' => $request->credit_limit ?? 0,
            'payment_terms' => $request->payment_terms ?? 'net_30',
            'status' => $request->status ?? 'active',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Client created successfully',
            'data' => new ClientResource($client->load(['user', 'contacts'])),
        ], 201);
    }

    public function show(Client $client): JsonResponse
    {
        $client->load(['user', 'contacts', 'cargoRequests', 'invoices']);

        return response()->json([
            'success' => true,
            'data' => new ClientResource($client),
        ]);
    }

    public function update(Request $request, Client $client): JsonResponse
    {
        $client->update($request->only([
            'company_name', 'contact_person', 'email', 'phone', 'address',
            'city', 'region', 'country', 'postal_code', 'tax_id',
            'credit_limit', 'payment_terms', 'status'
        ]));

        return response()->json([
            'success' => true,
            'message' => 'Client updated successfully',
            'data' => new ClientResource($client->load(['user', 'contacts'])),
        ]);
    }

    public function destroy(Client $client): JsonResponse
    {
        $client->delete();

        return response()->json([
            'success' => true,
            'message' => 'Client deleted successfully',
        ]);
    }
}
