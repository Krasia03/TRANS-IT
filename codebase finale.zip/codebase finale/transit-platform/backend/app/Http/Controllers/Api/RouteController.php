<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\RouteResource;
use App\Models\Route;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RouteController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $routes = Route::with(['creator', 'waypoints'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->route_type, fn($q) => $q->where('route_type', $request->route_type))
            ->when($request->search, fn($q) => $q->where('name', 'like', "%{$request->search}%")
                ->orWhere('route_number', 'like', "%{$request->search}%"))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => RouteResource::collection($routes),
            'meta' => [
                'current_page' => $routes->currentPage(),
                'last_page' => $routes->lastPage(),
                'per_page' => $routes->perPage(),
                'total' => $routes->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name' => ['required', 'string'],
            'origin' => ['required', 'string'],
            'origin_latitude' => ['nullable', 'numeric'],
            'origin_longitude' => ['nullable', 'numeric'],
            'destination' => ['required', 'string'],
            'destination_latitude' => ['nullable', 'numeric'],
            'destination_longitude' => ['nullable', 'numeric'],
            'waypoints' => ['nullable', 'array'],
            'total_distance' => ['nullable', 'numeric'],
            'estimated_duration' => ['nullable', 'integer'],
            'route_type' => ['nullable', 'in:shortest,fastest,scenic,custom'],
        ]);

        $route = Route::create([
            'route_number' => 'RTE-' . strtoupper(uniqid()),
            'name' => $request->name,
            'origin' => $request->origin,
            'origin_latitude' => $request->origin_latitude,
            'origin_longitude' => $request->origin_longitude,
            'destination' => $request->destination,
            'destination_latitude' => $request->destination_latitude,
            'destination_longitude' => $request->destination_longitude,
            'waypoints' => $request->waypoints,
            'total_distance' => $request->total_distance ?? 0,
            'estimated_duration' => $request->estimated_duration ?? 0,
            'route_type' => $request->route_type ?? 'fastest',
            'status' => 'draft',
            'created_by' => $request->user()->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Route created successfully',
            'data' => new RouteResource($route->load(['creator', 'waypoints'])),
        ], 201);
    }

    public function show(Route $route): JsonResponse
    {
        $route->load(['creator', 'waypoints', 'cargoRequests', 'dispatches']);

        return response()->json([
            'success' => true,
            'data' => new RouteResource($route),
        ]);
    }

    public function update(Request $request, Route $route): JsonResponse
    {
        $route->update($request->only([
            'name', 'origin', 'origin_latitude', 'origin_longitude',
            'destination', 'destination_latitude', 'destination_longitude',
            'waypoints', 'total_distance', 'estimated_duration', 'route_type', 'status'
        ]));

        return response()->json([
            'success' => true,
            'message' => 'Route updated successfully',
            'data' => new RouteResource($route->load(['creator', 'waypoints'])),
        ]);
    }

    public function destroy(Route $route): JsonResponse
    {
        $route->delete();

        return response()->json([
            'success' => true,
            'message' => 'Route deleted successfully',
        ]);
    }
}
