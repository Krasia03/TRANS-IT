<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\WarehouseResource;
use App\Models\Warehouse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WarehouseController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $warehouses = Warehouse::with(['manager', 'staff'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->city, fn($q) => $q->where('city', $request->city))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => WarehouseResource::collection($warehouses),
            'meta' => [
                'current_page' => $warehouses->currentPage(),
                'last_page' => $warehouses->lastPage(),
                'per_page' => $warehouses->perPage(),
                'total' => $warehouses->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name' => ['required', 'string'],
            'description' => ['nullable', 'string'],
            'address' => ['nullable', 'string'],
            'city' => ['nullable', 'string'],
            'region' => ['nullable', 'string'],
            'country' => ['nullable', 'string'],
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
            'capacity' => ['required', 'numeric', 'min:0'],
            'manager_id' => ['nullable', 'exists:users,id'],
            'status' => ['nullable', 'in:active,inactive,maintenance'],
            'operating_hours' => ['nullable', 'array'],
            'contact_phone' => ['nullable', 'string'],
            'contact_email' => ['nullable', 'email'],
        ]);

        $warehouse = Warehouse::create([
            'warehouse_code' => 'WH-' . strtoupper(uniqid()),
            'name' => $request->name,
            'description' => $request->description,
            'address' => $request->address,
            'city' => $request->city,
            'region' => $request->region,
            'country' => $request->country ?? 'Tanzania',
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'capacity' => $request->capacity,
            'manager_id' => $request->manager_id,
            'status' => $request->status ?? 'active',
            'operating_hours' => $request->operating_hours,
            'contact_phone' => $request->contact_phone,
            'contact_email' => $request->contact_email,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Warehouse created successfully',
            'data' => new WarehouseResource($warehouse->load(['manager', 'staff'])),
        ], 201);
    }

    public function show(Warehouse $warehouse): JsonResponse
    {
        $warehouse->load(['manager', 'staff', 'inventory']);

        return response()->json([
            'success' => true,
            'data' => new WarehouseResource($warehouse),
        ]);
    }

    public function update(Request $request, Warehouse $warehouse): JsonResponse
    {
        $warehouse->update($request->only([
            'name', 'description', 'address', 'city', 'region', 'country',
            'latitude', 'longitude', 'capacity', 'manager_id', 'status',
            'operating_hours', 'contact_phone', 'contact_email'
        ]));

        return response()->json([
            'success' => true,
            'message' => 'Warehouse updated successfully',
            'data' => new WarehouseResource($warehouse->load(['manager', 'staff'])),
        ]);
    }

    public function destroy(Warehouse $warehouse): JsonResponse
    {
        $warehouse->delete();

        return response()->json([
            'success' => true,
            'message' => 'Warehouse deleted successfully',
        ]);
    }
}
