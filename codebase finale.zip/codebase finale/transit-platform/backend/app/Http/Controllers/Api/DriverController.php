<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Driver\StoreDriverRequest;
use App\Http\Requests\Driver\UpdateDriverRequest;
use App\Http\Resources\DriverResource;
use App\Models\Driver;
use App\Services\DriverService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DriverController extends Controller
{
    public function __construct(private DriverService $driverService)
    {}

    public function index(Request $request): JsonResponse
    {
        $drivers = Driver::with(['user', 'primaryVehicle'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->search, fn($q) => $q->where('first_name', 'like', "%{$request->search}%")
                ->orWhere('last_name', 'like', "%{$request->search}%")
                ->orWhere('employee_id', 'like', "%{$request->search}%")
                ->orWhere('phone', 'like', "%{$request->search}%"))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => DriverResource::collection($drivers),
            'meta' => [
                'current_page' => $drivers->currentPage(),
                'last_page' => $drivers->lastPage(),
                'per_page' => $drivers->perPage(),
                'total' => $drivers->total(),
            ],
        ]);
    }

    public function store(StoreDriverRequest $request): JsonResponse
    {
        $driver = $this->driverService->createDriver($request->validated());

        return response()->json([
            'success' => true,
            'message' => 'Driver created successfully',
            'data' => new DriverResource($driver->load(['user', 'primaryVehicle'])),
        ], 201);
    }

    public function show(Driver $driver): JsonResponse
    {
        $driver->load(['user', 'primaryVehicle', 'vehicles', 'payrolls', 'performanceMetrics', 'trainingRecords']);

        return response()->json([
            'success' => true,
            'data' => new DriverResource($driver),
        ]);
    }

    public function update(UpdateDriverRequest $request, Driver $driver): JsonResponse
    {
        $driver = $this->driverService->updateDriver($driver, $request->validated());

        return response()->json([
            'success' => true,
            'message' => 'Driver updated successfully',
            'data' => new DriverResource($driver->load(['user', 'primaryVehicle'])),
        ]);
    }

    public function destroy(Driver $driver): JsonResponse
    {
        $this->driverService->deleteDriver($driver);

        return response()->json([
            'success' => true,
            'message' => 'Driver deleted successfully',
        ]);
    }

    public function performance(Request $request, Driver $driver): JsonResponse
    {
        $performance = $driver->performanceMetrics()
            ->when($request->period_start, fn($q) => $q->where('period_start', '>=', $request->period_start))
            ->when($request->period_end, fn($q) => $q->where('period_end', '<=', $request->period_end))
            ->orderBy('period_start', 'desc')
            ->paginate($request->per_page ?? 12);

        return response()->json([
            'success' => true,
            'data' => $performance,
        ]);
    }

    public function processPayroll(Request $request, Driver $driver): JsonResponse
    {
        $request->validate([
            'period_start' => ['required', 'date'],
            'period_end' => ['required', 'date', 'after:period_start'],
        ]);

        $payroll = $this->driverService->processPayroll($driver, $request->only(['period_start', 'period_end']));

        return response()->json([
            'success' => true,
            'message' => 'Payroll processed successfully',
            'data' => $payroll,
        ]);
    }
}
