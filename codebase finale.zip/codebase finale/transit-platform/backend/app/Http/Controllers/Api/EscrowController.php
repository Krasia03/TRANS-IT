<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\EscrowResource;
use App\Models\Escrow;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class EscrowController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $escrows = Escrow::with(['cargoRequest', 'client'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => EscrowResource::collection($escrows),
            'meta' => [
                'current_page' => $escrows->currentPage(),
                'last_page' => $escrows->lastPage(),
                'per_page' => $escrows->perPage(),
                'total' => $escrows->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'cargo_request_id' => ['required', 'exists:cargo_requests,id'],
            'client_id' => ['required', 'exists:clients,id'],
            'amount' => ['required', 'numeric', 'min:0'],
            'currency' => ['nullable', 'string', 'size:3'],
        ]);

        $escrow = Escrow::create([
            'escrow_number' => 'ESC-' . strtoupper(uniqid()),
            'cargo_request_id' => $request->cargo_request_id,
            'client_id' => $request->client_id,
            'amount' => $request->amount,
            'currency' => $request->currency ?? 'TZS',
            'status' => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Escrow created successfully',
            'data' => new EscrowResource($escrow),
        ], 201);
    }

    public function show(Escrow $escrow): JsonResponse
    {
        $escrow->load(['cargoRequest', 'client']);

        return response()->json([
            'success' => true,
            'data' => new EscrowResource($escrow),
        ]);
    }

    public function hold(Request $request, Escrow $escrow): JsonResponse
    {
        if (!$escrow->canHold()) {
            return response()->json([
                'success' => false,
                'message' => 'Escrow cannot be held in current status',
            ], 400);
        }

        $escrow->update([
            'status' => 'held',
            'held_at' => now(),
            'payment_reference' => $request->payment_reference,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Escrow held successfully',
            'data' => new EscrowResource($escrow),
        ]);
    }

    public function release(Request $request, Escrow $escrow): JsonResponse
    {
        if (!$escrow->isReleasable()) {
            return response()->json([
                'success' => false,
                'message' => 'Escrow cannot be released in current status',
            ], 400);
        }

        $request->validate([
            'released_to' => ['required', 'exists:users,id'],
        ]);

        $escrow->update([
            'status' => 'released',
            'released_at' => now(),
            'released_to' => $request->released_to,
            'release_reference' => 'REL-' . strtoupper(uniqid()),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Escrow released successfully',
            'data' => new EscrowResource($escrow),
        ]);
    }

    public function refund(Request $request, Escrow $escrow): JsonResponse
    {
        if (!$escrow->canRefund()) {
            return response()->json([
                'success' => false,
                'message' => 'Escrow cannot be refunded in current status',
            ], 400);
        }

        $escrow->update([
            'status' => 'refunded',
            'refunded_at' => now(),
            'refund_reason' => $request->reason,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Escrow refunded successfully',
            'data' => new EscrowResource($escrow),
        ]);
    }
}
