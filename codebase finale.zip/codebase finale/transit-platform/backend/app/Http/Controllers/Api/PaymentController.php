<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PaymentResource;
use App\Models\Payment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $payments = Payment::with(['invoice', 'client', 'escrow'])
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->payment_method, fn($q) => $q->where('payment_method', $request->payment_method))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->when($request->date_from, fn($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => PaymentResource::collection($payments),
            'meta' => [
                'current_page' => $payments->currentPage(),
                'last_page' => $payments->lastPage(),
                'per_page' => $payments->perPage(),
                'total' => $payments->total(),
            ],
        ]);
    }

    public function show(Payment $payment): JsonResponse
    {
        $payment->load(['invoice', 'client', 'escrow', 'user']);

        return response()->json([
            'success' => true,
            'data' => new PaymentResource($payment),
        ]);
    }

    public function initiate(Request $request): JsonResponse
    {
        $request->validate([
            'invoice_id' => ['required', 'exists:invoices,id'],
            'payment_method' => ['required', 'in:mpesa,tigo_pesa,airtel_money,bank_transfer,cash,escrow'],
            'amount' => ['required', 'numeric', 'min:0'],
            'phone' => ['nullable', 'string'],
        ]);

        $payment = Payment::create([
            'payment_number' => 'PAY-' . strtoupper(uniqid()),
            'invoice_id' => $request->invoice_id,
            'amount' => $request->amount,
            'currency' => 'TZS',
            'payment_method' => $request->payment_method,
            'status' => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Payment initiated',
            'data' => new PaymentResource($payment->load(['invoice', 'client'])),
        ], 201);
    }

    public function callback(Request $request, Payment $payment): JsonResponse
    {
        $payment->update([
            'provider_status' => $request->status,
            'provider_response' => $request->all(),
            'status' => $request->status === 'completed' ? 'successful' : 'failed',
            'paid_at' => $request->status === 'completed' ? now() : null,
            'failed_at' => $request->status === 'failed' ? now() : null,
            'failure_reason' => $request->message,
        ]);

        return response()->json(['success' => true]);
    }
}
