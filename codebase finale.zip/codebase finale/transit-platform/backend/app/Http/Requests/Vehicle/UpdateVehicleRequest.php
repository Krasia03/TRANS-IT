<?php

namespace App\Http\Requests\Vehicle;

use Illuminate\Foundation\Http\FormRequest;

class UpdateVehicleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('edit vehicles');
    }

    public function rules(): array
    {
        return [
            'user_id' => ['nullable', 'exists:users,id'],
            'registration_number' => ['sometimes', 'string', 'max:20', 'unique:vehicles,registration_number,' . $this->vehicle->id],
            'vin' => ['nullable', 'string', 'max:17', 'unique:vehicles,vin,' . $this->vehicle->id],
            'make' => ['sometimes', 'string', 'max:50'],
            'model' => ['sometimes', 'string', 'max:50'],
            'year' => ['sometimes', 'integer', 'between:1990,2030'],
            'type' => ['sometimes', 'in:truck,van,pickup,trailer,bus,motorcycle'],
            'capacity' => ['sometimes', 'numeric', 'min:0'],
            'fuel_type' => ['sometimes', 'in:petrol,diesel,electric,hybrid,lpg'],
            'status' => ['nullable', 'in:active,inactive,maintenance,decommissioned'],
            'insurance_expiry' => ['nullable', 'date'],
            'road_tax_expiry' => ['nullable', 'date'],
            'inspection_due' => ['nullable', 'date'],
            'image_url' => ['nullable', 'url'],
        ];
    }
}
