<?php

namespace App\Http\Requests\Vehicle;

use Illuminate\Foundation\Http\FormRequest;

class StoreVehicleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create vehicles');
    }

    public function rules(): array
    {
        return [
            'user_id' => ['nullable', 'exists:users,id'],
            'registration_number' => ['required', 'string', 'max:20', 'unique:vehicles'],
            'vin' => ['nullable', 'string', 'max:17', 'unique:vehicles'],
            'make' => ['required', 'string', 'max:50'],
            'model' => ['required', 'string', 'max:50'],
            'year' => ['required', 'integer', 'between:1990,2030'],
            'type' => ['required', 'in:truck,van,pickup,trailer,bus,motorcycle'],
            'capacity' => ['required', 'numeric', 'min:0'],
            'fuel_type' => ['required', 'in:petrol,diesel,electric,hybrid,lpg'],
            'status' => ['nullable', 'in:active,inactive,maintenance,decommissioned'],
            'insurance_expiry' => ['nullable', 'date'],
            'road_tax_expiry' => ['nullable', 'date'],
            'inspection_due' => ['nullable', 'date'],
            'image_url' => ['nullable', 'url'],
        ];
    }
}
