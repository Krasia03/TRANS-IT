<?php

namespace App\Http\Requests\Cargo;

use Illuminate\Foundation\Http\FormRequest;

class StoreCargoRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create cargo');
    }

    public function rules(): array
    {
        return [
            'client_id' => ['required', 'exists:clients,id'],
            'client_type' => ['required', 'in:corporate,individual'],
            'cargo_type' => ['required', 'in:general,fragile,hazardous,perishable,livestock,oversized'],
            'description' => ['required', 'string'],
            'weight' => ['required', 'numeric', 'min:0'],
            'volume' => ['nullable', 'numeric', 'min:0'],
            'pickup_location' => ['required', 'string'],
            'pickup_latitude' => ['nullable', 'numeric'],
            'pickup_longitude' => ['nullable', 'numeric'],
            'pickup_date' => ['required', 'date'],
            'delivery_location' => ['required', 'string'],
            'delivery_latitude' => ['nullable', 'numeric'],
            'delivery_longitude' => ['nullable', 'numeric'],
            'delivery_date' => ['nullable', 'date'],
            'estimated_distance' => ['nullable', 'numeric'],
            'estimated_duration' => ['nullable', 'integer'],
            'priority' => ['nullable', 'in:low,normal,high,urgent'],
            'special_requirements' => ['nullable', 'array'],
            'price' => ['nullable', 'numeric', 'min:0'],
            'currency' => ['nullable', 'string', 'size:3'],
        ];
    }
}
