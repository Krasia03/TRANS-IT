<?php

namespace App\Http\Requests\Cargo;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCargoRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('edit cargo');
    }

    public function rules(): array
    {
        return [
            'cargo_type' => ['sometimes', 'in:general,fragile,hazardous,perishable,livestock,oversized'],
            'description' => ['sometimes', 'string'],
            'weight' => ['sometimes', 'numeric', 'min:0'],
            'volume' => ['nullable', 'numeric', 'min:0'],
            'pickup_location' => ['sometimes', 'string'],
            'pickup_latitude' => ['nullable', 'numeric'],
            'pickup_longitude' => ['nullable', 'numeric'],
            'pickup_date' => ['sometimes', 'date'],
            'delivery_location' => ['sometimes', 'string'],
            'delivery_latitude' => ['nullable', 'numeric'],
            'delivery_longitude' => ['nullable', 'numeric'],
            'delivery_date' => ['nullable', 'date'],
            'estimated_distance' => ['nullable', 'numeric'],
            'estimated_duration' => ['nullable', 'integer'],
            'priority' => ['sometimes', 'in:low,normal,high,urgent'],
            'special_requirements' => ['nullable', 'array'],
            'price' => ['sometimes', 'numeric', 'min:0'],
            'status' => ['sometimes', 'in:pending,confirmed,assigned,at_pickup,in_transit,at_delivery,delivered,completed,cancelled,failed'],
        ];
    }
}
