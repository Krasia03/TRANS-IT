<?php

namespace App\Http\Requests\Driver;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDriverRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('edit drivers');
    }

    public function rules(): array
    {
        return [
            'user_id' => ['nullable', 'exists:users,id'],
            'employee_id' => ['sometimes', 'string', 'unique:drivers,employee_id,' . $this->driver->id],
            'first_name' => ['sometimes', 'string', 'max:50'],
            'last_name' => ['sometimes', 'string', 'max:50'],
            'email' => ['sometimes', 'email', 'unique:drivers,email,' . $this->driver->id],
            'phone' => ['sometimes', 'string', 'max:20'],
            'date_of_birth' => ['nullable', 'date', 'before:today'],
            'license_number' => ['sometimes', 'string', 'unique:drivers,license_number,' . $this->driver->id],
            'license_type' => ['sometimes', 'in:A,B,C,D,E,CM'],
            'license_expiry' => ['sometimes', 'date', 'after:today'],
            'address' => ['nullable', 'string'],
            'emergency_contact_name' => ['nullable', 'string', 'max:100'],
            'emergency_contact_phone' => ['nullable', 'string', 'max:20'],
            'profile_photo' => ['nullable', 'url'],
            'status' => ['nullable', 'in:active,inactive,on_leave,suspended,terminated'],
            'hire_date' => ['sometimes', 'date'],
            'termination_date' => ['nullable', 'date'],
        ];
    }
}
