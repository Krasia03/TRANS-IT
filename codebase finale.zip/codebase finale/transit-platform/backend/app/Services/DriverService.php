<?php

namespace App\Services;

use App\Models\Driver;
use App\Models\DriverPayroll;
use App\Models\CargoRequest;
use Illuminate\Support\Str;

class DriverService
{
    public function createDriver(array $data): Driver
    {
        return Driver::create($data);
    }

    public function updateDriver(Driver $driver, array $data): Driver
    {
        $driver->update($data);
        return $driver->fresh(['user', 'primaryVehicle']);
    }

    public function deleteDriver(Driver $driver): void
    {
        $driver->delete();
    }

    public function processPayroll(Driver $driver, array $period): DriverPayroll
    {
        $periodStart = $period['period_start'];
        $periodEnd = $period['period_end'];

        $baseSalary = $driver->total_deliveries > 0 
            ? $driver->total_deliveries * 50000 
            : 400000;

        $successfulDeliveries = CargoRequest::where('driver_id', $driver->id)
            ->whereBetween('completed_at', [$periodStart, $periodEnd])
            ->where('status', 'completed')
            ->count();

        $bonuses = $successfulDeliveries * 10000;

        $grossSalary = $baseSalary + $bonuses;
        $deductions = $grossSalary * 0.1; 

        $payroll = DriverPayroll::create([
            'payroll_number' => 'PAY-' . strtoupper(Str::random(8)),
            'driver_id' => $driver->id,
            'period_start' => $periodStart,
            'period_end' => $periodEnd,
            'base_salary' => $baseSalary,
            'allowances' => 0,
            'deductions' => $deductions,
            'bonuses' => $bonuses,
            'gross_salary' => $grossSalary,
            'net_salary' => $grossSalary - $deductions,
            'currency' => 'TZS',
            'status' => 'pending',
            'processed_by' => auth()->id(),
            'processed_at' => now(),
        ]);

        return $payroll;
    }
}
