<?php

namespace App\Services;

use App\Models\CargoRequest;
use App\Models\CargoTracking;
use Illuminate\Support\Str;

class CargoService
{
    public function createCargoRequest(array $data): CargoRequest
    {
        $data['request_number'] = 'CRG-' . strtoupper(Str::random(8));
        $data['tracking_number'] = 'TRK' . strtoupper(Str::random(10));
        $data['currency'] = $data['currency'] ?? 'TZS';
        
        return CargoRequest::create($data);
    }

    public function updateCargoRequest(CargoRequest $cargoRequest, array $data): CargoRequest
    {
        $cargoRequest->update($data);
        return $cargoRequest->fresh(['client', 'vehicle', 'driver', 'route']);
    }

    public function assignCargo(CargoRequest $cargoRequest, array $data): CargoRequest
    {
        $cargoRequest->update([
            'vehicle_id' => $data['vehicle_id'],
            'driver_id' => $data['driver_id'],
            'route_id' => $data['route_id'] ?? null,
            'status' => 'assigned',
        ]);

        $this->addTrackingUpdate($cargoRequest, 'assigned', 'Cargo assigned to driver and vehicle');

        return $cargoRequest->fresh(['vehicle', 'driver', 'route']);
    }

    public function updateStatus(CargoRequest $cargoRequest, string $status): CargoRequest
    {
        $statusMessages = [
            'confirmed' => 'Cargo request confirmed',
            'at_pickup' => 'Driver at pickup location',
            'in_transit' => 'Cargo in transit',
            'at_delivery' => 'Driver at delivery location',
            'delivered' => 'Cargo delivered',
            'completed' => 'Delivery completed and confirmed',
            'cancelled' => 'Cargo request cancelled',
            'failed' => 'Delivery failed',
        ];

        $cargoRequest->update([
            'status' => $status,
            'completed_at' => in_array($status, ['delivered', 'completed']) ? now() : null,
            'cancelled_at' => $status === 'cancelled' ? now() : null,
        ]);

        $message = $statusMessages[$status] ?? "Status changed to {$status}";
        $this->addTrackingUpdate($cargoRequest, $status, $message);

        return $cargoRequest->fresh();
    }

    protected function addTrackingUpdate(CargoRequest $cargoRequest, string $status, string $description): void
    {
        CargoTracking::create([
            'cargo_request_id' => $cargoRequest->id,
            'status' => $status,
            'description' => $description,
            'recorded_by' => auth()->id(),
            'recorded_at' => now(),
        ]);
    }
}
