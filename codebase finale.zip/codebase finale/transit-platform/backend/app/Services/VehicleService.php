<?php

namespace App\Services;

use App\Models\Vehicle;
use App\Models\VehicleLocation;
use Illuminate\Support\Str;

class VehicleService
{
    public function createVehicle(array $data): Vehicle
    {
        $data['registration_number'] = strtoupper($data['registration_number']);
        
        return Vehicle::create($data);
    }

    public function updateVehicle(Vehicle $vehicle, array $data): Vehicle
    {
        if (isset($data['registration_number'])) {
            $data['registration_number'] = strtoupper($data['registration_number']);
        }

        $vehicle->update($data);

        return $vehicle->fresh(['primaryDriver']);
    }

    public function deleteVehicle(Vehicle $vehicle): void
    {
        $vehicle->delete();
    }

    public function updateLocation(Vehicle $vehicle, array $locationData): VehicleLocation
    {
        $vehicle->update([
            'current_location' => [
                'latitude' => $locationData['latitude'],
                'longitude' => $locationData['longitude'],
                'speed' => $locationData['speed'] ?? null,
                'heading' => $locationData['heading'] ?? null,
                'updated_at' => now()->toIso8601String(),
            ],
            'last_location_update' => now(),
        ]);

        return VehicleLocation::create([
            'vehicle_id' => $vehicle->id,
            'latitude' => $locationData['latitude'],
            'longitude' => $locationData['longitude'],
            'speed' => $locationData['speed'] ?? null,
            'heading' => $locationData['heading'] ?? null,
            'altitude' => $locationData['altitude'] ?? null,
            'accuracy' => $locationData['accuracy'] ?? null,
            'recorded_at' => now(),
            'location_type' => 'gps',
        ]);
    }
}
